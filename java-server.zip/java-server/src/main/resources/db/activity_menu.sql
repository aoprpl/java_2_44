-- 添加活动管理菜单项
-- 检查是否已存在ID为1012的记录
INSERT INTO menu (id, user_type_ids, pid, name, title)
SELECT 1012, '1,2,3', 1, 'activity-panel', '活动管理'
WHERE NOT EXISTS (SELECT 1 FROM menu WHERE id = 1012);

-- 添加数据字典：活动类型
INSERT INTO dictionary_info (code, label, value, order_num, remark)
SELECT 'HDLX', '体育活动', '1', 1, '活动类型-体育活动'
WHERE NOT EXISTS (SELECT 1 FROM dictionary_info WHERE code = 'HDLX' AND value = '1');

INSERT INTO dictionary_info (code, label, value, order_num, remark)
SELECT 'HDLX', '外出旅游', '2', 2, '活动类型-外出旅游'
WHERE NOT EXISTS (SELECT 1 FROM dictionary_info WHERE code = 'HDLX' AND value = '2');

INSERT INTO dictionary_info (code, label, value, order_num, remark)
SELECT 'HDLX', '文艺演出', '3', 3, '活动类型-文艺演出'
WHERE NOT EXISTS (SELECT 1 FROM dictionary_info WHERE code = 'HDLX' AND value = '3');

INSERT INTO dictionary_info (code, label, value, order_num, remark)
SELECT 'HDLX', '聚会', '4', 4, '活动类型-聚会'
WHERE NOT EXISTS (SELECT 1 FROM dictionary_info WHERE code = 'HDLX' AND value = '4');

INSERT INTO dictionary_info (code, label, value, order_num, remark)
SELECT 'HDLX', '其他', '9', 9, '活动类型-其他'
WHERE NOT EXISTS (SELECT 1 FROM dictionary_info WHERE code = 'HDLX' AND value = '9');

-- 添加数据字典：活动状态
INSERT INTO dictionary_info (code, label, value, order_num, remark)
SELECT 'HDZT', '未开始', '1', 1, '活动状态-未开始'
WHERE NOT EXISTS (SELECT 1 FROM dictionary_info WHERE code = 'HDZT' AND value = '1');

INSERT INTO dictionary_info (code, label, value, order_num, remark)
SELECT 'HDZT', '进行中', '2', 2, '活动状态-进行中'
WHERE NOT EXISTS (SELECT 1 FROM dictionary_info WHERE code = 'HDZT' AND value = '2');

INSERT INTO dictionary_info (code, label, value, order_num, remark)
SELECT 'HDZT', '已结束', '3', 3, '活动状态-已结束'
WHERE NOT EXISTS (SELECT 1 FROM dictionary_info WHERE code = 'HDZT' AND value = '3');

INSERT INTO dictionary_info (code, label, value, order_num, remark)
SELECT 'HDZT', '已取消', '4', 4, '活动状态-已取消'
WHERE NOT EXISTS (SELECT 1 FROM dictionary_info WHERE code = 'HDZT' AND value = '4'); 