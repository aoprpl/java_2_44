package cn.edu.sdu.java.server.controllers;

import cn.edu.sdu.java.server.payload.request.DataRequest;
import cn.edu.sdu.java.server.payload.response.DataResponse;
import cn.edu.sdu.java.server.services.LeaveService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/leave")
public class LeaveController {
    
    @Autowired
    private LeaveService leaveService;
    
    /**
     * 获取请假列表
     */
    @PostMapping("/list")
    public DataResponse getLeaveList(@RequestBody DataRequest dataRequest) {
        return leaveService.getLeaveList(dataRequest);
    }
    
    /**
     * 获取请假详情
     */
    @PostMapping("/info")
    public DataResponse getLeaveInfo(@RequestBody DataRequest dataRequest) {
        return leaveService.getLeaveInfo(dataRequest);
    }
    
    /**
     * 添加或编辑请假
     */
    @PostMapping("/edit")
    public DataResponse leaveEdit(@RequestBody DataRequest dataRequest) {
        return leaveService.leaveEdit(dataRequest);
    }
    
    /**
     * 删除请假
     */
    @PostMapping("/delete")
    public DataResponse deleteLeave(@RequestBody DataRequest dataRequest) {
        return leaveService.deleteLeave(dataRequest);
    }
    
    /**
     * 审批请假
     */
    @PostMapping("/approve")
    public DataResponse approveLeave(@RequestBody DataRequest dataRequest) {
        return leaveService.approveLeave(dataRequest);
    }
} 