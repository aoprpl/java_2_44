package cn.edu.sdu.java.server.repositorys;

import cn.edu.sdu.java.server.models.ModifyLog;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ModifyLogRepository extends JpaRepository<ModifyLog,Integer>{

}
