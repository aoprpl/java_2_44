package cn.edu.sdu.java.server.controllers;

import cn.edu.sdu.java.server.payload.request.DataRequest;
import cn.edu.sdu.java.server.payload.response.DataResponse;
import cn.edu.sdu.java.server.services.TeacherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/teacher")
public class TeacherController {
    @Autowired
    private TeacherService teacherService;

    @PostMapping("/list")
    public DataResponse getTeacherList(@RequestBody DataRequest dataRequest) {
        return teacherService.getTeacherList(dataRequest);
    }

    @PostMapping("/edit")
    public DataResponse teacherEdit(@RequestBody DataRequest dataRequest) {
        return teacherService.teacherEdit(dataRequest);
    }

    @PostMapping("/delete")
    public DataResponse teacherDelete(@RequestBody DataRequest dataRequest) {
        return teacherService.teacherDelete(dataRequest);
    }

    @PostMapping("/info")
    public DataResponse getTeacherInfo(@RequestBody DataRequest dataRequest) {
        return teacherService.getTeacherInfo(dataRequest);
    }
}
