package cn.edu.sdu.java.server.repositorys;

import cn.edu.sdu.java.server.models.Innovation;
import cn.edu.sdu.java.server.models.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface InnovationRepository extends JpaRepository<Innovation, Integer> {
    
    @Query("SELECT i FROM Innovation i WHERE i.student = :student")
    List<Innovation> findInnovationsByStudent(@Param("student") Student student);
    
    List<Innovation> findByInnovationType(String innovationType);
    
    List<Innovation> findByLevel(String level);
    
    List<Innovation> findByStatus(String status);
    
    @Query("SELECT i FROM Innovation i WHERE i.achieveTime BETWEEN :startDate AND :endDate")
    List<Innovation> findInnovationsBetweenDates(@Param("startDate") LocalDateTime startDate, @Param("endDate") LocalDateTime endDate);
    
    @Query("SELECT i FROM Innovation i WHERE i.student.person.name LIKE %:keyword% OR i.student.person.num LIKE %:keyword% OR i.name LIKE %:keyword% OR i.description LIKE %:keyword% OR i.organization LIKE %:keyword%")
    List<Innovation> findByKeyword(@Param("keyword") String keyword);
    
    @Query("SELECT i FROM Innovation i WHERE (:keyword IS NULL OR i.student.person.name LIKE %:keyword% OR i.student.person.num LIKE %:keyword% OR i.name LIKE %:keyword% OR i.description LIKE %:keyword%) AND (:innovationType IS NULL OR i.innovationType = :innovationType) AND (:level IS NULL OR i.level = :level) AND (:status IS NULL OR i.status = :status)")
    List<Innovation> findByFilters(@Param("keyword") String keyword, @Param("innovationType") String innovationType, @Param("level") String level, @Param("status") String status);
} 