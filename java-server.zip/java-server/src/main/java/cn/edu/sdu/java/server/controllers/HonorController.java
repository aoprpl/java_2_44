package cn.edu.sdu.java.server.controllers;

import cn.edu.sdu.java.server.payload.request.DataRequest;
import cn.edu.sdu.java.server.payload.response.DataResponse;
import cn.edu.sdu.java.server.services.HonorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/honor")
public class HonorController {
    
    @Autowired
    private HonorService honorService;
    
    /**
     * 获取荣誉列表
     */
    @PostMapping("/list")
    public DataResponse getHonorList(@RequestBody DataRequest dataRequest) {
        return honorService.getHonorList(dataRequest);
    }
    
    /**
     * 获取荣誉详情
     */
    @PostMapping("/info")
    public DataResponse getHonorInfo(@RequestBody DataRequest dataRequest) {
        return honorService.getHonorInfo(dataRequest);
    }
    
    /**
     * 添加或编辑荣誉
     */
    @PostMapping("/edit")
    public DataResponse honorEdit(@RequestBody DataRequest dataRequest) {
        return honorService.honorEdit(dataRequest);
    }
    
    /**
     * 删除荣誉
     */
    @PostMapping("/delete")
    public DataResponse deleteHonor(@RequestBody DataRequest dataRequest) {
        return honorService.deleteHonor(dataRequest);
    }
} 