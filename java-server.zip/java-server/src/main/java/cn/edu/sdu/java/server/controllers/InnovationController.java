package cn.edu.sdu.java.server.controllers;

import cn.edu.sdu.java.server.payload.request.DataRequest;
import cn.edu.sdu.java.server.payload.response.DataResponse;
import cn.edu.sdu.java.server.payload.response.OptionItemList;
import cn.edu.sdu.java.server.services.InnovationService;
import cn.edu.sdu.java.server.util.CommonMethod;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/innovation")
public class InnovationController {
    
    @Autowired
    private InnovationService innovationService;
    
    /**
     * 获取创新成就列表
     */
    @PostMapping("/list")
    public DataResponse getInnovationList(@RequestBody DataRequest dataRequest) {
        return innovationService.getInnovationList(dataRequest);
    }
    
    /**
     * 获取创新成就详情
     */
    @PostMapping("/info")
    public DataResponse getInnovationInfo(@RequestBody DataRequest dataRequest) {
        return innovationService.getInnovationInfo(dataRequest);
    }
    
    /**
     * 添加或编辑创新成就
     */
    @PostMapping("/edit")
    public DataResponse innovationEdit(@RequestBody DataRequest dataRequest) {
        return innovationService.innovationEdit(dataRequest);
    }
    
    /**
     * 删除创新成就
     */
    @PostMapping("/delete")
    public DataResponse deleteInnovation(@RequestBody DataRequest dataRequest) {
        return innovationService.deleteInnovation(dataRequest);
    }
    
    /**
     * 审批创新成就
     */
    @PostMapping("/approve")
    public DataResponse approveInnovation(@RequestBody DataRequest dataRequest) {
        return innovationService.approveInnovation(dataRequest);
    }
    
    /**
     * 获取学生创新成就统计
     */
    @PostMapping("/statistics")
    public DataResponse getStudentInnovationStatistics(@RequestBody DataRequest dataRequest) {
        return innovationService.getStudentInnovationStatistics(dataRequest);
    }

    @PostMapping("/getStudentItemOptionList")
    public OptionItemList getStudentItemOptionList(@Valid @RequestBody DataRequest dataRequest) {
        return innovationService.getStudentItemOptionList(dataRequest);
    }
} 