package cn.edu.sdu.java.server.repositorys;

import cn.edu.sdu.java.server.models.Honor;
import cn.edu.sdu.java.server.models.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface HonorRepository extends JpaRepository<Honor, Integer> {
    
    @Query("SELECT h FROM Honor h WHERE h.title LIKE %:keyword% OR h.description LIKE %:keyword% OR h.student.person.name LIKE %:keyword% OR h.student.person.num LIKE %:keyword%")
    List<Honor> findByTitleOrDescriptionOrStudentContaining(@Param("keyword") String keyword);
    
    List<Honor> findByHonorType(String honorType);
    
    List<Honor> findByLevel(String level);
    
    List<Honor> findByAwardDateBetween(LocalDate startDate, LocalDate endDate);
    
    @Query("SELECT h FROM Honor h WHERE h.student = :student")
    List<Honor> findHonorsByStudent(@Param("student") Student student);
    
    @Query("SELECT h FROM Honor h WHERE h.issuer LIKE %:issuer%")
    List<Honor> findByIssuerContaining(@Param("issuer") String issuer);
    
    @Query("SELECT h FROM Honor h WHERE h.honorType = :type AND h.level = :level")
    List<Honor> findByTypeAndLevel(@Param("type") String type, @Param("level") String level);

    @Query("SELECT h FROM Honor h WHERE (:keyword IS NULL OR h.title LIKE %:keyword% OR h.description LIKE %:keyword% OR h.student.person.name LIKE %:keyword% OR h.student.person.num LIKE %:keyword%) AND (:honorType IS NULL OR h.honorType = :honorType)")
    List<Honor> findByKeywordAndType(@Param("keyword") String keyword, @Param("honorType") String honorType);
} 