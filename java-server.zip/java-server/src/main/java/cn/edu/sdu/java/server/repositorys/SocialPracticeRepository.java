package cn.edu.sdu.java.server.repositorys;

import cn.edu.sdu.java.server.models.SocialPractice;
import cn.edu.sdu.java.server.models.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface SocialPracticeRepository extends JpaRepository<SocialPractice, Integer> {
    
    @Query("SELECT p FROM SocialPractice p WHERE p.practiceName LIKE %:keyword% OR p.practiceContent LIKE %:keyword% OR p.student.person.name LIKE %:keyword% OR p.student.person.num LIKE %:keyword%")
    List<SocialPractice> findByKeyword(@Param("keyword") String keyword);
    
    List<SocialPractice> findByStatus(String status);
    
    List<SocialPractice> findByStartTimeBetween(LocalDateTime startTime, LocalDateTime endTime);
    
    @Query("SELECT p FROM SocialPractice p WHERE p.student = :student")
    List<SocialPractice> findPracticesByStudent(@Param("student") Student student);
    
    @Query("SELECT p FROM SocialPractice p WHERE p.practiceLocation LIKE %:location%")
    List<SocialPractice> findByLocationContaining(@Param("location") String location);
    
    @Query("SELECT p FROM SocialPractice p WHERE (:keyword IS NULL OR p.practiceName LIKE %:keyword% OR p.practiceContent LIKE %:keyword% OR p.student.person.name LIKE %:keyword% OR p.student.person.num LIKE %:keyword%) AND (:status IS NULL OR p.status = :status)")
    List<SocialPractice> findByKeywordAndStatus(@Param("keyword") String keyword, @Param("status") String status);
} 