package cn.edu.sdu.java.server.repositorys;

import cn.edu.sdu.java.server.models.Teacher;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface TeacherRepository extends JpaRepository<Teacher, Integer> {
    
    @Query("SELECT t FROM Teacher t WHERE t.person.num LIKE %:numName% OR t.person.name LIKE %:numName%")
    List<Teacher> findTeacherListByNumName(@Param("numName") String numName);

    Optional<Teacher> findByPersonNum(String num);

    boolean existsByPersonNum(String num);

    @Query("SELECT t FROM Teacher t WHERE t.status = :status")
    List<Teacher> findByStatus(@Param("status") String status);

    @Query("SELECT t FROM Teacher t WHERE t.title = :title")
    List<Teacher> findByTitle(@Param("title") String title);

    Optional<Teacher> findByPersonPersonId(Integer personId);

    List<Teacher> findByPersonName(String name);
}
