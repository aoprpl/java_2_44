package cn.edu.sdu.java.server.services;

import cn.edu.sdu.java.server.models.Innovation;
import cn.edu.sdu.java.server.models.Student;
import cn.edu.sdu.java.server.payload.request.DataRequest;
import cn.edu.sdu.java.server.payload.response.DataResponse;
import cn.edu.sdu.java.server.repositorys.InnovationRepository;
import cn.edu.sdu.java.server.repositorys.StudentRepository;
import cn.edu.sdu.java.server.util.CommonMethod;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class InnovationService {
    private final InnovationRepository innovationRepository;
    private final StudentRepository studentRepository;
    private final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public InnovationService(InnovationRepository innovationRepository, StudentRepository studentRepository) {
        this.innovationRepository = innovationRepository;
        this.studentRepository = studentRepository;
    }

    /**
     * 将Innovation对象转换为Map
     */
    public Map<String, Object> getMapFromInnovation(Innovation innovation) {
        Map<String, Object> map = new HashMap<>();
        if (innovation == null) {
            return map;
        }
        
        map.put("innovationId", innovation.getInnovationId());
        map.put("innovationType", innovation.getInnovationType());
        map.put("name", innovation.getName());
        map.put("description", innovation.getDescription());
        map.put("achieveTime", innovation.getAchieveTime() != null ? innovation.getAchieveTime().format(dateTimeFormatter) : null);
        map.put("level", innovation.getLevel());
        map.put("organization", innovation.getOrganization());
        map.put("certificateNumber", innovation.getCertificateNumber());
        map.put("status", innovation.getStatus());
        map.put("approver", innovation.getApprover());
        map.put("approveTime", innovation.getApproveTime() != null ? innovation.getApproveTime().format(dateTimeFormatter) : null);
        map.put("approveComment", innovation.getApproveComment());
        
        // 添加学生信息
        if (innovation.getStudent() != null) {
            Map<String, Object> studentMap = new HashMap<>();
            studentMap.put("personId", innovation.getStudent().getPersonId());
            if (innovation.getStudent().getPerson() != null) {
                studentMap.put("name", innovation.getStudent().getPerson().getName());
                studentMap.put("num", innovation.getStudent().getPerson().getNum());
                studentMap.put("className", innovation.getStudent().getClassName());
            }
            map.put("student", studentMap);
        }
        
        return map;
    }

    /**
     * 获取创新成就列表
     */
    public DataResponse getInnovationList(DataRequest dataRequest) {
        String keyword = dataRequest.getString("keyword");
        String innovationType = dataRequest.getString("innovationType");
        String level = dataRequest.getString("level");
        String status = dataRequest.getString("status");
        
        List<Innovation> innovations;
        if (keyword != null || innovationType != null || level != null || status != null) {
            innovations = innovationRepository.findByFilters(keyword, innovationType, level, status);
        } else {
            innovations = innovationRepository.findAll();
        }
        
        List<Map<String, Object>> dataList = innovations.stream()
                .map(this::getMapFromInnovation)
                .collect(Collectors.toList());
        
        return CommonMethod.getReturnData(dataList);
    }

    /**
     * 获取创新成就详情
     */
    public DataResponse getInnovationInfo(DataRequest dataRequest) {
        Integer innovationId = dataRequest.getInteger("innovationId");
        if (innovationId == null) {
            return CommonMethod.getReturnMessageError("创新成就ID不能为空");
        }
        
        Optional<Innovation> optionalInnovation = innovationRepository.findById(innovationId);
        if (optionalInnovation.isEmpty()) {
            return CommonMethod.getReturnMessageError("找不到该创新成就记录");
        }
        
        return CommonMethod.getReturnData(getMapFromInnovation(optionalInnovation.get()));
    }

    /**
     * 添加或编辑创新成就
     */
    @Transactional
    public DataResponse innovationEdit(DataRequest dataRequest) {
        Integer innovationId = dataRequest.getInteger("innovationId");
        Map<String, Object> form = dataRequest.getMap("form");
        
        Innovation innovation;
        if (innovationId != null && innovationId > 0) {
            // 编辑现有创新成就
            Optional<Innovation> optionalInnovation = innovationRepository.findById(innovationId);
            if (optionalInnovation.isEmpty()) {
                return CommonMethod.getReturnMessageError("找不到该创新成就记录");
            }
            innovation = optionalInnovation.get();
        } else {
            // 添加新创新成就
            innovation = new Innovation();
            // 新创新成就默认为待审批状态
            innovation.setStatus("1"); // 假设 1 表示"待审批"
        }
        
        // 设置创新成就字段
        innovation.setInnovationType(CommonMethod.getString(form, "innovationType"));
        innovation.setName(CommonMethod.getString(form, "name"));
        innovation.setDescription(CommonMethod.getString(form, "description"));
        
        String achieveTimeStr = CommonMethod.getString(form, "achieveTime");
        if (achieveTimeStr != null && !achieveTimeStr.isEmpty()) {
            innovation.setAchieveTime(LocalDateTime.parse(achieveTimeStr, dateTimeFormatter));
        } else {
            innovation.setAchieveTime(LocalDateTime.now());
        }
        
        innovation.setLevel(CommonMethod.getString(form, "level"));
        innovation.setOrganization(CommonMethod.getString(form, "organization"));
        innovation.setCertificateNumber(CommonMethod.getString(form, "certificateNumber"));
        
        // 如果状态被修改，更新审批相关信息
        String newStatus = CommonMethod.getString(form, "status");
        if (newStatus != null && !newStatus.equals(innovation.getStatus())) {
            innovation.setStatus(newStatus);
            innovation.setApprover(CommonMethod.getString(form, "approver"));
            innovation.setApproveComment(CommonMethod.getString(form, "approveComment"));
            innovation.setApproveTime(LocalDateTime.now()); // 设置当前时间为审批时间
        }
        
        // 处理学生关联
        Integer studentId = CommonMethod.getInteger(form, "studentId");
        if (studentId != null) {
            Optional<Student> optionalStudent = studentRepository.findById(studentId);
            if (optionalStudent.isPresent()) {
                innovation.setStudent(optionalStudent.get());
            } else {
                return CommonMethod.getReturnMessageError("找不到ID为" + studentId + "的学生");
            }
        } else {
            return CommonMethod.getReturnMessageError("学生ID不能为空");
        }
        
        innovationRepository.save(innovation);
        return CommonMethod.getReturnData(innovation.getInnovationId());
    }

    /**
     * 删除创新成就
     */
    @Transactional
    public DataResponse deleteInnovation(DataRequest dataRequest) {
        Integer innovationId = dataRequest.getInteger("innovationId");
        if (innovationId == null || innovationId <= 0) {
            return CommonMethod.getReturnMessageError("创新成就ID不能为空");
        }
        
        Optional<Innovation> optionalInnovation = innovationRepository.findById(innovationId);
        if (optionalInnovation.isEmpty()) {
            return CommonMethod.getReturnMessageError("找不到该创新成就记录");
        }
        
        // 删除创新成就记录
        innovationRepository.deleteById(innovationId);
        return CommonMethod.getReturnMessageOK();
    }
    
    /**
     * 审批创新成就
     */
    @Transactional
    public DataResponse approveInnovation(DataRequest dataRequest) {
        Integer innovationId = dataRequest.getInteger("innovationId");
        String status = dataRequest.getString("status");
        String approver = dataRequest.getString("approver");
        String approveComment = dataRequest.getString("approveComment");
        
        if (innovationId == null || status == null) {
            return CommonMethod.getReturnMessageError("创新成就ID和审批状态不能为空");
        }
        
        Optional<Innovation> optionalInnovation = innovationRepository.findById(innovationId);
        if (optionalInnovation.isEmpty()) {
            return CommonMethod.getReturnMessageError("找不到该创新成就记录");
        }
        
        Innovation innovation = optionalInnovation.get();
        innovation.setStatus(status);
        innovation.setApprover(approver);
        innovation.setApproveComment(approveComment);
        innovation.setApproveTime(LocalDateTime.now());
        
        innovationRepository.save(innovation);
        return CommonMethod.getReturnMessageOK();
    }
    
    /**
     * 获取学生创新成就统计
     */
    public DataResponse getStudentInnovationStatistics(DataRequest dataRequest) {
        Integer studentId = dataRequest.getInteger("studentId");
        if (studentId == null) {
            return CommonMethod.getReturnMessageError("学生ID不能为空");
        }
        
        Optional<Student> optionalStudent = studentRepository.findById(studentId);
        if (optionalStudent.isEmpty()) {
            return CommonMethod.getReturnMessageError("找不到该学生");
        }
        
        Student student = optionalStudent.get();
        List<Innovation> innovations = innovationRepository.findInnovationsByStudent(student);
        
        // 按类型分组统计
        Map<String, Integer> countByType = new HashMap<>();
        Map<String, Integer> countByLevel = new HashMap<>();
        
        for (Innovation innovation : innovations) {
            String type = innovation.getInnovationType();
            String level = innovation.getLevel();
            
            if (type != null) {
                countByType.put(type, countByType.getOrDefault(type, 0) + 1);
            }
            
            if (level != null) {
                countByLevel.put(level, countByLevel.getOrDefault(level, 0) + 1);
            }
        }
        
        Map<String, Object> result = new HashMap<>();
        result.put("studentId", studentId);
        result.put("studentName", student.getPerson() != null ? student.getPerson().getName() : "");
        result.put("totalCount", innovations.size());
        result.put("countByType", countByType);
        result.put("countByLevel", countByLevel);
        
        return CommonMethod.getReturnData(result);
    }
} 