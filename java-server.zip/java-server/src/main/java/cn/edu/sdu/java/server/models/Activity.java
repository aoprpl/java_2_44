package cn.edu.sdu.java.server.models;

import jakarta.persistence.*;
import jakarta.validation.constraints.Size;
import java.time.LocalDateTime;
import java.util.Set;

/**
 * Activity 学生活动表实体类，保存学生体育活动、外出旅游、文艺演出、聚会等日常活动信息
 */
@Entity
@Table(name = "activity")
public class Activity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer activityId;

    @Size(max = 20)
    private String activityType;  // 活动类型：体育活动、外出旅游、文艺演出、聚会等

    @Size(max = 100)
    private String name;  // 活动名称

    @Size(max = 500)
    private String description;  // 活动描述

    private LocalDateTime startTime;  // 开始时间

    private LocalDateTime endTime;  // 结束时间

    @Size(max = 100)
    private String location;  // 活动地点

    @Size(max = 50)
    private String organizer;  // 组织者

    @Size(max = 20)
    private String status;  // 活动状态：未开始、进行中、已结束等

    @ManyToMany
    @JoinTable(
            name = "activity_student",
            joinColumns = @JoinColumn(name = "activity_id"),
            inverseJoinColumns = @JoinColumn(name = "student_id")
    )
    private Set<Student> participants;  // 参与活动的学生

    // Getters and Setters
    public Integer getActivityId() {
        return activityId;
    }

    public void setActivityId(Integer activityId) {
        this.activityId = activityId;
    }

    public String getActivityType() {
        return activityType;
    }

    public void setActivityType(String activityType) {
        this.activityType = activityType;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getOrganizer() {
        return organizer;
    }

    public void setOrganizer(String organizer) {
        this.organizer = organizer;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Set<Student> getParticipants() {
        return participants;
    }

    public void setParticipants(Set<Student> participants) {
        this.participants = participants;
    }
} 