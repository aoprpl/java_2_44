package cn.edu.sdu.java.server.models;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

/**
 * Leave 学生请假表实体类，保存学生请假、外出等信息
 */
@Entity
@Table(name = "leaves")
@Data
@NoArgsConstructor
public class Leave {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long leaveId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "student_id", nullable = false)
    private Student student;  // 请假学生

    @Column(name = "leave_type", nullable = false)
    private String leaveType;  // 请假类型：事假、病假、外出等

    @Column(name = "start_time", nullable = false)
    private LocalDateTime startTime;  // 请假开始时间

    @Column(name = "end_time", nullable = false)
    private LocalDateTime endTime;    // 请假结束时间

    @Column(name = "destination")
    private String destination;  // 目的地/去向

    @Column(name = "contact")
    private String contact;  // 请假期间联系方式

    @Column(name = "reason", nullable = false)
    private String reason;   // 请假原因

    @Column(name = "status", nullable = false)
    private String status;   // 请假状态：待审批、已批准、已拒绝、已销假

    @Column(name = "approver")
    private String approver; // 审批人

    @Column(name = "approve_time")
    private LocalDateTime approveTime; // 审批时间

    @Column(name = "approve_comment")
    private String approveComment; // 审批意见

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    // Getters and Setters
    public Long getLeaveId() {
        return leaveId;
    }

    public void setLeaveId(Long leaveId) {
        this.leaveId = leaveId;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public String getLeaveType() {
        return leaveType;
    }

    public void setLeaveType(String leaveType) {
        this.leaveType = leaveType;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getApprover() {
        return approver;
    }

    public void setApprover(String approver) {
        this.approver = approver;
    }

    public LocalDateTime getApproveTime() {
        return approveTime;
    }

    public void setApproveTime(LocalDateTime approveTime) {
        this.approveTime = approveTime;
    }

    public String getApproveComment() {
        return approveComment;
    }

    public void setApproveComment(String approveComment) {
        this.approveComment = approveComment;
    }
} 