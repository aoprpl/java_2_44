package cn.edu.sdu.java.server.controllers;

import cn.edu.sdu.java.server.payload.request.DataRequest;
import cn.edu.sdu.java.server.payload.response.DataResponse;
import cn.edu.sdu.java.server.services.SocialPracticeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/social-practice")
public class SocialPracticeController {
    
    @Autowired
    private SocialPracticeService socialPracticeService;
    
    /**
     * 获取社会实践列表
     */
    @PostMapping("/list")
    public DataResponse getPracticeList(@RequestBody DataRequest dataRequest) {
        return socialPracticeService.getPracticeList(dataRequest);
    }
    
    /**
     * 获取社会实践详情
     */
    @PostMapping("/info")
    public DataResponse getPracticeInfo(@RequestBody DataRequest dataRequest) {
        return socialPracticeService.getPracticeInfo(dataRequest);
    }
    
    /**
     * 添加或编辑社会实践
     */
    @PostMapping("/edit")
    public DataResponse practiceEdit(@RequestBody DataRequest dataRequest) {
        return socialPracticeService.practiceEdit(dataRequest);
    }
    
    /**
     * 删除社会实践
     */
    @PostMapping("/delete")
    public DataResponse deletePractice(@RequestBody DataRequest dataRequest) {
        return socialPracticeService.deletePractice(dataRequest);
    }
} 