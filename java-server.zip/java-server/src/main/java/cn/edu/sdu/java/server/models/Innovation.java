package cn.edu.sdu.java.server.models;

import jakarta.persistence.*;
import jakarta.validation.constraints.Size;
import java.time.LocalDateTime;

/**
 * Innovation 学生创新成就表实体类，保存学生创新项目、比赛、专利等信息
 */
@Entity
@Table(name = "student_innovation")
public class Innovation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer innovationId;

    @ManyToOne
    @JoinColumn(name = "student_id")
    private Student student;  // 学生

    @Size(max = 20)
    private String innovationType;  // 创新类型：项目、竞赛、专利、论文等

    @Size(max = 100)
    private String name;  // 创新成就名称

    @Size(max = 500)
    private String description;  // 创新成就描述

    private LocalDateTime achieveTime;  // 获得时间

    @Size(max = 20)
    private String level;  // 成就级别：国家级、省级、市级、校级等

    @Size(max = 100)
    private String organization;  // 主办单位/获奖单位

    @Size(max = 100)
    private String certificateNumber;  // 证书编号

    @Size(max = 20)
    private String status;   // 审批状态：待审批、已批准、已拒绝

    @Size(max = 50)
    private String approver; // 审批人

    private LocalDateTime approveTime; // 审批时间

    @Size(max = 200)
    private String approveComment; // 审批意见

    @Size(max = 50)
    private String teacher; // 指导老师

    // Getters and Setters
    public Integer getInnovationId() {
        return innovationId;
    }

    public void setInnovationId(Integer innovationId) {
        this.innovationId = innovationId;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public String getInnovationType() {
        return innovationType;
    }

    public void setInnovationType(String innovationType) {
        this.innovationType = innovationType;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDateTime getAchieveTime() {
        return achieveTime;
    }

    public void setAchieveTime(LocalDateTime achieveTime) {
        this.achieveTime = achieveTime;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getOrganization() {
        return organization;
    }

    public void setOrganization(String organization) {
        this.organization = organization;
    }

    public String getCertificateNumber() {
        return certificateNumber;
    }

    public void setCertificateNumber(String certificateNumber) {
        this.certificateNumber = certificateNumber;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getApprover() {
        return approver;
    }

    public void setApprover(String approver) {
        this.approver = approver;
    }

    public LocalDateTime getApproveTime() {
        return approveTime;
    }

    public void setApproveTime(LocalDateTime approveTime) {
        this.approveTime = approveTime;
    }

    public String getApproveComment() {
        return approveComment;
    }

    public void setApproveComment(String approveComment) {
        this.approveComment = approveComment;
    }

    public String getTeacher() {
        return teacher;
    }

    public void setTeacher(String teacher) {
        this.teacher = teacher;
    }
} 