package cn.edu.sdu.java.server.controllers;

import cn.edu.sdu.java.server.payload.request.DataRequest;
import cn.edu.sdu.java.server.payload.response.DataResponse;
import cn.edu.sdu.java.server.services.ActivityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/activity")
public class ActivityController {
    
    @Autowired
    private ActivityService activityService;
    
    /**
     * 获取活动列表
     */
    @PostMapping("/list")
    public DataResponse getActivityList(@RequestBody DataRequest dataRequest) {
        return activityService.getActivityList(dataRequest);
    }
    
    /**
     * 获取活动详情
     */
    @PostMapping("/info")
    public DataResponse getActivityInfo(@RequestBody DataRequest dataRequest) {
        return activityService.getActivityInfo(dataRequest);
    }
    
    /**
     * 添加或编辑活动
     */
    @PostMapping("/edit")
    public DataResponse activityEdit(@RequestBody DataRequest dataRequest) {
        return activityService.activityEdit(dataRequest);
    }
    
    /**
     * 删除活动
     */
    @PostMapping("/delete")
    public DataResponse deleteActivity(@RequestBody DataRequest dataRequest) {
        return activityService.deleteActivity(dataRequest);
    }
    
    /**
     * 添加学生到活动
     */
    @PostMapping("/addStudent")
    public DataResponse addStudentToActivity(@RequestBody DataRequest dataRequest) {
        return activityService.addStudentToActivity(dataRequest);
    }
    
    /**
     * 从活动中移除学生
     */
    @PostMapping("/removeStudent")
    public DataResponse removeStudentFromActivity(@RequestBody DataRequest dataRequest) {
        return activityService.removeStudentFromActivity(dataRequest);
    }
} 