package cn.edu.sdu.java.server.services;

import cn.edu.sdu.java.server.models.Leave;
import cn.edu.sdu.java.server.models.Student;
import cn.edu.sdu.java.server.payload.request.DataRequest;
import cn.edu.sdu.java.server.payload.response.DataResponse;
import cn.edu.sdu.java.server.repositorys.LeaveRepository;
import cn.edu.sdu.java.server.repositorys.StudentRepository;
import cn.edu.sdu.java.server.util.CommonMethod;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class LeaveService {
    private final LeaveRepository leaveRepository;
    private final StudentRepository studentRepository;
    private final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public LeaveService(LeaveRepository leaveRepository, StudentRepository studentRepository) {
        this.leaveRepository = leaveRepository;
        this.studentRepository = studentRepository;
    }

    /**
     * 将Leave对象转换为Map
     */
    public Map<String, Object> getMapFromLeave(Leave leave) {
        Map<String, Object> map = new HashMap<>();
        if (leave == null) {
            return map;
        }
        
        map.put("leaveId", leave.getLeaveId());
        map.put("leaveType", leave.getLeaveType());
        map.put("startTime", leave.getStartTime() != null ? leave.getStartTime().format(dateTimeFormatter) : null);
        map.put("endTime", leave.getEndTime() != null ? leave.getEndTime().format(dateTimeFormatter) : null);
        map.put("destination", leave.getDestination());
        map.put("contact", leave.getContact());
        map.put("reason", leave.getReason());
        map.put("status", leave.getStatus());
        map.put("approver", leave.getApprover());
        map.put("approveTime", leave.getApproveTime() != null ? leave.getApproveTime().format(dateTimeFormatter) : null);
        map.put("approveComment", leave.getApproveComment());
        
        // 添加学生信息
        if (leave.getStudent() != null) {
            Map<String, Object> studentMap = new HashMap<>();
            studentMap.put("personId", leave.getStudent().getPersonId());
            if (leave.getStudent().getPerson() != null) {
                studentMap.put("name", leave.getStudent().getPerson().getName());
                studentMap.put("num", leave.getStudent().getPerson().getNum());
                studentMap.put("className", leave.getStudent().getClassName());
            }
            map.put("student", studentMap);
        }
        
        return map;
    }

    /**
     * 获取请假列表
     */
    public DataResponse getLeaveList(DataRequest dataRequest) {
        String keyword = dataRequest.getString("keyword");
        String leaveType = dataRequest.getString("leaveType");
        String status = dataRequest.getString("status");
        
        List<Leave> leaves;
        if (keyword != null || leaveType != null || status != null) {
            leaves = leaveRepository.findByKeywordAndTypeAndStatus(keyword, leaveType, status);
        } else {
            leaves = leaveRepository.findAll();
        }
        
        List<Map<String, Object>> dataList = leaves.stream()
                .map(this::getMapFromLeave)
                .collect(Collectors.toList());
        
        return CommonMethod.getReturnData(dataList);
    }

    /**
     * 获取请假详情
     */
    public DataResponse getLeaveInfo(DataRequest dataRequest) {
        Integer leaveId = dataRequest.getInteger("leaveId");
        if (leaveId == null) {
            return CommonMethod.getReturnMessageError("请假ID不能为空");
        }
        
        Optional<Leave> optionalLeave = leaveRepository.findById(leaveId);
        if (optionalLeave.isEmpty()) {
            return CommonMethod.getReturnMessageError("找不到该请假记录");
        }
        
        return CommonMethod.getReturnData(getMapFromLeave(optionalLeave.get()));
    }

    /**
     * 添加或编辑请假记录
     */
    @Transactional
    public DataResponse leaveEdit(DataRequest dataRequest) {
        Integer leaveId = dataRequest.getInteger("leaveId");
        Map<String, Object> form = dataRequest.getMap("form");
        
        Leave leave;
        if (leaveId != null && leaveId > 0) {
            // 编辑现有请假记录
            Optional<Leave> optionalLeave = leaveRepository.findById(leaveId);
            if (optionalLeave.isEmpty()) {
                return CommonMethod.getReturnMessageError("找不到该请假记录");
            }
            leave = optionalLeave.get();
        } else {
            // 添加新请假记录
            leave = new Leave();
            // 新请假默认为待审批状态
            leave.setStatus("1"); // 假设 1 表示"待审批"
        }
        
        // 设置请假记录字段
        leave.setLeaveType(CommonMethod.getString(form, "leaveType"));
        
        String startTimeStr = CommonMethod.getString(form, "startTime");
        if (startTimeStr != null && !startTimeStr.isEmpty()) {
            leave.setStartTime(LocalDateTime.parse(startTimeStr, dateTimeFormatter));
        }
        
        String endTimeStr = CommonMethod.getString(form, "endTime");
        if (endTimeStr != null && !endTimeStr.isEmpty()) {
            leave.setEndTime(LocalDateTime.parse(endTimeStr, dateTimeFormatter));
        }
        
        leave.setDestination(CommonMethod.getString(form, "destination"));
        leave.setContact(CommonMethod.getString(form, "contact"));
        leave.setReason(CommonMethod.getString(form, "reason"));
        
        // 如果状态被修改，更新审批相关信息
        String newStatus = CommonMethod.getString(form, "status");
        if (newStatus != null && !newStatus.equals(leave.getStatus())) {
            leave.setStatus(newStatus);
            leave.setApprover(CommonMethod.getString(form, "approver"));
            leave.setApproveComment(CommonMethod.getString(form, "approveComment"));
            leave.setApproveTime(LocalDateTime.now()); // 设置当前时间为审批时间
        }
        
        // 处理学生关联
        Integer studentId = CommonMethod.getInteger(form, "studentId");
        if (studentId != null) {
            Optional<Student> optionalStudent = studentRepository.findById(studentId);
            if (optionalStudent.isPresent()) {
                leave.setStudent(optionalStudent.get());
            } else {
                return CommonMethod.getReturnMessageError("找不到ID为" + studentId + "的学生");
            }
        } else {
            return CommonMethod.getReturnMessageError("学生ID不能为空");
        }
        
        leaveRepository.save(leave);
        return CommonMethod.getReturnData(leave.getLeaveId());
    }

    /**
     * 删除请假记录
     */
    @Transactional
    public DataResponse deleteLeave(DataRequest dataRequest) {
        Integer leaveId = dataRequest.getInteger("leaveId");
        if (leaveId == null || leaveId <= 0) {
            return CommonMethod.getReturnMessageError("请假ID不能为空");
        }
        
        Optional<Leave> optionalLeave = leaveRepository.findById(leaveId);
        if (optionalLeave.isEmpty()) {
            return CommonMethod.getReturnMessageError("找不到该请假记录");
        }
        
        // 删除请假记录
        leaveRepository.deleteById(leaveId);
        return CommonMethod.getReturnMessageOK();
    }
    
    /**
     * 审批请假
     */
    @Transactional
    public DataResponse approveLeave(DataRequest dataRequest) {
        Integer leaveId = dataRequest.getInteger("leaveId");
        String status = dataRequest.getString("status");
        String approver = dataRequest.getString("approver");
        String approveComment = dataRequest.getString("approveComment");
        
        if (leaveId == null || status == null) {
            return CommonMethod.getReturnMessageError("请假ID和审批状态不能为空");
        }
        
        Optional<Leave> optionalLeave = leaveRepository.findById(leaveId);
        if (optionalLeave.isEmpty()) {
            return CommonMethod.getReturnMessageError("找不到该请假记录");
        }
        
        Leave leave = optionalLeave.get();
        leave.setStatus(status);
        leave.setApprover(approver);
        leave.setApproveComment(approveComment);
        leave.setApproveTime(LocalDateTime.now());
        
        leaveRepository.save(leave);
        return CommonMethod.getReturnMessageOK();
    }
} 