package cn.edu.sdu.java.server.services;

import cn.edu.sdu.java.server.models.SocialPractice;
import cn.edu.sdu.java.server.models.Student;
import cn.edu.sdu.java.server.payload.request.DataRequest;
import cn.edu.sdu.java.server.payload.response.DataResponse;
import cn.edu.sdu.java.server.repositorys.SocialPracticeRepository;
import cn.edu.sdu.java.server.repositorys.StudentRepository;
import cn.edu.sdu.java.server.util.CommonMethod;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class SocialPracticeService {
    private final SocialPracticeRepository socialPracticeRepository;
    private final StudentRepository studentRepository;

    public SocialPracticeService(SocialPracticeRepository socialPracticeRepository, StudentRepository studentRepository) {
        this.socialPracticeRepository = socialPracticeRepository;
        this.studentRepository = studentRepository;
    }

    /**
     * 将SocialPractice对象转换为Map
     */
    public Map<String, Object> getMapFromPractice(SocialPractice practice) {
        Map<String, Object> map = new HashMap<>();
        if (practice == null) {
            return map;
        }
        
        map.put("practiceId", practice.getPracticeId());
        map.put("practiceName", practice.getPracticeName());
        map.put("practiceContent", practice.getPracticeContent());
        map.put("startTime", practice.getStartTime() != null ? practice.getStartTime().toString() : null);
        map.put("endTime", practice.getEndTime() != null ? practice.getEndTime().toString() : null);
        map.put("practiceLocation", practice.getPracticeLocation());
        map.put("practiceHours", practice.getPracticeHours());
        map.put("status", practice.getStatus());
        map.put("feedback", practice.getFeedback());
        
        // 添加学生信息
        if (practice.getStudent() != null) {
            Map<String, Object> studentMap = new HashMap<>();
            studentMap.put("personId", practice.getStudent().getPersonId());
            if (practice.getStudent().getPerson() != null) {
                studentMap.put("name", practice.getStudent().getPerson().getName());
                studentMap.put("num", practice.getStudent().getPerson().getNum());
                studentMap.put("className", practice.getStudent().getClassName());
            }
            map.put("student", studentMap);
        }
        
        return map;
    }

    /**
     * 获取社会实践列表
     */
    public DataResponse getPracticeList(DataRequest dataRequest) {
        String keyword = dataRequest.getString("keyword");
        String status = dataRequest.getString("status");
        
        List<SocialPractice> practices;
        if ((keyword != null && !keyword.isEmpty()) || (status != null && !status.isEmpty())) {
            practices = socialPracticeRepository.findByKeywordAndStatus(keyword, status);
        } else {
            practices = socialPracticeRepository.findAll();
        }
        
        List<Map<String, Object>> dataList = practices.stream()
                .map(this::getMapFromPractice)
                .collect(Collectors.toList());
        
        return CommonMethod.getReturnData(dataList);
    }

    /**
     * 获取社会实践详情
     */
    public DataResponse getPracticeInfo(DataRequest dataRequest) {
        Integer practiceId = dataRequest.getInteger("practiceId");
        if (practiceId == null) {
            return CommonMethod.getReturnMessageError("实践ID不能为空");
        }
        
        Optional<SocialPractice> optionalPractice = socialPracticeRepository.findById(practiceId);
        if (optionalPractice.isEmpty()) {
            return CommonMethod.getReturnMessageError("找不到该实践记录");
        }
        
        return CommonMethod.getReturnData(getMapFromPractice(optionalPractice.get()));
    }

    /**
     * 添加或编辑社会实践
     */
    @Transactional
    public DataResponse practiceEdit(DataRequest dataRequest) {
        Integer practiceId = dataRequest.getInteger("practiceId");
        Map<String, Object> form = dataRequest.getMap("form");
        
        SocialPractice practice;
        if (practiceId != null && practiceId > 0) {
            // 编辑现有实践
            Optional<SocialPractice> optionalPractice = socialPracticeRepository.findById(practiceId);
            if (optionalPractice.isEmpty()) {
                return CommonMethod.getReturnMessageError("找不到该实践记录");
            }
            practice = optionalPractice.get();
        } else {
            // 添加新实践
            practice = new SocialPractice();
        }
        
        // 设置实践字段
        practice.setPracticeName(CommonMethod.getString(form, "practiceName"));
        practice.setPracticeContent(CommonMethod.getString(form, "practiceContent"));
        
        String startTimeStr = CommonMethod.getString(form, "startTime");
        if (startTimeStr != null && !startTimeStr.isEmpty()) {
            practice.setStartTime(LocalDateTime.parse(startTimeStr, DateTimeFormatter.ISO_DATE_TIME));
        }
        
        String endTimeStr = CommonMethod.getString(form, "endTime");
        if (endTimeStr != null && !endTimeStr.isEmpty()) {
            practice.setEndTime(LocalDateTime.parse(endTimeStr, DateTimeFormatter.ISO_DATE_TIME));
        }
        
        practice.setPracticeLocation(CommonMethod.getString(form, "practiceLocation"));
        practice.setPracticeHours(CommonMethod.getInteger(form, "practiceHours"));
        practice.setStatus(CommonMethod.getString(form, "status"));
        practice.setFeedback(CommonMethod.getString(form, "feedback"));
        
        // 处理学生关联
        Integer studentId = CommonMethod.getInteger(form, "studentId");
        if (studentId != null) {
            Optional<Student> optionalStudent = studentRepository.findById(studentId);
            if (optionalStudent.isPresent()) {
                practice.setStudent(optionalStudent.get());
            } else {
                return CommonMethod.getReturnMessageError("找不到ID为" + studentId + "的学生");
            }
        } else {
            return CommonMethod.getReturnMessageError("学生ID不能为空");
        }
        
        socialPracticeRepository.save(practice);
        return CommonMethod.getReturnData(practice.getPracticeId());
    }

    /**
     * 删除社会实践
     */
    @Transactional
    public DataResponse deletePractice(DataRequest dataRequest) {
        Integer practiceId = dataRequest.getInteger("practiceId");
        if (practiceId == null || practiceId <= 0) {
            return CommonMethod.getReturnMessageError("实践ID不能为空");
        }
        
        Optional<SocialPractice> optionalPractice = socialPracticeRepository.findById(practiceId);
        if (optionalPractice.isEmpty()) {
            return CommonMethod.getReturnMessageError("找不到该实践记录");
        }
        
        // 删除实践记录
        socialPracticeRepository.deleteById(practiceId);
        return CommonMethod.getReturnMessageOK();
    }
} 