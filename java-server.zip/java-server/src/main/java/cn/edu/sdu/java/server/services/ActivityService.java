package cn.edu.sdu.java.server.services;

import cn.edu.sdu.java.server.models.Activity;
import cn.edu.sdu.java.server.models.Student;
import cn.edu.sdu.java.server.payload.request.DataRequest;
import cn.edu.sdu.java.server.payload.response.DataResponse;
import cn.edu.sdu.java.server.repositorys.ActivityRepository;
import cn.edu.sdu.java.server.repositorys.StudentRepository;
import cn.edu.sdu.java.server.util.CommonMethod;
import cn.edu.sdu.java.server.util.DateTimeTool;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class ActivityService {
    private final ActivityRepository activityRepository;
    private final StudentRepository studentRepository;

    public ActivityService(ActivityRepository activityRepository, StudentRepository studentRepository) {
        this.activityRepository = activityRepository;
        this.studentRepository = studentRepository;
    }

    /**
     * 将Activity对象转换为Map
     */
    public Map<String, Object> getMapFromActivity(Activity activity) {
        Map<String, Object> map = new HashMap<>();
        if (activity == null) {
            return map;
        }
        
        map.put("activityId", activity.getActivityId());
        map.put("activityType", activity.getActivityType());
        map.put("name", activity.getName());
        map.put("description", activity.getDescription());
        map.put("startTime", activity.getStartTime());
        map.put("endTime", activity.getEndTime());
        map.put("location", activity.getLocation());
        map.put("organizer", activity.getOrganizer());
        map.put("status", activity.getStatus());
        
        // 添加参与者列表
        if (activity.getParticipants() != null) {
            List<Map<String, Object>> participants = activity.getParticipants().stream()
                    .map(student -> {
                        Map<String, Object> studentMap = new HashMap<>();
                        studentMap.put("studentId", student.getPersonId());
                        studentMap.put("name", student.getPerson().getName());
                        studentMap.put("num", student.getPerson().getNum());
                        return studentMap;
                    })
                    .collect(Collectors.toList());
            map.put("participants", participants);
        }
        
        return map;
    }

    /**
     * 获取活动列表
     */
    public DataResponse getActivityList(DataRequest dataRequest) {
        String keyword = dataRequest.getString("keyword");
        String activityType = dataRequest.getString("activityType");
        
        List<Activity> activities;
        if (keyword != null && !keyword.isEmpty()) {
            activities = activityRepository.findByNameOrDescriptionContaining(keyword);
        } else if (activityType != null && !activityType.isEmpty()) {
            activities = activityRepository.findByActivityType(activityType);
        } else {
            activities = activityRepository.findAll();
        }
        
        List<Map<String, Object>> dataList = activities.stream()
                .map(this::getMapFromActivity)
                .collect(Collectors.toList());
        
        return CommonMethod.getReturnData(dataList);
    }

    /**
     * 获取活动详情
     */
    public DataResponse getActivityInfo(DataRequest dataRequest) {
        Integer activityId = dataRequest.getInteger("activityId");
        if (activityId == null) {
            return CommonMethod.getReturnMessageError("活动ID不能为空");
        }
        
        Optional<Activity> optionalActivity = activityRepository.findById(activityId);
        if (optionalActivity.isEmpty()) {
            return CommonMethod.getReturnMessageError("找不到该活动");
        }
        
        return CommonMethod.getReturnData(getMapFromActivity(optionalActivity.get()));
    }

    /**
     * 添加或编辑活动
     */
    @Transactional
    public DataResponse activityEdit(DataRequest dataRequest) {
        Integer activityId = dataRequest.getInteger("activityId");
        Map<String, Object> form = dataRequest.getMap("form");
        
        Activity activity;
        if (activityId != null && activityId > 0) {
            // 编辑现有活动
            Optional<Activity> optionalActivity = activityRepository.findById(activityId);
            if (optionalActivity.isEmpty()) {
                return CommonMethod.getReturnMessageError("找不到该活动");
            }
            activity = optionalActivity.get();
        } else {
            // 添加新活动
            activity = new Activity();
        }
        
        // 设置活动字段
        activity.setActivityType(CommonMethod.getString(form, "activityType"));
        activity.setName(CommonMethod.getString(form, "name"));
        activity.setDescription(CommonMethod.getString(form, "description"));
        
        String startTimeStr = CommonMethod.getString(form, "startTime");
        if (startTimeStr != null && !startTimeStr.isEmpty()) {
            activity.setStartTime(LocalDateTime.parse(startTimeStr));
        }
        
        String endTimeStr = CommonMethod.getString(form, "endTime");
        if (endTimeStr != null && !endTimeStr.isEmpty()) {
            activity.setEndTime(LocalDateTime.parse(endTimeStr));
        }
        
        activity.setLocation(CommonMethod.getString(form, "location"));
        activity.setOrganizer(CommonMethod.getString(form, "organizer"));
        activity.setStatus(CommonMethod.getString(form, "status"));
        
        // 处理参与者
        List<Integer> participantIds = (List<Integer>) form.get("participantIds");
        if (participantIds != null && !participantIds.isEmpty()) {
            Set<Student> participants = new HashSet<>();
            for (Integer studentId : participantIds) {
                studentRepository.findById(studentId).ifPresent(participants::add);
            }
            activity.setParticipants(participants);
        }
        
        activityRepository.save(activity);
        return CommonMethod.getReturnData(activity.getActivityId());
    }

    /**
     * 删除活动
     */
    @Transactional
    public DataResponse deleteActivity(DataRequest dataRequest) {
        Integer activityId = dataRequest.getInteger("activityId");
        if (activityId == null || activityId <= 0) {
            return CommonMethod.getReturnMessageError("活动ID不能为空");
        }
        
        Optional<Activity> optionalActivity = activityRepository.findById(activityId);
        if (optionalActivity.isEmpty()) {
            return CommonMethod.getReturnMessageError("找不到该活动");
        }
        
        Activity activity = optionalActivity.get();
        
        // 清除多对多关系
        activity.setParticipants(new HashSet<>());
        activityRepository.save(activity);
        
        // 删除活动
        activityRepository.deleteById(activityId);
        return CommonMethod.getReturnMessageOK();
    }
    
    /**
     * 添加学生到活动
     */
    @Transactional
    public DataResponse addStudentToActivity(DataRequest dataRequest) {
        Integer activityId = dataRequest.getInteger("activityId");
        Integer studentId = dataRequest.getInteger("studentId");
        
        if (activityId == null || studentId == null) {
            return CommonMethod.getReturnMessageError("活动ID和学生ID不能为空");
        }
        
        Optional<Activity> optionalActivity = activityRepository.findById(activityId);
        Optional<Student> optionalStudent = studentRepository.findById(studentId);
        
        if (optionalActivity.isEmpty() || optionalStudent.isEmpty()) {
            return CommonMethod.getReturnMessageError("找不到活动或学生");
        }
        
        Activity activity = optionalActivity.get();
        Student student = optionalStudent.get();
        
        if (activity.getParticipants() == null) {
            activity.setParticipants(new HashSet<>());
        }
        
        if (activity.getParticipants().contains(student)) {
            return CommonMethod.getReturnMessageError("该学生已经是活动参与者");
        }
        
        activity.getParticipants().add(student);
        activityRepository.save(activity);
        
        return CommonMethod.getReturnMessageOK();
    }
    
    /**
     * 从活动中移除学生
     */
    @Transactional
    public DataResponse removeStudentFromActivity(DataRequest dataRequest) {
        Integer activityId = dataRequest.getInteger("activityId");
        Integer studentId = dataRequest.getInteger("studentId");
        
        if (activityId == null || studentId == null) {
            return CommonMethod.getReturnMessageError("活动ID和学生ID不能为空");
        }
        
        Optional<Activity> optionalActivity = activityRepository.findById(activityId);
        Optional<Student> optionalStudent = studentRepository.findById(studentId);
        
        if (optionalActivity.isEmpty() || optionalStudent.isEmpty()) {
            return CommonMethod.getReturnMessageError("找不到活动或学生");
        }
        
        Activity activity = optionalActivity.get();
        Student student = optionalStudent.get();
        
        if (activity.getParticipants() == null || !activity.getParticipants().contains(student)) {
            return CommonMethod.getReturnMessageError("该学生不是活动参与者");
        }
        
        activity.getParticipants().remove(student);
        activityRepository.save(activity);
        
        return CommonMethod.getReturnMessageOK();
    }
} 