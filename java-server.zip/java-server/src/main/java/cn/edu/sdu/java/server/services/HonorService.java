package cn.edu.sdu.java.server.services;

import cn.edu.sdu.java.server.models.Honor;
import cn.edu.sdu.java.server.models.Student;
import cn.edu.sdu.java.server.payload.request.DataRequest;
import cn.edu.sdu.java.server.payload.response.DataResponse;
import cn.edu.sdu.java.server.payload.response.OptionItem;
import cn.edu.sdu.java.server.payload.response.OptionItemList;
import cn.edu.sdu.java.server.repositorys.HonorRepository;
import cn.edu.sdu.java.server.repositorys.StudentRepository;
import cn.edu.sdu.java.server.util.CommonMethod;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class HonorService {
    private final HonorRepository honorRepository;
    private final StudentRepository studentRepository;

    public HonorService(HonorRepository honorRepository, StudentRepository studentRepository) {
        this.honorRepository = honorRepository;
        this.studentRepository = studentRepository;
    }

    /**
     * 将Honor对象转换为Map
     */
    public Map<String, Object> getMapFromHonor(Honor honor) {
        Map<String, Object> map = new HashMap<>();
        if (honor == null) {
            return map;
        }
        
        map.put("honorId", honor.getHonorId());
        map.put("title", honor.getTitle());
        map.put("honorType", honor.getHonorType());
        map.put("level", honor.getLevel());
        map.put("awardDate", honor.getAwardDate() != null ? honor.getAwardDate().toString() : null);
        map.put("issuer", honor.getIssuer());
        map.put("certificateNumber", honor.getCertificateNumber());
        map.put("description", honor.getDescription());
        
        // 添加学生信息
        if (honor.getStudent() != null) {
            Map<String, Object> studentMap = new HashMap<>();
            studentMap.put("personId", honor.getStudent().getPersonId());
            if (honor.getStudent().getPerson() != null) {
                studentMap.put("name", honor.getStudent().getPerson().getName());
                studentMap.put("num", honor.getStudent().getPerson().getNum());
                studentMap.put("className", honor.getStudent().getClassName());
            }
            map.put("student", studentMap);
        }
        
        return map;
    }

    /**
     * 获取荣誉列表
     */
    public DataResponse getHonorList(DataRequest dataRequest) {
        Integer personId = dataRequest.getInteger("personId");
        if(personId == null)
            personId = 0;
        String honorType = dataRequest.getString("honorType");
        if(honorType == null)
            honorType = "";
            
        List<Honor> hList = honorRepository.findByStudentAndType(personId, honorType);
        List<Map<String,Object>> dataList = new ArrayList<>();
        Map<String,Object> m;
        for (Honor h : hList) {
            m = new HashMap<>();
            m.put("honorId", h.getHonorId()+"");
            m.put("personId", h.getStudent().getPersonId()+"");
            m.put("studentNum", h.getStudent().getPerson().getNum());
            m.put("studentName", h.getStudent().getPerson().getName());
            m.put("className", h.getStudent().getClassName());
            m.put("title", h.getTitle());
            m.put("honorType", h.getHonorType());
            m.put("level", h.getLevel());
            m.put("awardDate", h.getAwardDate() != null ? h.getAwardDate().toString() : "");
            m.put("issuer", h.getIssuer());
            m.put("certificateNumber", h.getCertificateNumber());
            m.put("description", h.getDescription());
            dataList.add(m);
        }
        return CommonMethod.getReturnData(dataList);
    }

    /**
     * 获取荣誉详情
     */
    public DataResponse getHonorInfo(DataRequest dataRequest) {
        Integer honorId = dataRequest.getInteger("honorId");
        if (honorId == null) {
            return CommonMethod.getReturnMessageError("荣誉ID不能为空");
        }
        
        Optional<Honor> optionalHonor = honorRepository.findById(honorId);
        if (optionalHonor.isEmpty()) {
            return CommonMethod.getReturnMessageError("找不到该荣誉");
        }
        
        return CommonMethod.getReturnData(getMapFromHonor(optionalHonor.get()));
    }

    /**
     * 添加或编辑荣誉
     */
    @Transactional
    public DataResponse honorEdit(DataRequest dataRequest) {
        Integer honorId = dataRequest.getInteger("honorId");
        Map<String, Object> form = dataRequest.getMap("form");
        
        Honor honor;
        if (honorId != null && honorId > 0) {
            // 编辑现有荣誉
            Optional<Honor> optionalHonor = honorRepository.findById(honorId);
            if (optionalHonor.isEmpty()) {
                return CommonMethod.getReturnMessageError("找不到该荣誉");
            }
            honor = optionalHonor.get();
        } else {
            // 添加新荣誉
            honor = new Honor();
        }
        
        // 设置荣誉字段
        honor.setTitle(CommonMethod.getString(form, "title"));
        honor.setHonorType(CommonMethod.getString(form, "honorType"));
        honor.setLevel(CommonMethod.getString(form, "level"));
        
        String awardDateStr = CommonMethod.getString(form, "awardDate");
        if (awardDateStr != null && !awardDateStr.isEmpty()) {
            honor.setAwardDate(LocalDate.parse(awardDateStr, DateTimeFormatter.ISO_DATE));
        }
        
        honor.setIssuer(CommonMethod.getString(form, "issuer"));
        honor.setCertificateNumber(CommonMethod.getString(form, "certificateNumber"));
        honor.setDescription(CommonMethod.getString(form, "description"));
        
        // 处理学生关联
        Integer studentId = CommonMethod.getInteger(form, "studentId");
        if (studentId != null) {
            Optional<Student> optionalStudent = studentRepository.findById(studentId);
            if (optionalStudent.isPresent()) {
                honor.setStudent(optionalStudent.get());
            } else {
                return CommonMethod.getReturnMessageError("找不到ID为" + studentId + "的学生");
            }
        } else {
            return CommonMethod.getReturnMessageError("学生ID不能为空");
        }
        
        honorRepository.save(honor);
        return CommonMethod.getReturnData(honor.getHonorId());
    }

    /**
     * 删除荣誉
     */
    @Transactional
    public DataResponse deleteHonor(DataRequest dataRequest) {
        Integer honorId = dataRequest.getInteger("honorId");
        if (honorId == null || honorId <= 0) {
            return CommonMethod.getReturnMessageError("荣誉ID不能为空");
        }
        
        Optional<Honor> optionalHonor = honorRepository.findById(honorId);
        if (optionalHonor.isEmpty()) {
            return CommonMethod.getReturnMessageError("找不到该荣誉");
        }
        
        // 删除荣誉
        honorRepository.deleteById(honorId);
        return CommonMethod.getReturnMessageOK();
    }

    public OptionItemList getStudentItemOptionList(DataRequest dataRequest) {
        List<Student> sList = studentRepository.findStudentListByNumName("");
        List<OptionItem> itemList = new ArrayList<>();
        for (Student s : sList) {
            itemList.add(new OptionItem(s.getPersonId(), s.getPersonId()+"", 
                s.getPerson().getNum()+"-"+s.getPerson().getName()));
        }
        return new OptionItemList(0, itemList);
    }

    public DataResponse honorSave(DataRequest dataRequest) {
        Integer personId = dataRequest.getInteger("personId");
        Integer honorId = dataRequest.getInteger("honorId");
        String title = dataRequest.getString("title");
        String honorType = dataRequest.getString("honorType");
        String level = dataRequest.getString("level");
        String awardDateStr = dataRequest.getString("awardDate");
        String issuer = dataRequest.getString("issuer");
        String certificateNumber = dataRequest.getString("certificateNumber");
        String description = dataRequest.getString("description");

        Optional<Honor> op;
        Honor h = null;
        if(honorId != null) {
            op = honorRepository.findById(honorId);
            if(op.isPresent())
                h = op.get();
        }
        if(h == null) {
            h = new Honor();
            h.setStudent(studentRepository.findById(personId).get());
        }
        
        h.setTitle(title);
        h.setHonorType(honorType);
        h.setLevel(level);
        if(awardDateStr != null && !awardDateStr.isEmpty()) {
            h.setAwardDate(LocalDate.parse(awardDateStr));
        }
        h.setIssuer(issuer);
        h.setCertificateNumber(certificateNumber);
        h.setDescription(description);
        
        honorRepository.save(h);
        return CommonMethod.getReturnMessageOK();
    }

    public DataResponse honorDelete(DataRequest dataRequest) {
        Integer honorId = dataRequest.getInteger("honorId");
        Optional<Honor> op;
        Honor h = null;
        if(honorId != null) {
            op = honorRepository.findById(honorId);
            if(op.isPresent()) {
                h = op.get();
                honorRepository.delete(h);
            }
        }
        return CommonMethod.getReturnMessageOK();
    }
} 