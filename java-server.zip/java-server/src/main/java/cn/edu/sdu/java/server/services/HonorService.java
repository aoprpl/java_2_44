package cn.edu.sdu.java.server.services;

import cn.edu.sdu.java.server.models.Honor;
import cn.edu.sdu.java.server.models.Student;
import cn.edu.sdu.java.server.payload.request.DataRequest;
import cn.edu.sdu.java.server.payload.response.DataResponse;
import cn.edu.sdu.java.server.repositorys.HonorRepository;
import cn.edu.sdu.java.server.repositorys.StudentRepository;
import cn.edu.sdu.java.server.util.CommonMethod;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class HonorService {
    private final HonorRepository honorRepository;
    private final StudentRepository studentRepository;

    public HonorService(HonorRepository honorRepository, StudentRepository studentRepository) {
        this.honorRepository = honorRepository;
        this.studentRepository = studentRepository;
    }

    /**
     * 将Honor对象转换为Map
     */
    public Map<String, Object> getMapFromHonor(Honor honor) {
        Map<String, Object> map = new HashMap<>();
        if (honor == null) {
            return map;
        }
        
        map.put("honorId", honor.getHonorId());
        map.put("title", honor.getTitle());
        map.put("honorType", honor.getHonorType());
        map.put("level", honor.getLevel());
        map.put("awardDate", honor.getAwardDate() != null ? honor.getAwardDate().toString() : null);
        map.put("issuer", honor.getIssuer());
        map.put("certificateNumber", honor.getCertificateNumber());
        map.put("description", honor.getDescription());
        
        // 添加学生信息
        if (honor.getStudent() != null) {
            Map<String, Object> studentMap = new HashMap<>();
            studentMap.put("personId", honor.getStudent().getPersonId());
            if (honor.getStudent().getPerson() != null) {
                studentMap.put("name", honor.getStudent().getPerson().getName());
                studentMap.put("num", honor.getStudent().getPerson().getNum());
                studentMap.put("className", honor.getStudent().getClassName());
            }
            map.put("student", studentMap);
        }
        
        return map;
    }

    /**
     * 获取荣誉列表
     */
    public DataResponse getHonorList(DataRequest dataRequest) {
        String keyword = dataRequest.getString("keyword");
        String honorType = dataRequest.getString("honorType");
        
        List<Honor> honors;
        if ((keyword != null && !keyword.isEmpty()) || (honorType != null && !honorType.isEmpty())) {
            honors = honorRepository.findByKeywordAndType(keyword, honorType);
        } else {
            honors = honorRepository.findAll();
        }
        
        List<Map<String, Object>> dataList = honors.stream()
                .map(this::getMapFromHonor)
                .collect(Collectors.toList());
        
        return CommonMethod.getReturnData(dataList);
    }

    /**
     * 获取荣誉详情
     */
    public DataResponse getHonorInfo(DataRequest dataRequest) {
        Integer honorId = dataRequest.getInteger("honorId");
        if (honorId == null) {
            return CommonMethod.getReturnMessageError("荣誉ID不能为空");
        }
        
        Optional<Honor> optionalHonor = honorRepository.findById(honorId);
        if (optionalHonor.isEmpty()) {
            return CommonMethod.getReturnMessageError("找不到该荣誉");
        }
        
        return CommonMethod.getReturnData(getMapFromHonor(optionalHonor.get()));
    }

    /**
     * 添加或编辑荣誉
     */
    @Transactional
    public DataResponse honorEdit(DataRequest dataRequest) {
        Integer honorId = dataRequest.getInteger("honorId");
        Map<String, Object> form = dataRequest.getMap("form");
        
        Honor honor;
        if (honorId != null && honorId > 0) {
            // 编辑现有荣誉
            Optional<Honor> optionalHonor = honorRepository.findById(honorId);
            if (optionalHonor.isEmpty()) {
                return CommonMethod.getReturnMessageError("找不到该荣誉");
            }
            honor = optionalHonor.get();
        } else {
            // 添加新荣誉
            honor = new Honor();
        }
        
        // 设置荣誉字段
        honor.setTitle(CommonMethod.getString(form, "title"));
        honor.setHonorType(CommonMethod.getString(form, "honorType"));
        honor.setLevel(CommonMethod.getString(form, "level"));
        
        String awardDateStr = CommonMethod.getString(form, "awardDate");
        if (awardDateStr != null && !awardDateStr.isEmpty()) {
            honor.setAwardDate(LocalDate.parse(awardDateStr, DateTimeFormatter.ISO_DATE));
        }
        
        honor.setIssuer(CommonMethod.getString(form, "issuer"));
        honor.setCertificateNumber(CommonMethod.getString(form, "certificateNumber"));
        honor.setDescription(CommonMethod.getString(form, "description"));
        
        // 处理学生关联
        Integer studentId = CommonMethod.getInteger(form, "studentId");
        if (studentId != null) {
            Optional<Student> optionalStudent = studentRepository.findById(studentId);
            if (optionalStudent.isPresent()) {
                honor.setStudent(optionalStudent.get());
            } else {
                return CommonMethod.getReturnMessageError("找不到ID为" + studentId + "的学生");
            }
        } else {
            return CommonMethod.getReturnMessageError("学生ID不能为空");
        }
        
        honorRepository.save(honor);
        return CommonMethod.getReturnData(honor.getHonorId());
    }

    /**
     * 删除荣誉
     */
    @Transactional
    public DataResponse deleteHonor(DataRequest dataRequest) {
        Integer honorId = dataRequest.getInteger("honorId");
        if (honorId == null || honorId <= 0) {
            return CommonMethod.getReturnMessageError("荣誉ID不能为空");
        }
        
        Optional<Honor> optionalHonor = honorRepository.findById(honorId);
        if (optionalHonor.isEmpty()) {
            return CommonMethod.getReturnMessageError("找不到该荣誉");
        }
        
        // 删除荣誉
        honorRepository.deleteById(honorId);
        return CommonMethod.getReturnMessageOK();
    }
} 