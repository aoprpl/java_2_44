package cn.edu.sdu.java.server.repositorys;

import cn.edu.sdu.java.server.models.Activity;
import cn.edu.sdu.java.server.models.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface ActivityRepository extends JpaRepository<Activity, Integer> {
    
    @Query("SELECT a FROM Activity a WHERE a.name LIKE %:keyword% OR a.description LIKE %:keyword%")
    List<Activity> findByNameOrDescriptionContaining(@Param("keyword") String keyword);
    
    List<Activity> findByActivityType(String activityType);
    
    List<Activity> findByStatus(String status);
    
    @Query("SELECT a FROM Activity a WHERE a.startTime >= :startDate AND a.endTime <= :endDate")
    List<Activity> findActivitiesBetweenDates(@Param("startDate") LocalDateTime startDate, @Param("endDate") LocalDateTime endDate);
    
    @Query("SELECT a FROM Activity a WHERE :student MEMBER OF a.participants")
    List<Activity> findActivitiesByStudent(@Param("student") Student student);
    
    @Query("SELECT a FROM Activity a WHERE a.location LIKE %:location%")
    List<Activity> findByLocationContaining(@Param("location") String location);
    
    @Query("SELECT a FROM Activity a WHERE a.organizer = :organizer")
    List<Activity> findByOrganizer(@Param("organizer") String organizer);
    
    @Query("SELECT a FROM Activity a WHERE a.activityType = :type AND a.status = :status")
    List<Activity> findByTypeAndStatus(@Param("type") String type, @Param("status") String status);
} 