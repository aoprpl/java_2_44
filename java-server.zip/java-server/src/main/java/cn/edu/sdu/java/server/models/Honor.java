package cn.edu.sdu.java.server.models;

import jakarta.persistence.*;
import jakarta.validation.constraints.Size;
import java.time.LocalDate;

/**
 * Honor 学生荣誉表实体类，保存学生获得的各类荣誉、奖项、成果等信息
 */
@Entity
@Table(name = "honor")
public class Honor {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer honorId;

    @Size(max = 100)
    private String title;  // 荣誉称号

    @Size(max = 20)
    private String honorType;  // 荣誉类型：奖学金、学科竞赛、科研成果等

    @Size(max = 20)
    private String level;  // 荣誉级别：国家级、省级、校级等

    private LocalDate awardDate;  // 获奖日期

    @Size(max = 100)
    private String issuer;  // 授予单位

    @Size(max = 50)
    private String certificateNumber;  // 证书编号

    @Size(max = 500)
    private String description;  // 荣誉描述

    @ManyToOne
    @JoinColumn(name = "student_id")
    private Student student;  // 获奖学生

    // Getters and Setters
    public Integer getHonorId() {
        return honorId;
    }

    public void setHonorId(Integer honorId) {
        this.honorId = honorId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getHonorType() {
        return honorType;
    }

    public void setHonorType(String honorType) {
        this.honorType = honorType;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public LocalDate getAwardDate() {
        return awardDate;
    }

    public void setAwardDate(LocalDate awardDate) {
        this.awardDate = awardDate;
    }

    public String getIssuer() {
        return issuer;
    }

    public void setIssuer(String issuer) {
        this.issuer = issuer;
    }

    public String getCertificateNumber() {
        return certificateNumber;
    }

    public void setCertificateNumber(String certificateNumber) {
        this.certificateNumber = certificateNumber;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }
} 