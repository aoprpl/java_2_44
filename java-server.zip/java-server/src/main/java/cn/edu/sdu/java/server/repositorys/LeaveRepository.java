package cn.edu.sdu.java.server.repositorys;

import cn.edu.sdu.java.server.models.Leave;
import cn.edu.sdu.java.server.models.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface LeaveRepository extends JpaRepository<Leave, Integer> {
    
    @Query("SELECT l FROM Leave l WHERE l.student = :student")
    List<Leave> findLeavesByStudent(@Param("student") Student student);
    
    List<Leave> findByLeaveType(String leaveType);
    
    List<Leave> findByStatus(String status);
    
    @Query("SELECT l FROM Leave l WHERE l.startTime >= :startDate AND l.endTime <= :endDate")
    List<Leave> findLeavesBetweenDates(@Param("startDate") LocalDateTime startDate, @Param("endDate") LocalDateTime endDate);
    
    @Query("SELECT l FROM Leave l WHERE l.student.person.name LIKE %:keyword% OR l.student.person.num LIKE %:keyword% OR l.reason LIKE %:keyword% OR l.destination LIKE %:keyword%")
    List<Leave> findByKeyword(@Param("keyword") String keyword);
    
    @Query("SELECT l FROM Leave l WHERE (:keyword IS NULL OR l.student.person.name LIKE %:keyword% OR l.student.person.num LIKE %:keyword% OR l.reason LIKE %:keyword%) AND (:leaveType IS NULL OR l.leaveType = :leaveType) AND (:status IS NULL OR l.status = :status)")
    List<Leave> findByKeywordAndTypeAndStatus(@Param("keyword") String keyword, @Param("leaveType") String leaveType, @Param("status") String status);
} 