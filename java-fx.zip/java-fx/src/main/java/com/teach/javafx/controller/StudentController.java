package com.teach.javafx.controller;

import com.teach.javafx.MainApplication;
import com.teach.javafx.controller.base.LocalDateStringConverter;
import com.teach.javafx.controller.base.ToolController;
import com.teach.javafx.request.*;
import com.teach.javafx.AppStore;
import javafx.scene.Scene;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import com.teach.javafx.request.DataRequest;
import com.teach.javafx.request.DataResponse;
import com.teach.javafx.util.CommonMethod;
import com.teach.javafx.controller.base.MessageDialog;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.control.cell.MapValueFactory;
import javafx.stage.FileChooser;
import javafx.scene.layout.VBox;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javafx.beans.property.SimpleStringProperty;

/**
 * StudentController 登录交互控制类 对应 student_panel.fxml  对应于学生管理的后台业务处理的控制器，主要获取数据和保存数据的方法不同
 *
 * @FXML 属性 对应fxml文件中的
 * @FXML 方法 对应于fxml文件中的 on***Click的属性
 */
public class StudentController extends ToolController {
    private ImageView photoImageView;
    @FXML
    private TableView<Map> dataTableView;  //学生信息表
    @FXML
    private TableColumn<Map, String> numColumn;   //学生信息表 编号列
    @FXML
    private TableColumn<Map, String> nameColumn; //学生信息表 名称列
    @FXML
    private TableColumn<Map, String> deptColumn;  //学生信息表 院系列
    @FXML
    private TableColumn<Map, String> majorColumn; //学生信息表 专业列
    @FXML
    private TableColumn<Map, String> classNameColumn; //学生信息表 班级列
    @FXML
    private TableColumn<Map, String> cardColumn; //学生信息表 证件号码列
    @FXML
    private TableColumn<Map, String> genderColumn; //学生信息表 性别列
    @FXML
    private TableColumn<Map, String> birthdayColumn; //学生信息表 出生日期列
    @FXML
    private TableColumn<Map, String> emailColumn; //学生信息表 邮箱列
    @FXML
    private TableColumn<Map, String> phoneColumn; //学生信息表 电话列
    @FXML
    private TableColumn<Map, String> addressColumn;//学生信息表 地址列
    @FXML
    private Button photoButton;  //照片显示和上传按钮

    @FXML
    private TextField numField; //学生信息  学号输入域
    @FXML
    private TextField nameField;  //学生信息  名称输入域
    @FXML
    private TextField deptField; //学生信息  院系输入域
    @FXML
    private TextField majorField; //学生信息  专业输入域
    @FXML
    private TextField classNameField; //学生信息  班级输入域
    @FXML
    private TextField cardField; //学生信息  证件号码输入域
    @FXML
    private ComboBox<OptionItem> genderComboBox;  //学生信息  性别输入域
    @FXML
    private DatePicker birthdayPick;  //学生信息  出生日期选择域
    @FXML
    private TextField emailField;  //学生信息  邮箱输入域
    @FXML
    private TextField phoneField;   //学生信息  电话输入域
    @FXML
    private TextField addressField;  //学生信息  地址输入域

    @FXML
    private TextField numNameTextField;  //查询 姓名学号输入域

    private Integer personId = null;  //当前编辑修改的学生的主键

    private ArrayList<Map> studentList = new ArrayList();  // 学生信息列表数据
    private List<OptionItem> genderList;   //性别选择列表数据
    private ObservableList<Map> observableList = FXCollections.observableArrayList();  // TableView渲染列表

    private final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    /**
     * 将学生数据集合设置到面板上显示
     */
    private void setTableViewData() {
        observableList.clear();
        for (int j = 0; j < studentList.size(); j++) {
            observableList.addAll(FXCollections.observableArrayList(studentList.get(j)));
        }
        dataTableView.setItems(observableList);
    }

    /**
     * 页面加载对象创建完成初始化方法，页面中控件属性的设置，初始数据显示等初始操作都在这里完成，其他代码都事件处理方法里
     */

    @FXML
    public void initialize() {
        photoImageView = new ImageView();
        photoImageView.setFitHeight(100);
        photoImageView.setFitWidth(100);
        photoButton.setGraphic(photoImageView);
        DataResponse res;
        DataRequest req = new DataRequest();
        req.add("numName", "");
        res = HttpRequestUtil.request("/api/student/getStudentList", req); //从后台获取所有学生信息列表集合
        if (res != null && res.getCode() == 0) {
            studentList = (ArrayList<Map>) res.getData();
        }
        numColumn.setCellValueFactory(new MapValueFactory<>("num"));  //设置列值工程属性
        nameColumn.setCellValueFactory(new MapValueFactory<>("name"));
        deptColumn.setCellValueFactory(new MapValueFactory<>("dept"));
        majorColumn.setCellValueFactory(new MapValueFactory<>("major"));
        classNameColumn.setCellValueFactory(new MapValueFactory<>("className"));
        cardColumn.setCellValueFactory(new MapValueFactory<>("card"));
        genderColumn.setCellValueFactory(new MapValueFactory<>("genderName"));
        birthdayColumn.setCellValueFactory(cellData -> {
            Object value = cellData.getValue().get("birthday");
            if (value != null && !value.toString().isEmpty()) {
                try {
                    LocalDate date = LocalDate.parse(value.toString(), dateFormatter);
                    return new SimpleStringProperty(date.format(dateFormatter));
                } catch (Exception e) {
                    return new SimpleStringProperty(value.toString());
                }
            }
            return new SimpleStringProperty("");
        });
        emailColumn.setCellValueFactory(new MapValueFactory<>("email"));
        phoneColumn.setCellValueFactory(new MapValueFactory<>("phone"));
        addressColumn.setCellValueFactory(new MapValueFactory<>("address"));
        TableView.TableViewSelectionModel<Map> tsm = dataTableView.getSelectionModel();
        ObservableList<Integer> list = tsm.getSelectedIndices();
        list.addListener(this::onTableRowSelect);
        setTableViewData();
        genderList = HttpRequestUtil.getDictionaryOptionItemList("XBM");

        genderComboBox.getItems().addAll(genderList);
        birthdayPick.setConverter(new LocalDateStringConverter("yyyy-MM-dd"));
    }

    /**
     * 清除学生表单中输入信息
     */
    public void clearPanel() {
        personId = null;
        numField.setText("");
        nameField.setText("");
        deptField.setText("");
        majorField.setText("");
        classNameField.setText("");
        cardField.setText("");
        genderComboBox.getSelectionModel().select(-1);
        birthdayPick.getEditor().setText("");
        emailField.setText("");
        phoneField.setText("");
        addressField.setText("");
    }

    protected void changeStudentInfo() {
        Map<String,Object> form = dataTableView.getSelectionModel().getSelectedItem();
        if (form == null) {
            clearPanel();
            return;
        }
        personId = CommonMethod.getInteger(form, "personId");
        DataRequest req = new DataRequest();
        req.add("personId", personId);
        DataResponse res = HttpRequestUtil.request("/api/student/getStudentInfo", req);
        if (res.getCode() != 0) {
            MessageDialog.showDialog(res.getMsg());
            return;
        }
        form = (Map) res.getData();
        numField.setText(CommonMethod.getString(form, "num"));
        nameField.setText(CommonMethod.getString(form, "name"));
        deptField.setText(CommonMethod.getString(form, "dept"));
        majorField.setText(CommonMethod.getString(form, "major"));
        classNameField.setText(CommonMethod.getString(form, "className"));
        cardField.setText(CommonMethod.getString(form, "card"));
        genderComboBox.getSelectionModel().select(CommonMethod.getOptionItemIndexByValue(genderList, CommonMethod.getString(form, "gender")));
        
        // 处理日期
        String birthday = CommonMethod.getString(form, "birthday");
        if (birthday != null && !birthday.isEmpty()) {
            try {
                LocalDate date = LocalDate.parse(birthday, dateFormatter);
                birthdayPick.setValue(date);
            } catch (Exception e) {
                birthdayPick.setValue(null);
            }
        } else {
            birthdayPick.setValue(null);
        }
        
        emailField.setText(CommonMethod.getString(form, "email"));
        phoneField.setText(CommonMethod.getString(form, "phone"));
        addressField.setText(CommonMethod.getString(form, "address"));
        displayPhoto();
    }

    /**
     * 点击学生列表的某一行，根据personId ,从后台查询学生的基本信息，切换学生的编辑信息
     */

    public void onTableRowSelect(ListChangeListener.Change<? extends Integer> change) {
        changeStudentInfo();
    }

    /**
     * 点击查询按钮，从从后台根据输入的串，查询匹配的学生在学生列表中显示
     */
    @FXML
    protected void onQueryButtonClick() {
        String numName = numNameTextField.getText();
        DataRequest req = new DataRequest();
        req.add("numName", numName);
        DataResponse res = HttpRequestUtil.request("/api/student/getStudentList", req);
        if (res != null && res.getCode() == 0) {
            studentList = (ArrayList<Map>) res.getData();
            setTableViewData();
        }
    }


    /**
     * 添加新学生， 打开学生编辑对话框
     */
    @FXML
    protected void onAddButtonClick() {
        try {
            // 加载学生编辑对话框FXML
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/teach/javafx/student-edit-dialog.fxml"));
            VBox dialogPane = loader.load();
            
            // 获取对话框控制器
            StudentEditController controller = loader.getController();
            controller.setStudentController(this);
            controller.setStudentData(null); // 新建学生，传入null
            
            // 创建对话框
            Stage dialogStage = new Stage();
            dialogStage.setTitle("添加学生");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(numField.getScene().getWindow());
            
            // 设置对话框场景
            Scene scene = new Scene(dialogPane);
            dialogStage.setScene(scene);
            
            // 显示对话框
            dialogStage.showAndWait();
            
        } catch (IOException e) {
            e.printStackTrace();
            MessageDialog.showDialog("打开学生编辑对话框失败: " + e.getMessage());
        }
    }

    /**
     * 点击删除按钮 删除当前编辑的学生的数据
     */
    @FXML
    protected void onDeleteButtonClick() {
        Map form = dataTableView.getSelectionModel().getSelectedItem();
        if (form == null) {
            MessageDialog.showDialog("没有选择，不能删除");
            return;
        }
        int ret = MessageDialog.choiceDialog("确认要删除吗?");
        if (ret != MessageDialog.CHOICE_YES) {
            return;
        }
        personId = CommonMethod.getInteger(form, "personId");
        DataRequest req = new DataRequest();
        req.add("personId", personId);
        DataResponse res = HttpRequestUtil.request("/api/student/studentDelete", req);
        if(res!= null) {
            if (res.getCode() == 0) {
                MessageDialog.showDialog("删除成功！");
                onQueryButtonClick();
            } else {
                MessageDialog.showDialog(res.getMsg());
            }
        }
    }

    /**
     * 点击保存按钮，保存当前编辑的学生信息，如果是新添加的学生，后台添加学生
     */
    @FXML
    protected void onSaveButtonClick() {
        if (numField.getText().isEmpty()) {
            MessageDialog.showDialog("学号为空，不能修改");
            return;
        }
        Map<String,Object> form = new HashMap<>();
        form.put("num", numField.getText());
        form.put("name", nameField.getText());
        form.put("dept", deptField.getText());
        form.put("major", majorField.getText());
        form.put("className", classNameField.getText());
        form.put("card", cardField.getText());
        if (genderComboBox.getSelectionModel() != null && genderComboBox.getSelectionModel().getSelectedItem() != null)
            form.put("gender", genderComboBox.getSelectionModel().getSelectedItem().getValue());
        
        // 处理日期
        if (birthdayPick.getValue() != null) {
            form.put("birthday", birthdayPick.getValue().format(dateFormatter));
        } else {
            form.put("birthday", "");
        }
        
        form.put("email", emailField.getText());
        form.put("phone", phoneField.getText());
        form.put("address", addressField.getText());
        DataRequest req = new DataRequest();
        req.add("personId", personId);
        req.add("form", form);
        DataResponse res = HttpRequestUtil.request("/api/student/studentEditSave", req);
        if (res != null) {
            if (res.getCode() == 0) {
                personId = CommonMethod.getIntegerFromObject(res.getData());
                MessageDialog.showDialog("提交成功！");
                onQueryButtonClick();
            } else {
                String errorMsg = res.getMsg();
                if (errorMsg == null || errorMsg.isEmpty()) {
                    errorMsg = "未知错误";
                }
                MessageDialog.showDialog("保存失败：" + errorMsg);
            }
        } else {
            MessageDialog.showDialog("保存失败：服务器响应为空，请检查后端服务是否正常运行");
        }
    }

    /**
     * doNew() doSave() doDelete() 重写 ToolController 中的方法， 实现选择 新建，保存，删除 对学生的增，删，改操作
     */
    public void doNew() {
        clearPanel();
    }

    public void doSave() {
        onSaveButtonClick();
    }

    public void doDelete() {
        onDeleteButtonClick();
    }

    /**
     * 导出学生信息表的示例 重写ToolController 中的doExport 这里给出了一个导出学生基本信息到Excl表的示例， 后台生成Excl文件数据，传回前台，前台将文件保存到本地
     */
    public void doExport() {
        String numName = numNameTextField.getText();
        DataRequest req = new DataRequest();
        req.add("numName", numName);
        byte[] bytes = HttpRequestUtil.requestByteData("/api/student/getStudentListExcl", req);
        if (bytes != null) {
            try {
                FileChooser fileDialog = new FileChooser();
                fileDialog.setTitle("前选择保存的文件");
                fileDialog.setInitialDirectory(new File("C:/"));
                fileDialog.getExtensionFilters().addAll(
                        new FileChooser.ExtensionFilter("XLSX 文件", "*.xlsx"));
                File file = fileDialog.showSaveDialog(null);
                if (file != null) {
                    FileOutputStream out = new FileOutputStream(file);
                    out.write(bytes);
                    out.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    @FXML
    protected void onImportButtonClick() {
        FileChooser fileDialog = new FileChooser();
        fileDialog.setTitle("前选择学生数据表");
        fileDialog.setInitialDirectory(new File("D:/"));
        fileDialog.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("XLSX 文件", "*.xlsx"));
        File file = fileDialog.showOpenDialog(null);
        
        // 检查用户是否取消了文件选择
        if (file == null) {
            return;
        }
        
        String paras = "";
        DataResponse res = HttpRequestUtil.importData("/api/term/importStudentData", file.getPath(), paras);
        if (res != null) {
            if (res.getCode() == 0) {
                MessageDialog.showDialog("上传成功！");
                onQueryButtonClick(); // 刷新数据
            } else {
                MessageDialog.showDialog(res.getMsg());
            }
        } else {
            MessageDialog.showDialog("导入失败：服务器响应为空");
        }
    }

    @FXML
    protected void onFamilyButtonClick() {
        DataRequest req = new DataRequest();
        req.add("personId", personId);
        DataResponse res = HttpRequestUtil.request("/api/student/getFamilyMemberList", req);
        if (res.getCode() != 0) {
            MessageDialog.showDialog(res.getMsg());
            return;
        }
        List<Map> familyList = (List<Map>) res.getData();
        ObservableList<Map> oList = FXCollections.observableArrayList(familyList);
        Scene scene = null, pScene = null;
        Stage stage;
        stage = new Stage();
        TableView<Map> table = new TableView<>(oList);
        table.setEditable(true);
        TableColumn<Map, String> relationColumn = new TableColumn<>("关系");
        relationColumn.setCellValueFactory(new MapValueFactory("relation"));
        relationColumn.setCellFactory(TextFieldTableCell.<Map>forTableColumn());
        relationColumn.setOnEditCommit(event -> {
            TableView tempTable = event.getTableView();
            Map tempEntity = (Map) tempTable.getItems().get(event.getTablePosition().getRow());
            tempEntity.put("relation",event.getNewValue());
        });
        table.getColumns().add(relationColumn);
        TableColumn<Map, String> nameColumn = new TableColumn<>("姓名");
        nameColumn.setCellValueFactory(new MapValueFactory<>("name"));
        nameColumn.setCellFactory(TextFieldTableCell.<Map>forTableColumn());
        table.getColumns().add(nameColumn);
        TableColumn<Map, String> genderColumn = new TableColumn<>("性别");
        genderColumn.setCellValueFactory(new MapValueFactory<>("gender"));
        genderColumn.setCellFactory(TextFieldTableCell.<Map>forTableColumn());
        table.getColumns().add(genderColumn);
        TableColumn<Map, String> ageColumn = new TableColumn<>("年龄");
        ageColumn.setCellValueFactory(new MapValueFactory<>("age"));
        ageColumn.setCellFactory(TextFieldTableCell.<Map>forTableColumn());
        table.getColumns().add(ageColumn);
        TableColumn<Map, String> unitColumn = new TableColumn<>("单位");
        unitColumn.setCellValueFactory(new MapValueFactory<>("unit"));
        unitColumn.setCellFactory(TextFieldTableCell.<Map>forTableColumn());
        table.getColumns().add(unitColumn);
        BorderPane root = new BorderPane();
        FlowPane flowPane = new FlowPane();
        Button obButton = new Button("确定");
        obButton.setOnAction(event -> {
            for(Map map: table.getItems()) {
                System.out.println("map:"+map);
            }
            stage.close();
        });
        flowPane.getChildren().add(obButton);
        root.setCenter(table);
        root.setBottom(flowPane);
        scene = new Scene(root, 260, 140);
        stage.initOwner(MainApplication.getMainStage());
        stage.initModality(Modality.NONE);
        stage.setAlwaysOnTop(true);
        stage.setScene(scene);
        stage.setTitle("成绩录入对话框！");
        stage.setOnCloseRequest(event -> {
            MainApplication.setCanClose(true);
        });
        stage.showAndWait();
    }
    public void displayPhoto(){
        DataRequest req = new DataRequest();
        req.add("fileName", "photo/" + personId + ".jpg");  //个人照片显示
        byte[] bytes = HttpRequestUtil.requestByteData("/api/base/getFileByteData", req);
        if (bytes != null) {
            ByteArrayInputStream in = new ByteArrayInputStream(bytes);
            Image img = new Image(in);
            photoImageView.setImage(img);
        }

    }

    @FXML
    public void onPhotoButtonClick(){
        if (personId == null) {
            MessageDialog.showDialog("请先选择学生");
            return;
        }

        FileChooser fileDialog = new FileChooser();
        fileDialog.setTitle("图片上传");
        fileDialog.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("JPG 文件", "*.jpg"));
        File file = fileDialog.showOpenDialog(null);
        if(file == null)
            return;

        try {
            System.out.println("开始上传图片，personId: " + personId);
            System.out.println("文件路径: " + file.getPath());
            System.out.println("文件大小: " + file.length() + " bytes");
            System.out.println("文件是否存在: " + file.exists());
            System.out.println("文件是否可读: " + file.canRead());
            
            String targetPath = "photo/" + personId + ".jpg";
            System.out.println("目标路径: " + targetPath);
            
            // 检查JWT令牌
            if (AppStore.getJwt() == null || AppStore.getJwt().getToken() == null) {
                System.out.println("警告: JWT令牌不存在");
                MessageDialog.showDialog("请先登录系统");
                return;
            }
            
            DataResponse res = HttpRequestUtil.uploadFile("/api/base/uploadPhoto", file.getPath(), targetPath);
            if(res != null) {
                System.out.println("服务器响应: " + res.getCode() + " - " + res.getMsg());
                if (res.getCode() == 0) {
                    MessageDialog.showDialog("上传成功！");
                    displayPhoto();
                } else {
                    String errorMsg = res.getMsg();
                    if (errorMsg == null || errorMsg.isEmpty()) {
                        errorMsg = "上传失败，请稍后重试";
                    }
                    MessageDialog.showDialog("上传失败：" + errorMsg);
                }
            } else {
                System.out.println("服务器响应为空");
                MessageDialog.showDialog("上传失败：服务器响应为空");
            }
        } catch (Exception e) {
            System.out.println("上传过程发生异常: " + e.getMessage());
            e.printStackTrace();
            MessageDialog.showDialog("上传失败：" + e.getMessage());
        }
    }
    @FXML
    public void onImportFeeButtonClick() {
        FileChooser fileDialog = new FileChooser();
        fileDialog.setTitle("前选择消费数据表");
        fileDialog.setInitialDirectory(new File("C:/"));
        fileDialog.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("XLSX 文件", "*.xlsx"));
        File file = fileDialog.showOpenDialog(null);
        
        // 检查用户是否取消了文件选择
        if (file == null) {
            return;
        }
        
        String paras = "personId=" + personId;
        DataResponse res = HttpRequestUtil.importData("/api/student/importFeeData", file.getPath(), paras);
        if (res != null) {
            if (res.getCode() == 0) {
                MessageDialog.showDialog("上传成功！");
            } else {
                MessageDialog.showDialog(res.getMsg());
            }
        } else {
            MessageDialog.showDialog("导入失败：服务器响应为空");
        }
    }

    /**
     * 更新学生数据
     * 用于从StudentEditController中接收编辑后的学生数据
     * @param studentData 学生数据
     */
    public void updateStudentData(Map<String, Object> studentData) {
        if (studentData != null) {
            // 检查是否为更新操作
            boolean isNewStudent = true;
            Integer studentId = CommonMethod.getInteger(studentData, "personId");
            
            for (int i = 0; i < studentList.size(); i++) {
                Map<String, Object> item = studentList.get(i);
                Integer itemId = CommonMethod.getInteger(item, "personId");
                
                if (itemId != null && itemId.equals(studentId)) {
                    // 更新现有数据
                    studentList.set(i, studentData);
                    isNewStudent = false;
                    break;
                }
            }
            
            // 如果是新学生，添加到列表
            if (isNewStudent) {
                studentList.add(studentData);
            }
            
            // 刷新表格
            setTableViewData();
            
            // 选中更新的行
            for (int i = 0; i < studentList.size(); i++) {
                Map<String, Object> item = studentList.get(i);
                Integer itemId = CommonMethod.getInteger(item, "personId");
                
                if (itemId != null && itemId.equals(studentId)) {
                    dataTableView.getSelectionModel().select(i);
                    break;
                }
            }
            
            // 如果右侧面板已经显示了这个学生的数据，更新显示
            if (personId != null && personId.equals(studentId)) {
                displayStudentInfo(studentData);
            }
        }
    }

    /**
     * 显示学生详细信息到右侧面板
     */
    private void displayStudentInfo(Map<String, Object> studentData) {
        if (studentData != null) {
            personId = CommonMethod.getInteger(studentData, "personId");
            numField.setText(CommonMethod.getString(studentData, "num"));
            nameField.setText(CommonMethod.getString(studentData, "name"));
            deptField.setText(CommonMethod.getString(studentData, "dept"));
            majorField.setText(CommonMethod.getString(studentData, "major"));
            classNameField.setText(CommonMethod.getString(studentData, "className"));
            cardField.setText(CommonMethod.getString(studentData, "card"));
            
            // 设置性别
            String gender = CommonMethod.getString(studentData, "gender");
            for (OptionItem item : genderList) {
                if (item.getValue().equals(gender)) {
                    genderComboBox.setValue(item);
                    break;
                }
            }
            
            // 设置出生日期
            LocalDate birthday = null;
            String birthdayStr = CommonMethod.getString(studentData, "birthday");
            if (birthdayStr != null && !birthdayStr.isEmpty()) {
                try {
                    birthday = LocalDate.parse(birthdayStr);
                } catch (Exception e) {
                    birthday = null;
                }
            }
            birthdayPick.setValue(birthday);
            
            emailField.setText(CommonMethod.getString(studentData, "email"));
            phoneField.setText(CommonMethod.getString(studentData, "phone"));
            addressField.setText(CommonMethod.getString(studentData, "address"));
        }
    }

    /**
     * 编辑选中的学生
     */
    @FXML
    protected void onEditButtonClick() {
        Map<String, Object> selectedStudent = dataTableView.getSelectionModel().getSelectedItem();
        if (selectedStudent == null) {
            MessageDialog.showDialog("请先选择一名学生");
            return;
        }

        try {
            // 加载学生编辑对话框FXML
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/teach/javafx/student-edit-dialog.fxml"));
            VBox dialogPane = loader.load();
            
            // 获取对话框控制器
            StudentEditController controller = loader.getController();
            controller.setStudentController(this);
            controller.setStudentData(selectedStudent); // 传入选中的学生数据
            
            // 创建对话框
            Stage dialogStage = new Stage();
            dialogStage.setTitle("编辑学生");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(numField.getScene().getWindow());
            
            // 设置对话框场景
            Scene scene = new Scene(dialogPane);
            dialogStage.setScene(scene);
            
            // 显示对话框
            dialogStage.showAndWait();
            
        } catch (IOException e) {
            e.printStackTrace();
            MessageDialog.showDialog("打开学生编辑对话框失败: " + e.getMessage());
        }
    }

}
