package com.teach.javafx.controller;

import com.teach.javafx.controller.base.MessageDialog;
import com.teach.javafx.request.DataRequest;
import com.teach.javafx.request.DataResponse;
import com.teach.javafx.request.HttpRequestUtil;
import com.teach.javafx.request.OptionItem;
import com.teach.javafx.util.CommonMethod;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HonorEditController {
    @FXML
    private ComboBox<OptionItem> studentComboBox;
    @FXML
    private TextField titleField;
    @FXML
    private ComboBox<OptionItem> honorTypeComboBox;
    @FXML
    private ComboBox<OptionItem> levelComboBox;
    @FXML
    private DatePicker awardDatePicker;
    @FXML
    private TextField issuerField;
    @FXML
    private TextField certificateNumberField;
    @FXML
    private TextArea descriptionArea;

    private HonorController honorController;
    private Integer honorId;
    private List<OptionItem> studentList;
    private List<OptionItem> honorTypeList;
    private List<OptionItem> levelList;
    private final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    @FXML
    public void initialize() {
        initComboBoxes();
    }

    private void initComboBoxes() {
        // 获取学生列表
        DataRequest req = new DataRequest();
        List<OptionItem> studentItems = HttpRequestUtil.requestOptionItemList("/api/honor/getStudentItemOptionList", req);
        if (studentItems != null) {
            studentList = studentItems;
            // 添加"请选择"选项
            OptionItem defaultItem = new OptionItem(null, "0", "请选择");
            studentComboBox.getItems().add(defaultItem);
            studentComboBox.getItems().addAll(studentList);
            studentComboBox.setValue(defaultItem);
        }

        // 初始化荣誉类型
        honorTypeList = new ArrayList<>();
        honorTypeList.add(new OptionItem(1, "1", "奖学金"));
        honorTypeList.add(new OptionItem(2, "2", "学科竞赛"));
        honorTypeList.add(new OptionItem(3, "3", "科研成果"));
        honorTypeList.add(new OptionItem(4, "4", "社会工作"));
        honorTypeList.add(new OptionItem(5, "5", "文体活动"));
        honorTypeList.add(new OptionItem(6, "6", "荣誉称号"));
        honorTypeList.add(new OptionItem(7, "7", "其他"));
        honorTypeComboBox.getItems().addAll(honorTypeList);

        // 初始化荣誉级别
        levelList = new ArrayList<>();
        levelList.add(new OptionItem(1, "1", "国家级"));
        levelList.add(new OptionItem(2, "2", "省级"));
        levelList.add(new OptionItem(3, "3", "市级"));
        levelList.add(new OptionItem(4, "4", "校级"));
        levelList.add(new OptionItem(5, "5", "院级"));
        levelList.add(new OptionItem(6, "6", "班级"));
        levelComboBox.getItems().addAll(levelList);

        // 设置默认值
        if (!honorTypeList.isEmpty()) {
            honorTypeComboBox.setValue(honorTypeList.get(0));
        }
        if (!levelList.isEmpty()) {
            levelComboBox.setValue(levelList.get(0));
        }
        awardDatePicker.setValue(LocalDate.now());
    }

    public void setHonorController(HonorController honorController) {
        this.honorController = honorController;
    }

    public void showDialog(Map<String, Object> data) {
        if (data == null) {
            // 新增模式
            honorId = null;
            clearForm();
        } else {
            // 编辑模式
            honorId = CommonMethod.getInteger(data, "honorId");
            titleField.setText(CommonMethod.getString(data, "title"));
            
            // 设置学生
            Map<String, Object> student = (Map<String, Object>) data.get("student");
            if (student != null) {
                String personId = String.valueOf(student.get("personId"));
                for (OptionItem item : studentList) {
                    if (personId.equals(item.getValue())) {
                        studentComboBox.setValue(item);
                        break;
                    }
                }
                studentComboBox.setDisable(true); // 编辑模式下不允许更改学生
            } else {
                // 如果没有学生信息，设置为"请选择"
                studentComboBox.setValue(studentComboBox.getItems().get(0));
                studentComboBox.setDisable(false);
            }

            // 设置荣誉类型
            String honorType = CommonMethod.getString(data, "honorType");
            for (OptionItem item : honorTypeList) {
                if (item.getValue().equals(honorType)) {
                    honorTypeComboBox.setValue(item);
                    break;
                }
            }

            // 设置荣誉级别
            String level = CommonMethod.getString(data, "level");
            for (OptionItem item : levelList) {
                if (item.getValue().equals(level)) {
                    levelComboBox.setValue(item);
                    break;
                }
            }

            // 设置日期
            String awardDate = CommonMethod.getString(data, "awardDate");
            if (awardDate != null && !awardDate.isEmpty()) {
                try {
                    LocalDate date = LocalDate.parse(awardDate, dateFormatter);
                    awardDatePicker.setValue(date);
                } catch (Exception e) {
                    awardDatePicker.setValue(LocalDate.now());
                }
            }

            issuerField.setText(CommonMethod.getString(data, "issuer"));
            certificateNumberField.setText(CommonMethod.getString(data, "certificateNumber"));
            descriptionArea.setText(CommonMethod.getString(data, "description"));
        }
    }

    private void clearForm() {
        // 设置为"请选择"并启用学生选择
        studentComboBox.setValue(studentComboBox.getItems().get(0));
        studentComboBox.setDisable(false);
        
        titleField.clear();
        if (!honorTypeList.isEmpty()) {
            honorTypeComboBox.setValue(honorTypeList.get(0));
        }
        if (!levelList.isEmpty()) {
            levelComboBox.setValue(levelList.get(0));
        }
        awardDatePicker.setValue(LocalDate.now());
        issuerField.clear();
        certificateNumberField.clear();
        descriptionArea.clear();
    }

    @FXML
    private void onSaveButtonClick() {
        // 验证表单
        OptionItem selectedStudent = studentComboBox.getValue();
        if (selectedStudent == null || selectedStudent.getValue().equals("0")) {
            MessageDialog.showDialog("请选择学生");
            return;
        }
        if (titleField.getText().trim().isEmpty()) {
            MessageDialog.showDialog("请输入荣誉称号");
            return;
        }
        if (honorTypeComboBox.getValue() == null) {
            MessageDialog.showDialog("请选择荣誉类型");
            return;
        }
        if (levelComboBox.getValue() == null) {
            MessageDialog.showDialog("请选择荣誉级别");
            return;
        }
        if (awardDatePicker.getValue() == null) {
            MessageDialog.showDialog("请选择获奖日期");
            return;
        }

        try {
            // 构建保存数据
            Map<String, Object> data = new HashMap<>();
            data.put("personId", Integer.parseInt(selectedStudent.getValue()));
            data.put("honorId", honorId);
            data.put("title", titleField.getText().trim());
            data.put("honorType", honorTypeComboBox.getValue().getValue());
            data.put("level", levelComboBox.getValue().getValue());
            data.put("awardDate", awardDatePicker.getValue().format(dateFormatter));
            data.put("issuer", issuerField.getText());
            data.put("certificateNumber", certificateNumberField.getText());
            data.put("description", descriptionArea.getText());

            // 打印请求数据，用于调试
            System.out.println("保存荣誉数据: " + data);
            
            honorController.doClose("ok", data);
        } catch (Exception e) {
            e.printStackTrace();
            MessageDialog.showDialog("保存数据时发生错误: " + e.getMessage());
        }
    }

    @FXML
    private void onCancelButtonClick() {
        honorController.doClose("cancel", null);
    }
} 