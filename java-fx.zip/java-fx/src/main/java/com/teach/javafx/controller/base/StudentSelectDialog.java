package com.teach.javafx.controller.base;

import com.teach.javafx.request.DataRequest;
import com.teach.javafx.request.DataResponse;
import com.teach.javafx.request.HttpRequestUtil;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.util.List;
import java.util.Map;

public class StudentSelectDialog {
    private static Map<String, Object> selectedStudent = null;

    public static Map<String, Object> showDialog() {
        Stage dialog = new Stage(StageStyle.UTILITY);
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.setTitle("选择学生");
        dialog.setWidth(600);
        dialog.setHeight(400);

        BorderPane root = new BorderPane();
        root.setPadding(new Insets(10));

        // 搜索区域
        HBox searchBox = new HBox(10);
        searchBox.setPadding(new Insets(0, 0, 10, 0));
        TextField searchField = new TextField();
        searchField.setPromptText("输入学号或姓名搜索");
        searchField.setPrefWidth(200);
        Button searchButton = new Button("搜索");
        searchBox.getChildren().addAll(new Label("搜索："), searchField, searchButton);

        // 表格
        TableView<Map<String, Object>> tableView = new TableView<>();
        TableColumn<Map<String, Object>, String> numColumn = new TableColumn<>("学号");
        numColumn.setCellValueFactory(data -> new SimpleStringProperty(
                data.getValue().get("num") != null ? data.getValue().get("num").toString() : ""));
        
        TableColumn<Map<String, Object>, String> nameColumn = new TableColumn<>("姓名");
        nameColumn.setCellValueFactory(data -> new SimpleStringProperty(
                data.getValue().get("name") != null ? data.getValue().get("name").toString() : ""));
        
        TableColumn<Map<String, Object>, String> classColumn = new TableColumn<>("班级");
        classColumn.setCellValueFactory(data -> new SimpleStringProperty(
                data.getValue().get("className") != null ? data.getValue().get("className").toString() : ""));

        tableView.getColumns().addAll(numColumn, nameColumn, classColumn);
        
        // 按钮区域
        HBox buttonBox = new HBox(10);
        buttonBox.setPadding(new Insets(10, 0, 0, 0));
        buttonBox.setStyle("-fx-alignment: center-right;");
        Button selectButton = new Button("选择");
        Button cancelButton = new Button("取消");
        buttonBox.getChildren().addAll(selectButton, cancelButton);

        VBox mainBox = new VBox(10);
        mainBox.getChildren().addAll(searchBox, tableView);
        
        root.setCenter(mainBox);
        root.setBottom(buttonBox);

        Scene scene = new Scene(root);
        dialog.setScene(scene);

        // 数据列表
        ObservableList<Map<String, Object>> dataList = FXCollections.observableArrayList();
        tableView.setItems(dataList);

        // 加载数据
        Runnable loadData = () -> {
            DataRequest request = new DataRequest();
            String keyword = searchField.getText();
            if (keyword != null && !keyword.isEmpty()) {
                request.add("keyword", keyword);
            }
            
            DataResponse response = HttpRequestUtil.request("/api/student/list", request);
            if (response != null && response.getData() != null) {
                dataList.clear();
                List<Map<String, Object>> list = (List<Map<String, Object>>) response.getData();
                dataList.addAll(list);
            }
        };

        // 绑定事件
        searchButton.setOnAction(e -> loadData.run());
        
        selectButton.setOnAction(e -> {
            Map<String, Object> selected = tableView.getSelectionModel().getSelectedItem();
            if (selected != null) {
                selectedStudent = selected;
                dialog.close();
            } else {
                MessageDialog.showDialog("请先选择一个学生");
            }
        });
        
        cancelButton.setOnAction(e -> {
            selectedStudent = null;
            dialog.close();
        });

        // 初始加载数据
        loadData.run();

        // 显示对话框
        dialog.showAndWait();

        return selectedStudent;
    }
} 