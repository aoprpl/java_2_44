package com.teach.javafx.controller;

import com.teach.javafx.controller.base.MessageDialog;
import com.teach.javafx.request.DataRequest;
import com.teach.javafx.request.DataResponse;
import com.teach.javafx.request.HttpRequestUtil;
import com.teach.javafx.request.OptionItem;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.geometry.Insets;
import javafx.geometry.Pos;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 学生创新成就管理控制器
 */
public class InnovationController {
    // 查询和列表展示相关组件
    @FXML
    private TextField keywordTextField;
    
    @FXML
    private ComboBox<OptionItem> typeComboBox;
    
    @FXML
    private ComboBox<OptionItem> levelComboBox;
    
    @FXML
    private ComboBox<OptionItem> statusComboBox;
    
    @FXML
    private TableView<Map<String, Object>> dataTableView;
    
    @FXML
    private TableColumn<Map<String, Object>, String> studentNameColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> studentNumColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> nameColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> innovationTypeColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> levelColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> achieveTimeColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> statusColumn;
    
    // 详情编辑相关组件
    @FXML
    private TextField studentField;
    
    @FXML
    private TextField nameField;
    
    @FXML
    private ComboBox<OptionItem> achieveLevelComboBox;
    
    @FXML
    private DatePicker achieveDatePicker;
    
    @FXML
    private TextField organizationField;
    
    @FXML
    private TextField certificateNumberField;
    
    @FXML
    private ComboBox<OptionItem> achieveStatusComboBox;
    
    @FXML
    private TextArea descriptionArea;
    
    @FXML
    private TextField teacherField;
    
    // 数据列表
    private ObservableList<Map<String, Object>> dataList = FXCollections.observableArrayList();
    
    // 当前选中的学生
    private Map<String, Object> selectedStudent = null;
    
    // 当前创新成就ID
    private Integer currentInnovationId = null;
    
    // 日期时间格式化器
    private final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    
    private InnovationEditController innovationEditController = null;
    private Stage editStage = null;
    
    @FXML
    private TableView<Map<String, Object>> studentInnovationTableView;
    @FXML
    private TableColumn<Map<String, Object>, String> nameColumn2;
    @FXML
    private TableColumn<Map<String, Object>, String> innovationTypeColumn2;
    @FXML
    private TableColumn<Map<String, Object>, String> levelColumn2;
    @FXML
    private TableColumn<Map<String, Object>, String> achieveTimeColumn2;
    @FXML
    private TableColumn<Map<String, Object>, String> organizationColumn2;
    @FXML
    private TableColumn<Map<String, Object>, String> statusColumn2;
    private ObservableList<Map<String, Object>> studentInnovationList = FXCollections.observableArrayList();
    
    @FXML
    private ComboBox<OptionItem> innovationTypeComboBox;
    @FXML
    private TableColumn<Map<String, Object>, String> teacherColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> organizationColumn;
    
    /**
     * 初始化方法，JavaFX初始化时自动调用
     */
    @FXML
    private void initialize() {
        // 初始化表格列
        studentNameColumn.setCellValueFactory(cellData -> {
            Map<String, Object> student = (Map<String, Object>) cellData.getValue().get("student");
            if (student != null) {
                return new SimpleStringProperty(String.valueOf(student.get("name")));
            }
            return new SimpleStringProperty("");
        });
        
        studentNumColumn.setCellValueFactory(cellData -> {
            Map<String, Object> student = (Map<String, Object>) cellData.getValue().get("student");
            if (student != null) {
                return new SimpleStringProperty(String.valueOf(student.get("num")));
            }
            return new SimpleStringProperty("");
        });
        
        nameColumn.setCellValueFactory(cellData -> 
            new SimpleStringProperty(String.valueOf(cellData.getValue().get("name"))));
        
        innovationTypeColumn.setCellValueFactory(cellData -> {
            String innovationType = String.valueOf(cellData.getValue().get("innovationType"));
            for (OptionItem item : typeComboBox.getItems()) {
                if (item.getValue().equals(innovationType)) {
                    return new SimpleStringProperty(item.getTitle());
                }
            }
            return new SimpleStringProperty(innovationType);
        });
        
        levelColumn.setCellValueFactory(cellData -> {
            String level = String.valueOf(cellData.getValue().get("level"));
            for (OptionItem item : achieveLevelComboBox.getItems()) {
                if (item.getValue().equals(level)) {
                    return new SimpleStringProperty(item.getTitle());
                }
            }
            return new SimpleStringProperty(level);
        });
        
        achieveTimeColumn.setCellValueFactory(cellData -> {
            Object value = cellData.getValue().get("achieveTime");
            if (value != null && !value.toString().isEmpty()) {
                try {
                    LocalDateTime dateTime = LocalDateTime.parse(value.toString(), dateTimeFormatter);
                    return new SimpleStringProperty(dateTime.format(dateFormatter));
                } catch (Exception e) {
                    return new SimpleStringProperty(value.toString());
                }
            }
            return new SimpleStringProperty("");
        });
        
        statusColumn.setCellValueFactory(cellData -> {
            String status = String.valueOf(cellData.getValue().get("status"));
            for (OptionItem item : statusComboBox.getItems()) {
                if (item.getValue().equals(status)) {
                    return new SimpleStringProperty(item.getTitle());
                }
            }
            return new SimpleStringProperty(status);
        });
        
        // 添加行样式类，根据状态设置不同的背景颜色
        dataTableView.setRowFactory(tv -> {
            TableRow<Map<String, Object>> row = new TableRow<>();
            row.itemProperty().addListener((obs, oldItem, newItem) -> {
                if (newItem != null) {
                    String status = String.valueOf(newItem.get("status"));
                    // 清除所有状态样式
                    row.getStyleClass().removeAll("status-approved", "status-pending", "status-rejected");
                    
                    // 根据状态添加对应的样式类
                    if ("2".equals(status)) {
                        row.getStyleClass().add("status-approved");
                    } else if ("1".equals(status)) {
                        row.getStyleClass().add("status-pending");
                    } else if ("3".equals(status)) {
                        row.getStyleClass().add("status-rejected");
                    }
                }
            });
            return row;
        });
        
        // 绑定数据列表到表格
        dataTableView.setItems(dataList);
        
        // 表格选择事件
        dataTableView.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                displayInnovationDetails(newSelection);
                // 同步刷新currentInnovationId
                currentInnovationId = safeGetInteger(newSelection, "innovationId");
                Map<String, Object> student = (Map<String, Object>) newSelection.get("student");
                if (student != null) {
                    Integer studentId = safeGetInteger(student, "personId");
                    loadStudentInnovations(studentId);
                }
            }
        });
        
        // 表格样式
        dataTableView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        
        // 初始化下拉框
        initComboBoxes();
        
        // 加载数据
        loadData();
        
        // 让studentField只读
        studentField.setEditable(false);
        
        // 初始化右侧学生创新成就表格
        nameColumn2.setCellValueFactory(cellData -> new SimpleStringProperty(String.valueOf(cellData.getValue().get("name"))));
        innovationTypeColumn2.setCellValueFactory(cellData -> {
            String innovationType = String.valueOf(cellData.getValue().get("innovationType"));
            for (OptionItem item : typeComboBox.getItems()) {
                if (item.getValue().equals(innovationType)) {
                    return new SimpleStringProperty(item.getTitle());
                }
            }
            return new SimpleStringProperty(innovationType);
        });
        levelColumn2.setCellValueFactory(cellData -> {
            String level = String.valueOf(cellData.getValue().get("level"));
            for (OptionItem item : achieveLevelComboBox.getItems()) {
                if (item.getValue().equals(level)) {
                    return new SimpleStringProperty(item.getTitle());
                }
            }
            return new SimpleStringProperty(level);
        });
        achieveTimeColumn2.setCellValueFactory(cellData -> new SimpleStringProperty(String.valueOf(cellData.getValue().get("achieveTime"))));
        organizationColumn2.setCellValueFactory(cellData -> {
            Object value = cellData.getValue().get("organization");
            return new SimpleStringProperty(value != null ? value.toString() : "");
        });
        statusColumn2.setCellValueFactory(cellData -> {
            String status = String.valueOf(cellData.getValue().get("status"));
            for (OptionItem item : statusComboBox.getItems()) {
                if (item.getValue().equals(status)) {
                    return new SimpleStringProperty(item.getTitle());
                }
            }
            return new SimpleStringProperty(status);
        });
        studentInnovationTableView.setItems(studentInnovationList);
        
        // 初始化右侧创新类型下拉框
        innovationTypeComboBox.setItems(typeComboBox.getItems());
        
        // 左侧主表格指导老师列
        teacherColumn.setCellValueFactory(cellData -> new SimpleStringProperty(String.valueOf(cellData.getValue().get("teacher"))));
        
        // 左侧主表格主办单位
        organizationColumn.setCellValueFactory(cellData -> {
            Object value = cellData.getValue().get("organization");
            return new SimpleStringProperty(value != null ? value.toString() : "");
        });
    }
    
    /**
     * 初始化下拉框
     */
    private void initComboBoxes() {
        // 创新类型下拉框
        List<OptionItem> innovationTypes = HttpRequestUtil.getDictionaryOptionItemList("CXLX");
        
        // 如果从服务器获取的类型为空，添加一些默认值
        if (innovationTypes == null || innovationTypes.isEmpty()) {
            innovationTypes = new ArrayList<>();
            innovationTypes.add(new OptionItem(1, "1", "科研项目"));
            innovationTypes.add(new OptionItem(2, "2", "科技竞赛"));
            innovationTypes.add(new OptionItem(3, "3", "发明专利"));
            innovationTypes.add(new OptionItem(4, "4", "学术论文"));
            innovationTypes.add(new OptionItem(5, "5", "创业项目"));
            innovationTypes.add(new OptionItem(6, "6", "其他"));
        }
        
        typeComboBox.setItems(FXCollections.observableArrayList(innovationTypes));
        
        // 创新成就级别下拉框
        List<OptionItem> innovationLevels = HttpRequestUtil.getDictionaryOptionItemList("CXJB");
        
        // 如果从服务器获取的级别为空，添加一些默认值
        if (innovationLevels == null || innovationLevels.isEmpty()) {
            innovationLevels = new ArrayList<>();
            innovationLevels.add(new OptionItem(1, "1", "国家级"));
            innovationLevels.add(new OptionItem(2, "2", "省级"));
            innovationLevels.add(new OptionItem(3, "3", "市级"));
            innovationLevels.add(new OptionItem(4, "4", "校级"));
            innovationLevels.add(new OptionItem(5, "5", "院级"));
        }
        
        levelComboBox.setItems(FXCollections.observableArrayList(innovationLevels));
        achieveLevelComboBox.setItems(FXCollections.observableArrayList(innovationLevels));
        
        // 审批状态下拉框
        List<OptionItem> approveStatus = HttpRequestUtil.getDictionaryOptionItemList("SPZT");
        
        // 如果从服务器获取的状态为空，添加一些默认值
        if (approveStatus == null || approveStatus.isEmpty()) {
            approveStatus = new ArrayList<>();
            approveStatus.add(new OptionItem(1, "1", "待审批"));
            approveStatus.add(new OptionItem(2, "2", "已批准"));
            approveStatus.add(new OptionItem(3, "3", "已拒绝"));
        }
        
        statusComboBox.setItems(FXCollections.observableArrayList(approveStatus));
        achieveStatusComboBox.setItems(FXCollections.observableArrayList(approveStatus));
        
        // 设置默认值
        if (!innovationTypes.isEmpty()) {
            typeComboBox.setValue(null); // 查询时默认不选择
        }
        
        if (!innovationLevels.isEmpty()) {
            levelComboBox.setValue(null); // 查询时默认不选择
            achieveLevelComboBox.setValue(innovationLevels.get(0)); // 默认国家级
        }
        
        if (!approveStatus.isEmpty()) {
            statusComboBox.setValue(null); // 查询时默认不选择
            achieveStatusComboBox.setValue(approveStatus.get(0)); // 默认待审批
        }
    }
    
    /**
     * 加载创新成就数据
     */
    public void loadData() {
        DataRequest request = new DataRequest();
        
        String keyword = keywordTextField.getText();
        if (keyword != null && !keyword.isEmpty()) {
            request.add("keyword", keyword);
        }
        
        OptionItem selectedType = typeComboBox.getValue();
        if (selectedType != null) {
            request.add("innovationType", selectedType.getValue());
        }
        
        OptionItem selectedLevel = levelComboBox.getValue();
        if (selectedLevel != null) {
            request.add("level", selectedLevel.getValue());
        }
        
        OptionItem selectedStatus = statusComboBox.getValue();
        if (selectedStatus != null) {
            request.add("status", selectedStatus.getValue());
        }
        
        DataResponse response = HttpRequestUtil.request("/api/innovation/list", request);
        if (response != null && response.getData() != null) {
            dataList.clear();
            List<Map<String, Object>> list = (List<Map<String, Object>>) response.getData();
            dataList.addAll(list);
        }
    }
    
    /**
     * 显示创新成就详情
     */
    private void displayInnovationDetails(Map<String, Object> innovation) {
        clearForm();
        
        // 设置当前创新成就ID
        currentInnovationId = safeGetInteger(innovation, "innovationId");
        
        // 设置学生信息
        Map<String, Object> student = (Map<String, Object>) innovation.get("student");
        if (student != null) {
            selectedStudent = student;
            String name = String.valueOf(student.get("name"));
            String num = String.valueOf(student.get("num"));
            studentField.setText(name + " (" + num + ")");
        }
        
        // 设置成就名称
        nameField.setText(String.valueOf(innovation.get("name")));
        
        // 设置创新类型
        String innovationType = String.valueOf(innovation.get("innovationType"));
        if (innovationType != null && !innovationType.equals("null")) {
            for (OptionItem item : innovationTypeComboBox.getItems()) {
                if (item.getValue().equals(innovationType)) {
                    innovationTypeComboBox.setValue(item);
                    break;
                }
            }
        }
        
        // 设置级别
        String level = String.valueOf(innovation.get("level"));
        if (level != null && !level.equals("null")) {
            for (OptionItem item : achieveLevelComboBox.getItems()) {
                if (item.getValue().equals(level)) {
                    achieveLevelComboBox.setValue(item);
                    break;
                }
            }
        }
        
        // 设置获得时间
        String achieveTimeStr = (String) innovation.get("achieveTime");
        if (achieveTimeStr != null && !achieveTimeStr.isEmpty()) {
            try {
                LocalDateTime achieveTime = LocalDateTime.parse(achieveTimeStr, dateTimeFormatter);
                achieveDatePicker.setValue(achieveTime.toLocalDate());
            } catch (DateTimeParseException e) {
                System.err.println("Invalid achieve time format: " + achieveTimeStr);
            }
        }
        
        // 设置其他字段
        String organization = String.valueOf(innovation.get("organization"));
        System.out.println("主办单位字段: " + organization); // 调试用
        if (organization != null && !organization.equals("null")) {
            organizationField.setText(organization);
            System.out.println("setText后organizationField内容: " + organizationField.getText());
        } else {
            organizationField.clear();
            System.out.println("setText后organizationField内容: " + organizationField.getText());
        }
        
        String certificateNumber = String.valueOf(innovation.get("certificateNumber"));
        if (certificateNumber != null && !certificateNumber.equals("null")) {
            certificateNumberField.setText(certificateNumber);
        }
        
        // 设置指导老师
        String teacher = String.valueOf(innovation.get("teacher"));
        if (teacher != null && !teacher.equals("null")) {
            teacherField.setText(teacher);
        }
        
        // 设置状态
        String status = String.valueOf(innovation.get("status"));
        if (status != null && !status.equals("null")) {
            for (OptionItem item : achieveStatusComboBox.getItems()) {
                if (item.getValue().equals(status)) {
                    achieveStatusComboBox.setValue(item);
                    break;
                }
            }
        }
        
        String description = String.valueOf(innovation.get("description"));
        if (description != null && !description.equals("null")) {
            descriptionArea.setText(description);
        }
    }
    
    /**
     * 清空表单
     */
    private void clearForm() {
        currentInnovationId = null;
        selectedStudent = null;
        studentField.clear();
        nameField.clear();
        
        if (!typeComboBox.getItems().isEmpty()) {
            typeComboBox.setValue(null);
        }
        
        if (!achieveLevelComboBox.getItems().isEmpty()) {
            achieveLevelComboBox.setValue(achieveLevelComboBox.getItems().get(0));
        }
        
        achieveDatePicker.setValue(LocalDate.now());
        organizationField.clear();
        certificateNumberField.clear();
        
        if (!achieveStatusComboBox.getItems().isEmpty()) {
            achieveStatusComboBox.setValue(achieveStatusComboBox.getItems().get(0));
        }
        
        descriptionArea.clear();
        teacherField.clear();
    }
    
    /**
     * 新增按钮事件
     */
    @FXML
    private void onAddButtonClick(ActionEvent event) {
        try {
            if (editStage == null) {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/teach/javafx/innovation-edit-dialog.fxml"));
                Parent root = loader.load();
                innovationEditController = loader.getController();
                innovationEditController.setInnovationController(this);
                
                editStage = new Stage();
                editStage.setTitle("添加创新成就");
                editStage.initModality(Modality.APPLICATION_MODAL);
                editStage.setScene(new Scene(root));
            }
            
            innovationEditController.showDialog(null);
            editStage.showAndWait();
        } catch (IOException e) {
            e.printStackTrace();
            MessageDialog.showDialog("打开编辑窗口失败：" + e.getMessage());
        }
    }
    
    /**
     * 清空按钮事件
     */
    @FXML
    private void onClearButtonClick(ActionEvent event) {
        clearForm();
    }
    
    /**
     * 删除按钮事件
     */
    @FXML
    private void onDeleteButtonClick(ActionEvent event) {
        Map<String, Object> selected = dataTableView.getSelectionModel().getSelectedItem();
        System.out.println("选中行数据: " + selected);
        if (selected != null) {
            System.out.println("选中行key集合: " + selected.keySet());
            System.out.println("innovationId: " + selected.get("innovationId"));
        }
        Integer innovationId = null;
        if (selected != null && selected.get("innovationId") != null) {
            innovationId = safeGetInteger(selected, "innovationId");
        }
        if (innovationId == null) {
            MessageDialog.showDialog("请先选择要删除的创新成就记录");
            return;
        }
        int choice = MessageDialog.choiceDialog("确定要删除该创新成就记录吗？");
        if (choice != MessageDialog.CHOICE_YES) {
            return;
        }
        DataRequest request = new DataRequest();
        request.add("innovationId", innovationId);
        DataResponse response = HttpRequestUtil.request("/api/innovation/delete", request);
        if (response != null && response.getCode() == 0) {
            MessageDialog.showDialog("删除成功");
            clearForm();
            loadData();
        } else {
            String errorMsg = response != null ? response.getMsg() : "删除失败，请稍后重试";
            MessageDialog.showDialog(errorMsg);
        }
    }
    
    /**
     * 查询按钮事件
     */
    @FXML
    private void onQueryButtonClick(ActionEvent event) {
        loadData();
    }
    
    /**
     * 保存按钮事件
     */
    @FXML
    private void onSaveButtonClick(ActionEvent event) {
        Map<String, Object> selected = dataTableView.getSelectionModel().getSelectedItem();
        Integer innovationId = null;
        if (selected != null && selected.get("innovationId") != null) {
            innovationId = safeGetInteger(selected, "innovationId");
        }
        if (innovationId == null) {
            MessageDialog.showDialog("请先选择要修改的创新成就");
            return;
        }
        // 验证表单
        if (selectedStudent == null) {
            MessageDialog.showDialog("请选择学生");
            return;
        }
        if (nameField.getText().trim().isEmpty()) {
            MessageDialog.showDialog("请输入创新成就名称");
            return;
        }
        if (achieveDatePicker.getValue() == null) {
            MessageDialog.showDialog("请选择获得时间");
            return;
        }
        if (descriptionArea.getText().trim().isEmpty()) {
            MessageDialog.showDialog("请填写成就描述");
            return;
        }
        // 创建请求
        DataRequest request = new DataRequest();
        Map<String, Object> form = new HashMap<>();
        // 设置学生ID
        Integer studentId = safeGetInteger(selectedStudent, "personId");
        form.put("studentId", studentId);
        // 设置成就名称
        form.put("name", nameField.getText().trim());
        // 设置创新类型
        OptionItem selectedType = innovationTypeComboBox.getValue();
        if (selectedType != null) {
            form.put("innovationType", selectedType.getValue());
        }
        // 设置成就级别
        OptionItem selectedLevel = achieveLevelComboBox.getValue();
        if (selectedLevel != null) {
            form.put("level", selectedLevel.getValue());
        }
        // 设置获得时间
        LocalDateTime achieveDateTime = LocalDateTime.of(achieveDatePicker.getValue(), LocalTime.of(0, 0));
        form.put("achieveTime", achieveDateTime.format(dateTimeFormatter));
        // 设置其他字段
        form.put("organization", organizationField.getText().trim());
        form.put("certificateNumber", certificateNumberField.getText().trim());
        form.put("description", descriptionArea.getText().trim());
        // 设置指导老师
        form.put("teacher", teacherField.getText().trim());
        OptionItem selectedStatus = achieveStatusComboBox.getValue();
        if (selectedStatus != null) {
            form.put("status", selectedStatus.getValue());
        }
        request.add("form", form);
        request.add("innovationId", innovationId);
        // 发送请求
        DataResponse response = HttpRequestUtil.request("/api/innovation/edit", request);
        if (response != null && response.getCode() == 0) {
            MessageDialog.showDialog("保存成功");
            // 重新加载数据以显示最新状态
            loadData();
            // 重新选中当前编辑的记录
            for (Map<String, Object> item : dataList) {
                if (safeGetInteger(item, "innovationId").equals(innovationId)) {
                    dataTableView.getSelectionModel().select(item);
                    break;
                }
            }
        } else {
            String errorMsg = response != null ? response.getMsg() : "保存失败，请稍后重试";
            MessageDialog.showDialog(errorMsg);
        }
    }
    
    /**
     * 审批按钮事件
     */
    @FXML
    private void onApproveButtonClick(ActionEvent event) {
        if (currentInnovationId == null) {
            MessageDialog.showDialog("请先选择要审批的创新成就记录");
            return;
        }
        
        // 创建审批对话框
        Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.setTitle("创新成就审批");
        
        VBox dialogVBox = new VBox(10);
        dialogVBox.setPadding(new Insets(20));
        
        // 状态选择
        HBox statusBox = new HBox(10);
        statusBox.setAlignment(Pos.CENTER_LEFT);
        Label statusLabel = new Label("审批结果：");
        ComboBox<OptionItem> statusSelector = new ComboBox<>();
        
        // 过滤出审批相关的状态（已批准/已拒绝）
        List<OptionItem> approvalStatus = new ArrayList<>();
        for (OptionItem item : achieveStatusComboBox.getItems()) {
            if ("2".equals(item.getValue()) || "3".equals(item.getValue())) {
                approvalStatus.add(item);
            }
        }
        
        statusSelector.setItems(FXCollections.observableArrayList(approvalStatus));
        if (!approvalStatus.isEmpty()) {
            statusSelector.setValue(approvalStatus.get(0));
        }
        
        statusBox.getChildren().addAll(statusLabel, statusSelector);
        
        // 审批人
        HBox approverBox = new HBox(10);
        approverBox.setAlignment(Pos.CENTER_LEFT);
        Label approverLabel = new Label("审批人：");
        TextField approverInput = new TextField();
        approverBox.getChildren().addAll(approverLabel, approverInput);
        
        // 审批意见
        Label commentLabel = new Label("审批意见：");
        TextArea commentArea = new TextArea();
        commentArea.setPrefHeight(100);
        
        // 按钮
        HBox buttonBox = new HBox(20);
        buttonBox.setAlignment(Pos.CENTER);
        Button confirmButton = new Button("确认");
        Button cancelButton = new Button("取消");
        buttonBox.getChildren().addAll(confirmButton, cancelButton);
        
        dialogVBox.getChildren().addAll(statusBox, approverBox, commentLabel, commentArea, buttonBox);
        
        // 设置事件
        cancelButton.setOnAction(e -> dialog.close());
        
        confirmButton.setOnAction(e -> {
            if (approverInput.getText().trim().isEmpty()) {
                MessageDialog.showDialog("请填写审批人");
                return;
            }
            
            // 发送审批请求
            DataRequest request = new DataRequest();
            request.add("innovationId", currentInnovationId);
            request.add("status", statusSelector.getValue().getValue());
            request.add("approver", approverInput.getText());
            request.add("approveComment", commentArea.getText());
            
            DataResponse response = HttpRequestUtil.request("/api/innovation/approve", request);
            if (response != null && response.getCode() == 0) {
                MessageDialog.showDialog("审批成功");
                dialog.close();
                loadData();
            } else {
                String errorMsg = response != null ? response.getMsg() : "审批失败，请稍后重试";
                MessageDialog.showDialog(errorMsg);
            }
        });
        
        Scene dialogScene = new Scene(dialogVBox, 400, 300);
        dialog.setScene(dialogScene);
        dialog.showAndWait();
    }
    
    /**
     * 选择学生按钮事件
     */
    @FXML
    private void onSelectStudentButtonClick(ActionEvent event) {
        try {
            // 加载所有学生
            DataRequest request = new DataRequest();
            request.add("numName", ""); // 空字符串表示获取所有学生
            DataResponse response = HttpRequestUtil.request("/api/student/getStudentList", request);
            List<Map<String, Object>> studentsList = new ArrayList<>();
            
            if (response != null && response.getCode() == 0 && response.getData() != null) {
                studentsList = (List<Map<String, Object>>) response.getData();
                
                if (!studentsList.isEmpty()) {
                    // 创建学生选择对话框
                    showStudentSelectionDialog(studentsList);
                } else {
                    MessageDialog.showDialog("没有可选择的学生数据");
                }
            } else {
                String errorMsg = response != null ? response.getMsg() : "无法连接到服务器";
                MessageDialog.showDialog("获取学生列表失败: " + errorMsg);
            }
        } catch (Exception e) {
            e.printStackTrace();
            MessageDialog.showDialog("获取学生列表时发生错误: " + e.getMessage());
        }
    }
    
    private void showStudentSelectionDialog(List<Map<String, Object>> students) {
        try {
            // 创建一个临时表格
            TableView<Map<String, Object>> tableView = new TableView<>();
            tableView.setPrefSize(500, 400);
            
            // 添加列
            TableColumn<Map<String, Object>, String> numCol = new TableColumn<>("学号");
            numCol.setCellValueFactory(cellData -> {
                Object value = cellData.getValue().get("num");
                return new SimpleStringProperty(value != null ? value.toString() : "");
            });
            numCol.setPrefWidth(100);
            
            TableColumn<Map<String, Object>, String> nameCol = new TableColumn<>("姓名");
            nameCol.setCellValueFactory(cellData -> {
                Object value = cellData.getValue().get("name");
                return new SimpleStringProperty(value != null ? value.toString() : "");
            });
            nameCol.setPrefWidth(100);
            
            TableColumn<Map<String, Object>, String> classCol = new TableColumn<>("班级");
            classCol.setCellValueFactory(cellData -> {
                Object value = cellData.getValue().get("className");
                return new SimpleStringProperty(value != null ? value.toString() : "");
            });
            classCol.setPrefWidth(120);
            
            TableColumn<Map<String, Object>, String> deptCol = new TableColumn<>("院系");
            deptCol.setCellValueFactory(cellData -> {
                Object value = cellData.getValue().get("dept");
                return new SimpleStringProperty(value != null ? value.toString() : "");
            });
            deptCol.setPrefWidth(120);
            
            tableView.getColumns().addAll(numCol, nameCol, classCol, deptCol);
            tableView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
            
            // 添加数据
            ObservableList<Map<String, Object>> studentList = FXCollections.observableArrayList(students);
            tableView.setItems(studentList);
            
            // 添加搜索功能
            TextField searchField = new TextField();
            searchField.setPromptText("输入学号或姓名搜索");
            searchField.setPrefWidth(250);
            
            Button searchButton = new Button("搜索");
            searchButton.setOnAction(e -> {
                String keyword = searchField.getText().toLowerCase();
                ObservableList<Map<String, Object>> filteredList = FXCollections.observableArrayList();
                
                for (Map<String, Object> student : students) {
                    String num = String.valueOf(student.get("num")).toLowerCase();
                    String name = String.valueOf(student.get("name")).toLowerCase();
                    
                    if (num.contains(keyword) || name.contains(keyword)) {
                        filteredList.add(student);
                    }
                }
                
                tableView.setItems(filteredList);
            });
            
            HBox searchBox = new HBox(10, new Label("搜索:"), searchField, searchButton);
            searchBox.setPadding(new Insets(10));
            searchBox.setAlignment(Pos.CENTER_LEFT);
            
            // 创建布局
            VBox vbox = new VBox(10);
            vbox.setPadding(new Insets(10));
            
            Label titleLabel = new Label("选择获奖学生");
            titleLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 14px;");
            
            HBox buttonBox = new HBox(10);
            buttonBox.setAlignment(Pos.CENTER);
            
            Button selectButton = new Button("选择");
            Button cancelButton = new Button("取消");
            
            buttonBox.getChildren().addAll(selectButton, cancelButton);
            vbox.getChildren().addAll(titleLabel, searchBox, tableView, buttonBox);
            
            // 创建场景和舞台
            Scene scene = new Scene(vbox);
            Stage stage = new Stage();
            stage.setTitle("选择学生");
            stage.setScene(scene);
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setResizable(false);
            
            // 设置按钮事件
            selectButton.setOnAction(e -> {
                Map<String, Object> selectedStudent = tableView.getSelectionModel().getSelectedItem();
                if (selectedStudent != null) {
                    this.selectedStudent = selectedStudent;
                    String studentName = String.valueOf(selectedStudent.get("name"));
                    String studentNum = String.valueOf(selectedStudent.get("num"));
                    studentField.setText(studentName + " (" + studentNum + ")");
                    stage.close();
                } else {
                    MessageDialog.showDialog("请选择一个学生");
                }
            });
            
            cancelButton.setOnAction(e -> stage.close());
            
            // 显示舞台
            stage.showAndWait();
        } catch (Exception e) {
            e.printStackTrace();
            MessageDialog.showDialog("显示学生选择对话框失败: " + e.getMessage());
        }
    }
    
    /**
     * 安全获取Map中的Integer值
     */
    private Integer safeGetInteger(Map<String, Object> map, String key) {
        Object value = map.get(key);
        return safeGetInteger(value);
    }
    
    /**
     * 安全转换Object为Integer
     */
    private Integer safeGetInteger(Object value) {
        if (value == null) {
            return null;
        }
        
        if (value instanceof Integer) {
            return (Integer) value;
        }
        
        if (value instanceof Double) {
            return ((Double) value).intValue();
        }
        
        try {
            return Integer.parseInt(value.toString());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /**
     * 编辑按钮点击事件
     */
    @FXML
    private void onEditButtonClick(ActionEvent event) {
        Map<String, Object> selectedInnovation = dataTableView.getSelectionModel().getSelectedItem();
        if (selectedInnovation == null) {
            MessageDialog.showDialog("请先选择一条创新成就记录");
            return;
        }
        
        try {
            if (editStage == null) {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/teach/javafx/innovation-edit-dialog.fxml"));
                Parent root = loader.load();
                innovationEditController = loader.getController();
                innovationEditController.setInnovationController(this);
                
                editStage = new Stage();
                editStage.setTitle("编辑创新成就");
                editStage.initModality(Modality.APPLICATION_MODAL);
                editStage.setScene(new Scene(root));
            }
            
            innovationEditController.showDialog(selectedInnovation);
            editStage.showAndWait();
        } catch (IOException e) {
            e.printStackTrace();
            MessageDialog.showDialog("打开编辑窗口失败：" + e.getMessage());
        }
    }
    
    private void loadStudentInnovations(Integer studentId) {
        if (studentId == null) {
            studentInnovationList.clear();
            return;
        }
        DataRequest req = new DataRequest();
        req.add("studentId", studentId);
        DataResponse response = HttpRequestUtil.request("/api/innovation/list", req);
        studentInnovationList.clear();
        if (response != null && response.getData() != null) {
            List<Map<String, Object>> list = (List<Map<String, Object>>) response.getData();
            // 只添加属于该 studentId 的成就
            for (Map<String, Object> item : list) {
                Map<String, Object> student = (Map<String, Object>) item.get("student");
                Integer sid = safeGetInteger(student, "personId");
                if (sid != null && sid.equals(studentId)) {
                    studentInnovationList.add(item);
                }
            }
        }
    }
} 