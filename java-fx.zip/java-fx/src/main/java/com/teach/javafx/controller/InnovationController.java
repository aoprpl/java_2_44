package com.teach.javafx.controller;

import com.teach.javafx.controller.base.MessageDialog;
import com.teach.javafx.request.DataRequest;
import com.teach.javafx.request.DataResponse;
import com.teach.javafx.request.HttpRequestUtil;
import com.teach.javafx.request.OptionItem;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.geometry.Insets;
import javafx.geometry.Pos;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 学生创新成就管理控制器
 */
public class InnovationController {
    // 查询和列表展示相关组件
    @FXML
    private TextField keywordTextField;
    
    @FXML
    private ComboBox<OptionItem> typeComboBox;
    
    @FXML
    private ComboBox<OptionItem> levelComboBox;
    
    @FXML
    private ComboBox<OptionItem> statusComboBox;
    
    @FXML
    private TableView<Map<String, Object>> dataTableView;
    
    @FXML
    private TableColumn<Map<String, Object>, String> studentNameColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> studentNumColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> nameColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> innovationTypeColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> levelColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> achieveTimeColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> statusColumn;
    
    // 详情编辑相关组件
    @FXML
    private TextField studentField;
    
    @FXML
    private TextField nameField;
    
    @FXML
    private ComboBox<OptionItem> achieveLevelComboBox;
    
    @FXML
    private DatePicker achieveDatePicker;
    
    @FXML
    private TextField organizationField;
    
    @FXML
    private TextField certificateNumberField;
    
    @FXML
    private ComboBox<OptionItem> achieveStatusComboBox;
    
    @FXML
    private TextArea descriptionTextArea;
    
    // 数据列表
    private ObservableList<Map<String, Object>> dataList = FXCollections.observableArrayList();
    
    // 当前选中的学生
    private Map<String, Object> selectedStudent = null;
    
    // 当前创新成就ID
    private Integer currentInnovationId = null;
    
    // 日期时间格式化器
    private final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    
    /**
     * 初始化方法，JavaFX初始化时自动调用
     */
    @FXML
    private void initialize() {
        // 初始化表格列
        studentNameColumn.setCellValueFactory(cellData -> {
            Map<String, Object> student = (Map<String, Object>) cellData.getValue().get("student");
            if (student != null) {
                return new SimpleStringProperty(String.valueOf(student.get("name")));
            }
            return new SimpleStringProperty("");
        });
        
        studentNumColumn.setCellValueFactory(cellData -> {
            Map<String, Object> student = (Map<String, Object>) cellData.getValue().get("student");
            if (student != null) {
                return new SimpleStringProperty(String.valueOf(student.get("num")));
            }
            return new SimpleStringProperty("");
        });
        
        nameColumn.setCellValueFactory(cellData -> 
            new SimpleStringProperty(String.valueOf(cellData.getValue().get("name"))));
        
        innovationTypeColumn.setCellValueFactory(cellData -> {
            String innovationType = String.valueOf(cellData.getValue().get("innovationType"));
            for (OptionItem item : typeComboBox.getItems()) {
                if (item.getValue().equals(innovationType)) {
                    return new SimpleStringProperty(item.getTitle());
                }
            }
            return new SimpleStringProperty(innovationType);
        });
        
        levelColumn.setCellValueFactory(cellData -> {
            String level = String.valueOf(cellData.getValue().get("level"));
            for (OptionItem item : achieveLevelComboBox.getItems()) {
                if (item.getValue().equals(level)) {
                    return new SimpleStringProperty(item.getTitle());
                }
            }
            return new SimpleStringProperty(level);
        });
        
        achieveTimeColumn.setCellValueFactory(cellData -> {
            Object value = cellData.getValue().get("achieveTime");
            if (value != null && !value.toString().isEmpty()) {
                try {
                    LocalDateTime dateTime = LocalDateTime.parse(value.toString(), dateTimeFormatter);
                    return new SimpleStringProperty(dateTime.format(dateFormatter));
                } catch (Exception e) {
                    return new SimpleStringProperty(value.toString());
                }
            }
            return new SimpleStringProperty("");
        });
        
        statusColumn.setCellValueFactory(cellData -> {
            String status = String.valueOf(cellData.getValue().get("status"));
            for (OptionItem item : statusComboBox.getItems()) {
                if (item.getValue().equals(status)) {
                    return new SimpleStringProperty(item.getTitle());
                }
            }
            return new SimpleStringProperty(status);
        });
        
        // 添加行样式类，根据状态设置不同的背景颜色
        dataTableView.setRowFactory(tv -> {
            TableRow<Map<String, Object>> row = new TableRow<>();
            row.itemProperty().addListener((obs, oldItem, newItem) -> {
                if (newItem != null) {
                    String status = String.valueOf(newItem.get("status"));
                    // 清除所有状态样式
                    row.getStyleClass().removeAll("status-approved", "status-pending", "status-rejected");
                    
                    // 根据状态添加对应的样式类
                    if ("2".equals(status)) {
                        row.getStyleClass().add("status-approved");
                    } else if ("1".equals(status)) {
                        row.getStyleClass().add("status-pending");
                    } else if ("3".equals(status)) {
                        row.getStyleClass().add("status-rejected");
                    }
                }
            });
            return row;
        });
        
        // 绑定数据列表到表格
        dataTableView.setItems(dataList);
        
        // 表格选择事件
        dataTableView.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                displayInnovationDetails(newSelection);
            }
        });
        
        // 表格样式
        dataTableView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        
        // 初始化下拉框
        initComboBoxes();
        
        // 加载数据
        loadData();
    }
    
    /**
     * 初始化下拉框
     */
    private void initComboBoxes() {
        // 创新类型下拉框
        List<OptionItem> innovationTypes = HttpRequestUtil.getDictionaryOptionItemList("CXLX");
        
        // 如果从服务器获取的类型为空，添加一些默认值
        if (innovationTypes == null || innovationTypes.isEmpty()) {
            innovationTypes = new ArrayList<>();
            innovationTypes.add(new OptionItem(1, "1", "科研项目"));
            innovationTypes.add(new OptionItem(2, "2", "科技竞赛"));
            innovationTypes.add(new OptionItem(3, "3", "发明专利"));
            innovationTypes.add(new OptionItem(4, "4", "学术论文"));
            innovationTypes.add(new OptionItem(5, "5", "创业项目"));
            innovationTypes.add(new OptionItem(6, "6", "其他"));
        }
        
        typeComboBox.setItems(FXCollections.observableArrayList(innovationTypes));
        
        // 创新成就级别下拉框
        List<OptionItem> innovationLevels = HttpRequestUtil.getDictionaryOptionItemList("CXJB");
        
        // 如果从服务器获取的级别为空，添加一些默认值
        if (innovationLevels == null || innovationLevels.isEmpty()) {
            innovationLevels = new ArrayList<>();
            innovationLevels.add(new OptionItem(1, "1", "国家级"));
            innovationLevels.add(new OptionItem(2, "2", "省级"));
            innovationLevels.add(new OptionItem(3, "3", "市级"));
            innovationLevels.add(new OptionItem(4, "4", "校级"));
            innovationLevels.add(new OptionItem(5, "5", "院级"));
        }
        
        levelComboBox.setItems(FXCollections.observableArrayList(innovationLevels));
        achieveLevelComboBox.setItems(FXCollections.observableArrayList(innovationLevels));
        
        // 审批状态下拉框
        List<OptionItem> approveStatus = HttpRequestUtil.getDictionaryOptionItemList("SPZT");
        
        // 如果从服务器获取的状态为空，添加一些默认值
        if (approveStatus == null || approveStatus.isEmpty()) {
            approveStatus = new ArrayList<>();
            approveStatus.add(new OptionItem(1, "1", "待审批"));
            approveStatus.add(new OptionItem(2, "2", "已批准"));
            approveStatus.add(new OptionItem(3, "3", "已拒绝"));
        }
        
        statusComboBox.setItems(FXCollections.observableArrayList(approveStatus));
        achieveStatusComboBox.setItems(FXCollections.observableArrayList(approveStatus));
        
        // 设置默认值
        if (!innovationTypes.isEmpty()) {
            typeComboBox.setValue(null); // 查询时默认不选择
        }
        
        if (!innovationLevels.isEmpty()) {
            levelComboBox.setValue(null); // 查询时默认不选择
            achieveLevelComboBox.setValue(innovationLevels.get(0)); // 默认国家级
        }
        
        if (!approveStatus.isEmpty()) {
            statusComboBox.setValue(null); // 查询时默认不选择
            achieveStatusComboBox.setValue(approveStatus.get(0)); // 默认待审批
        }
    }
    
    /**
     * 加载创新成就数据
     */
    private void loadData() {
        DataRequest request = new DataRequest();
        
        String keyword = keywordTextField.getText();
        if (keyword != null && !keyword.isEmpty()) {
            request.add("keyword", keyword);
        }
        
        OptionItem selectedType = typeComboBox.getValue();
        if (selectedType != null) {
            request.add("innovationType", selectedType.getValue());
        }
        
        OptionItem selectedLevel = levelComboBox.getValue();
        if (selectedLevel != null) {
            request.add("level", selectedLevel.getValue());
        }
        
        OptionItem selectedStatus = statusComboBox.getValue();
        if (selectedStatus != null) {
            request.add("status", selectedStatus.getValue());
        }
        
        DataResponse response = HttpRequestUtil.request("/api/innovation/list", request);
        if (response != null && response.getData() != null) {
            dataList.clear();
            List<Map<String, Object>> list = (List<Map<String, Object>>) response.getData();
            dataList.addAll(list);
        }
    }
    
    /**
     * 显示创新成就详情
     */
    private void displayInnovationDetails(Map<String, Object> innovation) {
        clearForm();
        
        // 设置当前创新成就ID
        currentInnovationId = safeGetInteger(innovation, "innovationId");
        
        // 设置学生信息
        Map<String, Object> student = (Map<String, Object>) innovation.get("student");
        if (student != null) {
            selectedStudent = student;
            String name = String.valueOf(student.get("name"));
            String num = String.valueOf(student.get("num"));
            studentField.setText(name + " (" + num + ")");
        }
        
        // 设置成就名称
        nameField.setText(String.valueOf(innovation.get("name")));
        
        // 设置创新类型
        String innovationType = String.valueOf(innovation.get("innovationType"));
        for (OptionItem item : typeComboBox.getItems()) {
            if (item.getValue().equals(innovationType)) {
                typeComboBox.setValue(item);
                break;
            }
        }
        
        // 设置级别
        String level = String.valueOf(innovation.get("level"));
        for (OptionItem item : achieveLevelComboBox.getItems()) {
            if (item.getValue().equals(level)) {
                achieveLevelComboBox.setValue(item);
                break;
            }
        }
        
        // 设置获得时间
        String achieveTimeStr = (String) innovation.get("achieveTime");
        if (achieveTimeStr != null && !achieveTimeStr.isEmpty()) {
            try {
                LocalDateTime achieveTime = LocalDateTime.parse(achieveTimeStr, dateTimeFormatter);
                achieveDatePicker.setValue(achieveTime.toLocalDate());
            } catch (DateTimeParseException e) {
                System.err.println("Invalid achieve time format: " + achieveTimeStr);
            }
        }
        
        // 设置其他字段
        organizationField.setText(String.valueOf(innovation.get("organization")));
        certificateNumberField.setText(String.valueOf(innovation.get("certificateNumber")));
        
        // 设置状态
        String status = String.valueOf(innovation.get("status"));
        for (OptionItem item : achieveStatusComboBox.getItems()) {
            if (item.getValue().equals(status)) {
                achieveStatusComboBox.setValue(item);
                break;
            }
        }
        
        descriptionTextArea.setText(String.valueOf(innovation.get("description")));
    }
    
    /**
     * 清空表单
     */
    private void clearForm() {
        currentInnovationId = null;
        selectedStudent = null;
        studentField.clear();
        nameField.clear();
        
        if (!typeComboBox.getItems().isEmpty()) {
            typeComboBox.setValue(null);
        }
        
        if (!achieveLevelComboBox.getItems().isEmpty()) {
            achieveLevelComboBox.setValue(achieveLevelComboBox.getItems().get(0));
        }
        
        achieveDatePicker.setValue(LocalDate.now());
        organizationField.clear();
        certificateNumberField.clear();
        
        if (!achieveStatusComboBox.getItems().isEmpty()) {
            achieveStatusComboBox.setValue(achieveStatusComboBox.getItems().get(0));
        }
        
        descriptionTextArea.clear();
    }
    
    /**
     * 新增按钮事件
     */
    @FXML
    private void onAddButtonClick(ActionEvent event) {
        clearForm();
    }
    
    /**
     * 清空按钮事件
     */
    @FXML
    private void onClearButtonClick(ActionEvent event) {
        clearForm();
    }
    
    /**
     * 删除按钮事件
     */
    @FXML
    private void onDeleteButtonClick(ActionEvent event) {
        if (currentInnovationId == null) {
            MessageDialog.showDialog("请先选择要删除的创新成就记录");
            return;
        }
        
        int choice = MessageDialog.choiceDialog("确定要删除该创新成就记录吗？");
        if (choice != MessageDialog.CHOICE_YES) {
            return;
        }
        
        DataRequest request = new DataRequest();
        request.add("innovationId", currentInnovationId);
        
        DataResponse response = HttpRequestUtil.request("/api/innovation/delete", request);
        if (response != null && response.getCode() == 0) {
            MessageDialog.showDialog("删除成功");
            clearForm();
            loadData();
        } else {
            String errorMsg = response != null ? response.getMsg() : "删除失败，请稍后重试";
            MessageDialog.showDialog(errorMsg);
        }
    }
    
    /**
     * 查询按钮事件
     */
    @FXML
    private void onQueryButtonClick(ActionEvent event) {
        loadData();
    }
    
    /**
     * 保存按钮事件
     */
    @FXML
    private void onSaveButtonClick(ActionEvent event) {
        // 验证表单
        if (selectedStudent == null) {
            MessageDialog.showDialog("请选择学生");
            return;
        }
        
        if (nameField.getText().trim().isEmpty()) {
            MessageDialog.showDialog("请输入创新成就名称");
            return;
        }
        
        if (achieveDatePicker.getValue() == null) {
            MessageDialog.showDialog("请选择获得时间");
            return;
        }
        
        if (descriptionTextArea.getText().trim().isEmpty()) {
            MessageDialog.showDialog("请填写成就描述");
            return;
        }
        
        // 创建请求
        DataRequest request = new DataRequest();
        Map<String, Object> form = new HashMap<>();
        
        // 设置学生ID
        Integer studentId = safeGetInteger(selectedStudent, "personId");
        form.put("studentId", studentId);
        
        // 设置成就名称
        form.put("name", nameField.getText().trim());
        
        // 设置创新类型
        OptionItem selectedType = typeComboBox.getValue();
        if (selectedType != null) {
            form.put("innovationType", selectedType.getValue());
        }
        
        // 设置成就级别
        OptionItem selectedLevel = achieveLevelComboBox.getValue();
        if (selectedLevel != null) {
            form.put("level", selectedLevel.getValue());
        }
        
        // 设置获得时间
        LocalDateTime achieveDateTime = LocalDateTime.of(achieveDatePicker.getValue(), LocalTime.of(0, 0));
        form.put("achieveTime", achieveDateTime.format(dateTimeFormatter));
        
        // 设置其他字段
        form.put("organization", organizationField.getText().trim());
        form.put("certificateNumber", certificateNumberField.getText().trim());
        form.put("description", descriptionTextArea.getText().trim());
        
        // 设置状态
        OptionItem selectedStatus = achieveStatusComboBox.getValue();
        if (selectedStatus != null) {
            form.put("status", selectedStatus.getValue());
        }
        
        request.add("form", form);
        
        // 如果是编辑已有创新成就，设置创新成就ID
        if (currentInnovationId != null) {
            request.add("innovationId", currentInnovationId);
        }
        
        // 发送请求
        DataResponse response = HttpRequestUtil.request("/api/innovation/edit", request);
        if (response != null && response.getCode() == 0) {
            MessageDialog.showDialog("保存成功");
            
            // 如果是新建，设置返回的ID
            if (currentInnovationId == null && response.getData() != null) {
                currentInnovationId = safeGetInteger(response.getData());
            }
            
            // 重新加载数据
            loadData();
        } else {
            String errorMsg = response != null ? response.getMsg() : "保存失败，请稍后重试";
            MessageDialog.showDialog(errorMsg);
        }
    }
    
    /**
     * 审批按钮事件
     */
    @FXML
    private void onApproveButtonClick(ActionEvent event) {
        if (currentInnovationId == null) {
            MessageDialog.showDialog("请先选择要审批的创新成就记录");
            return;
        }
        
        // 创建审批对话框
        Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.setTitle("创新成就审批");
        
        VBox dialogVBox = new VBox(10);
        dialogVBox.setPadding(new Insets(20));
        
        // 状态选择
        HBox statusBox = new HBox(10);
        statusBox.setAlignment(Pos.CENTER_LEFT);
        Label statusLabel = new Label("审批结果：");
        ComboBox<OptionItem> statusSelector = new ComboBox<>();
        
        // 过滤出审批相关的状态（已批准/已拒绝）
        List<OptionItem> approvalStatus = new ArrayList<>();
        for (OptionItem item : achieveStatusComboBox.getItems()) {
            if ("2".equals(item.getValue()) || "3".equals(item.getValue())) {
                approvalStatus.add(item);
            }
        }
        
        statusSelector.setItems(FXCollections.observableArrayList(approvalStatus));
        if (!approvalStatus.isEmpty()) {
            statusSelector.setValue(approvalStatus.get(0));
        }
        
        statusBox.getChildren().addAll(statusLabel, statusSelector);
        
        // 审批人
        HBox approverBox = new HBox(10);
        approverBox.setAlignment(Pos.CENTER_LEFT);
        Label approverLabel = new Label("审批人：");
        TextField approverInput = new TextField();
        approverBox.getChildren().addAll(approverLabel, approverInput);
        
        // 审批意见
        Label commentLabel = new Label("审批意见：");
        TextArea commentArea = new TextArea();
        commentArea.setPrefHeight(100);
        
        // 按钮
        HBox buttonBox = new HBox(20);
        buttonBox.setAlignment(Pos.CENTER);
        Button confirmButton = new Button("确认");
        Button cancelButton = new Button("取消");
        buttonBox.getChildren().addAll(confirmButton, cancelButton);
        
        dialogVBox.getChildren().addAll(statusBox, approverBox, commentLabel, commentArea, buttonBox);
        
        // 设置事件
        cancelButton.setOnAction(e -> dialog.close());
        
        confirmButton.setOnAction(e -> {
            if (approverInput.getText().trim().isEmpty()) {
                MessageDialog.showDialog("请填写审批人");
                return;
            }
            
            // 发送审批请求
            DataRequest request = new DataRequest();
            request.add("innovationId", currentInnovationId);
            request.add("status", statusSelector.getValue().getValue());
            request.add("approver", approverInput.getText());
            request.add("approveComment", commentArea.getText());
            
            DataResponse response = HttpRequestUtil.request("/api/innovation/approve", request);
            if (response != null && response.getCode() == 0) {
                MessageDialog.showDialog("审批成功");
                dialog.close();
                loadData();
            } else {
                String errorMsg = response != null ? response.getMsg() : "审批失败，请稍后重试";
                MessageDialog.showDialog(errorMsg);
            }
        });
        
        Scene dialogScene = new Scene(dialogVBox, 400, 300);
        dialog.setScene(dialogScene);
        dialog.showAndWait();
    }
    
    /**
     * 选择学生按钮事件
     */
    @FXML
    private void onSelectStudentButtonClick(ActionEvent event) {
        // 获取学生列表
        DataRequest request = new DataRequest();
        DataResponse response = HttpRequestUtil.request("/api/student/list", request);
        
        if (response != null && response.getData() != null) {
            List<Map<String, Object>> students = (List<Map<String, Object>>) response.getData();
            showStudentSelectionDialog(students);
        } else {
            MessageDialog.showDialog("获取学生列表失败，请稍后重试");
        }
    }
    
    /**
     * 显示学生选择对话框
     */
    private void showStudentSelectionDialog(List<Map<String, Object>> students) {
        Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.setTitle("选择学生");
        
        VBox dialogVBox = new VBox(10);
        dialogVBox.setPadding(new Insets(20));
        
        // 搜索框
        HBox searchBox = new HBox(10);
        TextField searchField = new TextField();
        searchField.setPromptText("输入学号或姓名搜索");
        searchField.setPrefWidth(200);
        Button searchButton = new Button("搜索");
        searchBox.getChildren().addAll(searchField, searchButton);
        
        // 学生列表
        TableView<Map<String, Object>> studentTable = new TableView<>();
        studentTable.setPrefHeight(300);
        
        TableColumn<Map<String, Object>, String> numColumn = new TableColumn<>("学号");
        numColumn.setCellValueFactory(data -> new SimpleStringProperty(String.valueOf(data.getValue().get("num"))));
        numColumn.setPrefWidth(120);
        
        TableColumn<Map<String, Object>, String> nameColumn = new TableColumn<>("姓名");
        nameColumn.setCellValueFactory(data -> new SimpleStringProperty(String.valueOf(data.getValue().get("name"))));
        nameColumn.setPrefWidth(100);
        
        TableColumn<Map<String, Object>, String> classColumn = new TableColumn<>("班级");
        classColumn.setCellValueFactory(data -> new SimpleStringProperty(String.valueOf(data.getValue().get("className"))));
        classColumn.setPrefWidth(120);
        
        studentTable.getColumns().addAll(numColumn, nameColumn, classColumn);
        
        // 确认按钮
        HBox buttonBox = new HBox(20);
        buttonBox.setAlignment(Pos.CENTER);
        Button selectButton = new Button("选择");
        Button cancelButton = new Button("取消");
        buttonBox.getChildren().addAll(selectButton, cancelButton);
        
        dialogVBox.getChildren().addAll(searchBox, studentTable, buttonBox);
        
        // 加载学生数据
        ObservableList<Map<String, Object>> studentData = FXCollections.observableArrayList(students);
        studentTable.setItems(studentData);
        
        // 搜索功能
        searchButton.setOnAction(e -> {
            String keyword = searchField.getText().toLowerCase();
            if (keyword.isEmpty()) {
                studentTable.setItems(studentData);
            } else {
                ObservableList<Map<String, Object>> filteredData = FXCollections.observableArrayList();
                for (Map<String, Object> student : students) {
                    String num = String.valueOf(student.get("num")).toLowerCase();
                    String name = String.valueOf(student.get("name")).toLowerCase();
                    if (num.contains(keyword) || name.contains(keyword)) {
                        filteredData.add(student);
                    }
                }
                studentTable.setItems(filteredData);
            }
        });
        
        // 设置按钮事件
        cancelButton.setOnAction(e -> dialog.close());
        
        selectButton.setOnAction(e -> {
            Map<String, Object> selectedItem = studentTable.getSelectionModel().getSelectedItem();
            if (selectedItem != null) {
                selectedStudent = selectedItem;
                String name = String.valueOf(selectedItem.get("name"));
                String num = String.valueOf(selectedItem.get("num"));
                studentField.setText(name + " (" + num + ")");
                dialog.close();
            } else {
                MessageDialog.showDialog("请先选择一名学生");
            }
        });
        
        Scene dialogScene = new Scene(dialogVBox, 400, 450);
        dialog.setScene(dialogScene);
        dialog.showAndWait();
    }
    
    /**
     * 安全获取Map中的Integer值
     */
    private Integer safeGetInteger(Map<String, Object> map, String key) {
        Object value = map.get(key);
        return safeGetInteger(value);
    }
    
    /**
     * 安全转换Object为Integer
     */
    private Integer safeGetInteger(Object value) {
        if (value == null) {
            return null;
        }
        
        if (value instanceof Integer) {
            return (Integer) value;
        }
        
        try {
            return Integer.parseInt(value.toString());
        } catch (NumberFormatException e) {
            return null;
        }
    }
} 