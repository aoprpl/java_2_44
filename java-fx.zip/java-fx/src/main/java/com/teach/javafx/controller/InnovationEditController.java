package com.teach.javafx.controller;

import com.teach.javafx.controller.base.MessageDialog;
import com.teach.javafx.request.DataRequest;
import com.teach.javafx.request.DataResponse;
import com.teach.javafx.request.HttpRequestUtil;
import com.teach.javafx.request.OptionItem;
import com.teach.javafx.util.CommonMethod;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class InnovationEditController {
    @FXML
    private ComboBox<OptionItem> studentComboBox;
    @FXML
    private TextField nameField;
    @FXML
    private ComboBox<OptionItem> innovationTypeComboBox;
    @FXML
    private ComboBox<OptionItem> levelComboBox;
    @FXML
    private DatePicker achieveDatePicker;
    @FXML
    private TextField organizationField;
    @FXML
    private TextField certificateNumberField;
    @FXML
    private TextArea descriptionArea;
    @FXML
    private ComboBox<OptionItem> statusComboBox;
    @FXML
    private TextField teacherField;

    private InnovationController innovationController;
    private Integer innovationId;
    private List<OptionItem> studentList;
    private List<OptionItem> innovationTypeList;
    private List<OptionItem> levelList;
    private List<OptionItem> statusList;
    private final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    @FXML
    public void initialize() {
        initComboBoxes();
    }

    private void initComboBoxes() {
        // 获取学生列表
        DataRequest req = new DataRequest();
        List<OptionItem> studentItems = HttpRequestUtil.requestOptionItemList("/api/innovation/getStudentItemOptionList", req);
        if (studentItems != null) {
            studentList = studentItems;
            // 添加"请选择"选项
            OptionItem defaultItem = new OptionItem(null, "0", "请选择");
            studentComboBox.getItems().add(defaultItem);
            studentComboBox.getItems().addAll(studentList);
            studentComboBox.setValue(defaultItem);
        }

        // 初始化创新类型
        innovationTypeList = new ArrayList<>();
        innovationTypeList.add(new OptionItem(1, "1", "科研项目"));
        innovationTypeList.add(new OptionItem(2, "2", "科技竞赛"));
        innovationTypeList.add(new OptionItem(3, "3", "发明专利"));
        innovationTypeList.add(new OptionItem(4, "4", "学术论文"));
        innovationTypeList.add(new OptionItem(5, "5", "创业项目"));
        innovationTypeList.add(new OptionItem(6, "6", "其他"));
        innovationTypeComboBox.getItems().addAll(innovationTypeList);

        // 初始化成就级别
        levelList = new ArrayList<>();
        levelList.add(new OptionItem(1, "1", "国家级"));
        levelList.add(new OptionItem(2, "2", "省级"));
        levelList.add(new OptionItem(3, "3", "市级"));
        levelList.add(new OptionItem(4, "4", "校级"));
        levelList.add(new OptionItem(5, "5", "院级"));
        levelComboBox.getItems().addAll(levelList);

        // 初始化审批状态
        statusList = new ArrayList<>();
        statusList.add(new OptionItem(1, "1", "待审批"));
        statusList.add(new OptionItem(2, "2", "已批准"));
        statusList.add(new OptionItem(3, "3", "已拒绝"));
        statusComboBox.getItems().addAll(statusList);

        // 设置默认值
        if (!innovationTypeList.isEmpty()) {
            innovationTypeComboBox.setValue(innovationTypeList.get(0));
        }
        if (!levelList.isEmpty()) {
            levelComboBox.setValue(levelList.get(0));
        }
        if (!statusList.isEmpty()) {
            statusComboBox.setValue(statusList.get(0));
        }
        achieveDatePicker.setValue(LocalDate.now());
    }

    public void setInnovationController(InnovationController innovationController) {
        this.innovationController = innovationController;
    }

    public void showDialog(Map<String, Object> data) {
        if (data == null) {
            // 新增模式
            innovationId = null;
            clearForm();
        } else {
            // 编辑模式
            innovationId = CommonMethod.getInteger(data, "innovationId");
            nameField.setText(CommonMethod.getString(data, "name"));
            
            // 设置学生
            Map<String, Object> student = (Map<String, Object>) data.get("student");
            if (student != null) {
                String personId = String.valueOf(student.get("personId"));
                for (OptionItem item : studentList) {
                    if (personId.equals(item.getValue())) {
                        studentComboBox.setValue(item);
                        break;
                    }
                }
                studentComboBox.setDisable(true); // 编辑模式下不允许更改学生
            }

            // 设置创新类型
            String innovationType = CommonMethod.getString(data, "innovationType");
            for (OptionItem item : innovationTypeList) {
                if (item.getValue().equals(innovationType)) {
                    innovationTypeComboBox.setValue(item);
                    break;
                }
            }

            // 设置级别
            String level = CommonMethod.getString(data, "level");
            for (OptionItem item : levelList) {
                if (item.getValue().equals(level)) {
                    levelComboBox.setValue(item);
                    break;
                }
            }

            // 设置获得时间
            String achieveTimeStr = CommonMethod.getString(data, "achieveTime");
            if (achieveTimeStr != null && !achieveTimeStr.isEmpty()) {
                try {
                    LocalDateTime achieveTime = LocalDateTime.parse(achieveTimeStr, dateTimeFormatter);
                    achieveDatePicker.setValue(achieveTime.toLocalDate());
                } catch (Exception e) {
                    System.err.println("Invalid achieve time format: " + achieveTimeStr);
                }
            }

            // 设置其他字段
            organizationField.setText(CommonMethod.getString(data, "organization"));
            teacherField.setText(CommonMethod.getString(data, "teacher"));
            certificateNumberField.setText(CommonMethod.getString(data, "certificateNumber"));
            descriptionArea.setText(CommonMethod.getString(data, "description"));

            // 设置状态
            String status = CommonMethod.getString(data, "status");
            for (OptionItem item : statusList) {
                if (item.getValue().equals(status)) {
                    statusComboBox.setValue(item);
                    break;
                }
            }
        }
    }

    private void clearForm() {
        nameField.clear();
        studentComboBox.setValue(null);
        studentComboBox.setDisable(false);
        innovationTypeComboBox.setValue(innovationTypeList.get(0));
        levelComboBox.setValue(levelList.get(0));
        achieveDatePicker.setValue(LocalDate.now());
        organizationField.clear();
        teacherField.clear();
        certificateNumberField.clear();
        descriptionArea.clear();
        statusComboBox.setValue(statusList.get(0));
    }

    @FXML
    private void onSaveButtonClick() {
        // 验证表单
        if (studentComboBox.getValue() == null) {
            MessageDialog.showDialog("请选择学生");
            return;
        }

        if (nameField.getText().trim().isEmpty()) {
            MessageDialog.showDialog("请输入创新成就名称");
            return;
        }

        if (achieveDatePicker.getValue() == null) {
            MessageDialog.showDialog("请选择获得时间");
            return;
        }

        if (descriptionArea.getText().trim().isEmpty()) {
            MessageDialog.showDialog("请填写成就描述");
            return;
        }

        // 创建请求
        DataRequest request = new DataRequest();
        Map<String, Object> form = new HashMap<>();

        // 设置学生ID
        form.put("studentId", studentComboBox.getValue().getValue());

        // 设置成就名称
        form.put("name", nameField.getText().trim());

        // 设置创新类型
        form.put("innovationType", innovationTypeComboBox.getValue().getValue());

        // 设置成就级别
        form.put("level", levelComboBox.getValue().getValue());

        // 设置获得时间
        LocalDateTime achieveDateTime = LocalDateTime.of(achieveDatePicker.getValue(), LocalTime.of(0, 0));
        form.put("achieveTime", achieveDateTime.format(dateTimeFormatter));

        // 设置其他字段
        form.put("organization", organizationField.getText().trim());
        form.put("teacher", teacherField.getText().trim());
        form.put("certificateNumber", certificateNumberField.getText().trim());
        form.put("description", descriptionArea.getText().trim());
        form.put("status", statusComboBox.getValue().getValue());

        request.add("form", form);

        // 如果是编辑已有创新成就，设置创新成就ID
        if (innovationId != null) {
            request.add("innovationId", innovationId);
        }

        // 发送请求
        DataResponse response = HttpRequestUtil.request("/api/innovation/edit", request);
        if (response != null && response.getCode() == 0) {
            MessageDialog.showDialog("保存成功");
            if (innovationController != null) {
                innovationController.loadData();
            }
            closeDialog();
        } else {
            String errorMsg = response != null ? response.getMsg() : "保存失败，请稍后重试";
            MessageDialog.showDialog(errorMsg);
        }
    }

    @FXML
    private void onCancelButtonClick() {
        closeDialog();
    }

    private void closeDialog() {
        if (studentComboBox.getScene() != null) {
            studentComboBox.getScene().getWindow().hide();
        }
    }
} 