package com.teach.javafx.controller;

import com.teach.javafx.request.DataRequest;
import com.teach.javafx.request.DataResponse;
import com.teach.javafx.util.CommonMethod;
import com.teach.javafx.request.OptionItem;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.MapValueFactory;
import javafx.scene.layout.HBox;
import javafx.util.Callback;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TeacherController {
    @FXML
    private TableView<Map> dataTableView;
    @FXML
    private TableColumn<Map, String> numColumn;
    @FXML
    private TableColumn<Map, String> nameColumn;
    @FXML
    private TableColumn<Map, String> deptColumn;
    @FXML
    private TableColumn<Map, String> titleColumn;
    @FXML
    private TableColumn<Map, String> degreeColumn;
    @FXML
    private TableColumn<Map, String> cardColumn;
    @FXML
    private TableColumn<Map, String> genderColumn;
    @FXML
    private TableColumn<Map, String> birthdayColumn;
    @FXML
    private TableColumn<Map, String> emailColumn;
    @FXML
    private TableColumn<Map, String> phoneColumn;
    @FXML
    private TableColumn<Map, String> addressColumn;

    @FXML
    private TextField numField;
    @FXML
    private TextField nameField;
    @FXML
    private TextField deptField;
    @FXML
    private TextField titleField;
    @FXML
    private TextField degreeField;
    @FXML
    private TextField cardField;
    @FXML
    private ComboBox<OptionItem> genderComboBox;
    @FXML
    private DatePicker birthdayPick;
    @FXML
    private TextField emailField;
    @FXML
    private TextField phoneField;
    @FXML
    private TextField addressField;
    @FXML
    private TextField numNameTextField;

    private Integer teacherId = null;
    private ArrayList<Map> teacherList = new ArrayList<>();
    private List<OptionItem> genderList;
    private ObservableList<Map> observableList = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        numColumn.setCellValueFactory(new MapValueFactory<>("num"));
        nameColumn.setCellValueFactory(new MapValueFactory<>("name"));
        deptColumn.setCellValueFactory(new MapValueFactory<>("dept"));
        titleColumn.setCellValueFactory(new MapValueFactory<>("title"));
        degreeColumn.setCellValueFactory(new MapValueFactory<>("degree"));
        cardColumn.setCellValueFactory(new MapValueFactory<>("card"));
        genderColumn.setCellValueFactory(new MapValueFactory<>("genderName"));
        birthdayColumn.setCellValueFactory(new MapValueFactory<>("birthday"));
        emailColumn.setCellValueFactory(new MapValueFactory<>("email"));
        phoneColumn.setCellValueFactory(new MapValueFactory<>("phone"));
        addressColumn.setCellValueFactory(new MapValueFactory<>("address"));
        dataTableView.setItems(observableList);
        genderList = CommonMethod.getDictionaryOptionItemList("XBM");
        genderComboBox.getItems().addAll(genderList);
        onQueryButtonClick();
    }

    @FXML
    protected void onQueryButtonClick() {
        String numName = numNameTextField.getText();
        DataRequest req = new DataRequest();
        req.add("numName", numName);
        DataResponse res = CommonMethod.request("/api/teacher/list", req);
        if (res != null && res.getCode() == 0) {
            teacherList = (ArrayList<Map>) res.getData();
            setTableViewData();
        }
    }

    private void setTableViewData() {
        observableList.clear();
        observableList.addAll(teacherList);
    }

    @FXML
    protected void onAddButtonClick() {
        clearPanel();
    }

    @FXML
    protected void onDeleteButtonClick() {
        if (teacherId == null) {
            CommonMethod.showDialog("请选择要删除的教师");
            return;
        }
        DataRequest req = new DataRequest();
        req.add("teacherId", teacherId);
        DataResponse res = CommonMethod.request("/api/teacher/delete", req);
        if (res.getCode() == 0) {
            CommonMethod.showDialog("删除成功！");
            onQueryButtonClick();
        } else {
            CommonMethod.showDialog(res.getMsg());
        }
    }

    @FXML
    protected void onSaveButtonClick() {
        if (numField.getText().isEmpty()) {
            CommonMethod.showDialog("工号为空，不能保存");
            return;
        }
        Map<String, Object> form = new HashMap<>();
        form.put("num", numField.getText());
        form.put("name", nameField.getText());
        form.put("dept", deptField.getText());
        form.put("title", titleField.getText());
        form.put("degree", degreeField.getText());
        form.put("card", cardField.getText());
        if (genderComboBox.getSelectionModel() != null && genderComboBox.getSelectionModel().getSelectedItem() != null)
            form.put("gender", genderComboBox.getSelectionModel().getSelectedItem().getValue());
        form.put("birthday", birthdayPick.getEditor().getText());
        form.put("email", emailField.getText());
        form.put("phone", phoneField.getText());
        form.put("address", addressField.getText());
        DataRequest req = new DataRequest();
        req.add("teacherId", teacherId);
        req.add("form", form);
        DataResponse res = CommonMethod.request("/api/teacher/edit", req);
        if (res.getCode() == 0) {
            teacherId = CommonMethod.getIntegerFromObject(res.getData());
            CommonMethod.showDialog("提交成功！");
            onQueryButtonClick();
        } else {
            CommonMethod.showDialog(res.getMsg());
        }
    }

    private void clearPanel() {
        teacherId = null;
        numField.clear();
        nameField.clear();
        deptField.clear();
        titleField.clear();
        degreeField.clear();
        cardField.clear();
        genderComboBox.getSelectionModel().clearSelection();
        birthdayPick.getEditor().clear();
        emailField.clear();
        phoneField.clear();
        addressField.clear();
    }
}
