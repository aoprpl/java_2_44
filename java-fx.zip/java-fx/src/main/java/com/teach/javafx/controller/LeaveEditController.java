package com.teach.javafx.controller;

import com.teach.javafx.controller.base.MessageDialog;
import com.teach.javafx.request.DataRequest;
import com.teach.javafx.request.DataResponse;
import com.teach.javafx.request.HttpRequestUtil;
import com.teach.javafx.request.OptionItem;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 请假编辑对话框控制器
 */
public class LeaveEditController {
    @FXML
    private TextField studentField;
    
    @FXML
    private ComboBox<OptionItem> typeComboBox;
    
    @FXML
    private DatePicker startDatePicker;
    
    @FXML
    private DatePicker endDatePicker;
    
    @FXML
    private TextField destinationField;
    
    @FXML
    private TextField contactField;
    
    @FXML
    private TextArea reasonTextArea;
    
    @FXML
    private ComboBox<OptionItem> studentComboBox;
    
    private List<OptionItem> studentList;
    
    // 当前选中的学生
    private Map<String, Object> selectedStudent = null;
    
    // 日期时间格式化器
    private final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    
    /**
     * 初始化方法
     */
    @FXML
    private void initialize() {
        // 初始化学生下拉框（完全参照荣誉管理）
        DataRequest req = new DataRequest();
        // 优先用/api/leave/getStudentItemOptionList，如无可用/api/honor/getStudentItemOptionList或/api/student/getStudentItemOptionList
        List<OptionItem> studentItems = HttpRequestUtil.requestOptionItemList("/api/leave/getStudentItemOptionList", req);
        if (studentItems == null) {
            studentItems = HttpRequestUtil.requestOptionItemList("/api/honor/getStudentItemOptionList", req);
        }
        if (studentItems == null) {
            studentItems = HttpRequestUtil.requestOptionItemList("/api/student/getStudentItemOptionList", req);
        }
        if (studentItems != null) {
            studentList = studentItems;
            OptionItem defaultItem = new OptionItem(null, "0", "请选择");
            studentComboBox.getItems().add(defaultItem);
            studentComboBox.getItems().addAll(studentList);
            studentComboBox.setValue(defaultItem);
        }
        
        // 初始化请假类型下拉框
        List<OptionItem> leaveTypes = HttpRequestUtil.getDictionaryOptionItemList("QJLX");
        
        // 如果从服务器获取的类型为空，添加一些默认值
        if (leaveTypes == null || leaveTypes.isEmpty()) {
            leaveTypes = new ArrayList<>();
            leaveTypes.add(new OptionItem(1, "1", "事假"));
            leaveTypes.add(new OptionItem(2, "2", "病假"));
            leaveTypes.add(new OptionItem(3, "3", "外出"));
            leaveTypes.add(new OptionItem(4, "4", "实习"));
            leaveTypes.add(new OptionItem(5, "5", "其他"));
        }
        
        typeComboBox.setItems(FXCollections.observableArrayList(leaveTypes));
        
        // 设置默认值
        if (!leaveTypes.isEmpty()) {
            typeComboBox.setValue(leaveTypes.get(0));
        }
        
        // 设置日期选择器的默认值为今天
        startDatePicker.setValue(LocalDate.now());
        endDatePicker.setValue(LocalDate.now());
    }
    
    /**
     * 保存按钮事件
     */
    @FXML
    private void onSaveButtonClick(ActionEvent event) {
        // 验证表单
        OptionItem selectedStudentItem = studentComboBox.getValue();
        if (selectedStudentItem == null || "0".equals(selectedStudentItem.getValue())) {
            MessageDialog.showDialog("请选择学生");
            return;
        }
        
        if (startDatePicker.getValue() == null) {
            MessageDialog.showDialog("请选择开始时间");
            return;
        }
        
        if (endDatePicker.getValue() == null) {
            MessageDialog.showDialog("请选择结束时间");
            return;
        }
        
        if (endDatePicker.getValue().isBefore(startDatePicker.getValue())) {
            MessageDialog.showDialog("结束时间不能早于开始时间");
            return;
        }
        
        if (reasonTextArea.getText().trim().isEmpty()) {
            MessageDialog.showDialog("请填写请假原因");
            return;
        }
        
        // 创建请求
        DataRequest request = new DataRequest();
        Map<String, Object> form = new HashMap<>();
        
        // 设置学生ID
        Integer studentId = null;
        try {
            studentId = Integer.parseInt(selectedStudentItem.getValue());
        } catch (Exception e) {
            studentId = null;
        }
        form.put("studentId", studentId);
        
        // 设置请假类型
        OptionItem selectedType = typeComboBox.getValue();
        if (selectedType != null) {
            form.put("leaveType", selectedType.getValue());
        }
        
        // 设置开始和结束时间
        LocalDateTime startDateTime = LocalDateTime.of(startDatePicker.getValue(), LocalTime.of(8, 0));
        form.put("startTime", startDateTime.format(dateTimeFormatter));
        
        LocalDateTime endDateTime = LocalDateTime.of(endDatePicker.getValue(), LocalTime.of(18, 0));
        form.put("endTime", endDateTime.format(dateTimeFormatter));
        
        // 设置其他字段
        form.put("destination", destinationField.getText().trim());
        form.put("contact", contactField.getText().trim());
        form.put("reason", reasonTextArea.getText().trim());
        
        // 新请假默认为待审批状态
        form.put("status", "1");
        
        request.add("form", form);
        
        // 发送请求
        DataResponse response = HttpRequestUtil.request("/api/leave/edit", request);
        if (response != null && response.getCode() == 0) {
            MessageDialog.showDialog("保存成功");
            closeDialog();
        } else {
            String errorMsg = response != null ? response.getMsg() : "保存失败，请稍后重试";
            MessageDialog.showDialog(errorMsg);
        }
    }
    
    /**
     * 取消按钮事件
     */
    @FXML
    private void onCancelButtonClick(ActionEvent event) {
        closeDialog();
    }
    
    /**
     * 关闭对话框
     */
    private void closeDialog() {
        Stage stage = (Stage) studentComboBox.getScene().getWindow();
        stage.close();
    }
    
    /**
     * 安全地获取整数值
     */
    private Integer safeGetInteger(Map<String, Object> map, String key) {
        if (map == null || key == null) {
            return null;
        }
        
        Object value = map.get(key);
        if (value == null) {
            return null;
        }
        
        if (value instanceof Integer) {
            return (Integer) value;
        }
        
        try {
            return Integer.parseInt(value.toString());
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
