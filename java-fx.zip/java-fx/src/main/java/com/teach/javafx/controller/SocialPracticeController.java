package com.teach.javafx.controller;

import com.teach.javafx.controller.base.StudentSelectDialog;
import com.teach.javafx.controller.base.MessageDialog;
import com.teach.javafx.request.OptionItem;
import com.teach.javafx.request.DataRequest;
import com.teach.javafx.request.DataResponse;
import com.teach.javafx.request.HttpRequestUtil;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.MapValueFactory;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 社会实践管理控制器
 */
public class SocialPracticeController {
    @FXML
    private TextField keywordTextField;
    
    @FXML
    private ComboBox<OptionItem> statusComboBox;
    
    @FXML
    private TableView<Map<String, Object>> dataTableView;
    
    @FXML
    private TableColumn<Map<String, Object>, String> practiceNameColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> practiceContentColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> startTimeColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> endTimeColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> locationColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> hoursColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> statusColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> studentNameColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> studentNumColumn;
    
    @FXML
    private TextField practiceNameField;
    
    @FXML
    private TextArea practiceContentArea;
    
    @FXML
    private DatePicker startDatePicker;
    
    @FXML
    private DatePicker endDatePicker;
    
    @FXML
    private TextField locationField;
    
    @FXML
    private TextField hoursField;
    
    @FXML
    private TextField studentField;
    
    private ObservableList<Map<String, Object>> dataList = FXCollections.observableArrayList();
    private Map<String, Object> selectedStudent = null;
    private Integer currentPracticeId = null;
    private final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    
    @FXML
    public void initialize() {
        initTableColumns();
        initStatusComboBox();
        initTableSelection();
        loadData();
    }
    
    private void initTableColumns() {
        practiceNameColumn.setCellValueFactory(cellData -> new SimpleStringProperty(String.valueOf(cellData.getValue().get("practiceName"))));
        practiceContentColumn.setCellValueFactory(cellData -> new SimpleStringProperty(String.valueOf(cellData.getValue().get("practiceContent"))));
        startTimeColumn.setCellValueFactory(cellData -> new SimpleStringProperty(formatDateTime(cellData.getValue().get("startTime"))));
        endTimeColumn.setCellValueFactory(cellData -> new SimpleStringProperty(formatDateTime(cellData.getValue().get("endTime"))));
        locationColumn.setCellValueFactory(cellData -> new SimpleStringProperty(String.valueOf(cellData.getValue().get("practiceLocation"))));
        hoursColumn.setCellValueFactory(cellData -> new SimpleStringProperty(String.valueOf(cellData.getValue().get("practiceHours"))));
        statusColumn.setCellValueFactory(cellData -> new SimpleStringProperty(String.valueOf(cellData.getValue().get("status"))));
        
        studentNameColumn.setCellValueFactory(cellData -> {
            Map<String, Object> student = (Map<String, Object>) cellData.getValue().get("student");
            return new SimpleStringProperty(student != null ? String.valueOf(student.get("name")) : "");
        });
        
        studentNumColumn.setCellValueFactory(cellData -> {
            Map<String, Object> student = (Map<String, Object>) cellData.getValue().get("student");
            return new SimpleStringProperty(student != null ? String.valueOf(student.get("num")) : "");
        });
        
        dataTableView.setItems(dataList);
    }
    
    private void initStatusComboBox() {
        List<OptionItem> statusList = new ArrayList<>();
        statusList.add(new OptionItem(1, "1", "待审核"));
        statusList.add(new OptionItem(2, "2", "已通过"));
        statusList.add(new OptionItem(3, "3", "未通过"));
        statusComboBox.setItems(FXCollections.observableArrayList(statusList));
    }
    
    private void initTableSelection() {
        dataTableView.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                displayPracticeDetails(newSelection);
            }
        });
    }
    
    private String formatDateTime(Object dateTime) {
        if (dateTime == null || dateTime.toString().isEmpty()) {
            return "";
        }
        try {
            LocalDateTime dt = LocalDateTime.parse(dateTime.toString());
            return dt.format(dateTimeFormatter);
        } catch (Exception e) {
            return dateTime.toString();
        }
    }
    
    private void loadData() {
        DataRequest request = new DataRequest();
        
        String keyword = keywordTextField.getText();
        if (keyword != null && !keyword.isEmpty()) {
            request.add("keyword", keyword);
        }
        
        OptionItem selectedStatus = statusComboBox.getValue();
        if (selectedStatus != null) {
            request.add("status", selectedStatus.getValue());
        }
        
        DataResponse response = HttpRequestUtil.request("/api/social-practice/list", request);
        if (response != null && response.getData() != null) {
            dataList.clear();
            List<Map<String, Object>> list = (List<Map<String, Object>>) response.getData();
            dataList.addAll(list);
        }
    }
    
    private void displayPracticeDetails(Map<String, Object> practice) {
        currentPracticeId = safeGetInteger(practice, "practiceId");
        
        practiceNameField.setText(String.valueOf(practice.get("practiceName")));
        practiceContentArea.setText(String.valueOf(practice.get("practiceContent")));
        
        Object startTimeObj = practice.get("startTime");
        if (startTimeObj != null && !startTimeObj.toString().isEmpty()) {
            try {
                LocalDateTime startTime = LocalDateTime.parse(startTimeObj.toString());
                startDatePicker.setValue(startTime.toLocalDate());
            } catch (Exception e) {
                startDatePicker.setValue(null);
            }
        } else {
            startDatePicker.setValue(null);
        }
        
        Object endTimeObj = practice.get("endTime");
        if (endTimeObj != null && !endTimeObj.toString().isEmpty()) {
            try {
                LocalDateTime endTime = LocalDateTime.parse(endTimeObj.toString());
                endDatePicker.setValue(endTime.toLocalDate());
            } catch (Exception e) {
                endDatePicker.setValue(null);
            }
        } else {
            endDatePicker.setValue(null);
        }
        
        locationField.setText(String.valueOf(practice.get("practiceLocation")));
        hoursField.setText(String.valueOf(practice.get("practiceHours")));
        
        Map<String, Object> student = (Map<String, Object>) practice.get("student");
        if (student != null) {
            selectedStudent = student;
            studentField.setText(student.get("name") + " (" + student.get("num") + ")");
        } else {
            selectedStudent = null;
            studentField.setText("");
        }
    }
    
    private void clearForm() {
        currentPracticeId = null;
        practiceNameField.clear();
        practiceContentArea.clear();
        startDatePicker.setValue(null);
        endDatePicker.setValue(null);
        locationField.clear();
        hoursField.clear();
        studentField.clear();
        selectedStudent = null;
    }
    
    private Integer safeGetInteger(Map<String, Object> map, String key) {
        Object value = map.get(key);
        if (value == null) {
            return null;
        }
        try {
            if (value instanceof Integer) {
                return (Integer) value;
            }
            return Integer.parseInt(value.toString());
        } catch (NumberFormatException e) {
            return null;
        }
    }
    
    @FXML
    private void onAddButtonClick(ActionEvent event) {
        clearForm();
    }
    
    @FXML
    private void onDeleteButtonClick(ActionEvent event) {
        Map<String, Object> selectedPractice = dataTableView.getSelectionModel().getSelectedItem();
        if (selectedPractice == null) {
            MessageDialog.showDialog("请先选择一条实践记录");
            return;
        }
        
        Integer practiceId = safeGetInteger(selectedPractice, "practiceId");
        if (practiceId == null) {
            MessageDialog.showDialog("实践ID无效");
            return;
        }
        
        if (MessageDialog.choiceDialog("确定要删除该实践记录吗？") == MessageDialog.CHOICE_YES) {
            DataRequest request = new DataRequest();
            request.add("practiceId", practiceId);
            
            DataResponse response = HttpRequestUtil.request("/api/social-practice/delete", request);
            if (response != null && response.getCode() == 0) {
                MessageDialog.showDialog("删除成功");
                loadData();
                clearForm();
            } else {
                MessageDialog.showDialog("删除失败: " + (response != null ? response.getMsg() : "未知错误"));
            }
        }
    }
    
    @FXML
    private void onQueryButtonClick(ActionEvent event) {
        loadData();
    }
    
    @FXML
    private void onSaveButtonClick(ActionEvent event) {
        try {
            // 验证输入
            if (practiceNameField.getText().isEmpty()) {
                MessageDialog.showDialog("实践名称不能为空");
                return;
            }
            
            if (startDatePicker.getValue() == null) {
                MessageDialog.showDialog("请选择开始时间");
                return;
            }
            
            if (endDatePicker.getValue() == null) {
                MessageDialog.showDialog("请选择结束时间");
                return;
            }
            
            if (selectedStudent == null) {
                MessageDialog.showDialog("请选择参与学生");
                return;
            }
            
            // 构建表单数据
            Map<String, Object> form = new HashMap<>();
            form.put("practiceName", practiceNameField.getText());
            form.put("practiceContent", practiceContentArea.getText());
            form.put("startTime", startDatePicker.getValue().atStartOfDay().format(dateTimeFormatter));
            form.put("endTime", endDatePicker.getValue().atStartOfDay().format(dateTimeFormatter));
            form.put("practiceLocation", locationField.getText());
            form.put("practiceHours", Integer.parseInt(hoursField.getText()));
            form.put("status", "待审核");
            form.put("studentId", selectedStudent.get("personId"));
            
            // 发送请求
            DataRequest request = new DataRequest();
            if (currentPracticeId != null) {
                request.add("practiceId", currentPracticeId);
            }
            request.add("form", form);
            
            DataResponse response = HttpRequestUtil.request("/api/social-practice/edit", request);
            if (response != null && response.getCode() == 0) {
                MessageDialog.showDialog("保存成功");
                
                if (currentPracticeId == null && response.getData() != null) {
                    Object data = response.getData();
                    if (data instanceof Map) {
                        @SuppressWarnings("unchecked")
                        Map<String, Object> dataMap = (Map<String, Object>) data;
                        currentPracticeId = safeGetInteger(dataMap, "practiceId");
                    }
                }
                
                loadData();
            } else {
                MessageDialog.showDialog("保存失败: " + (response != null ? response.getMsg() : "未知错误"));
            }
        } catch (NumberFormatException e) {
            MessageDialog.showDialog("实践学时必须是数字");
        } catch (Exception e) {
            MessageDialog.showDialog("保存失败: " + e.getMessage());
        }
    }
    
    @FXML
    private void onClearButtonClick(ActionEvent event) {
        clearForm();
    }
    
    @FXML
    private void onSelectStudentButtonClick(ActionEvent event) {
        // 调用学生选择对话框
        Map<String, Object> student = StudentSelectDialog.showDialog();
        if (student != null) {
            selectedStudent = student;
            studentField.setText(student.get("name") + " (" + student.get("num") + ")");
        }
    }
} 