package com.teach.javafx.controller;

import com.teach.javafx.MainApplication;
import com.teach.javafx.controller.base.MessageDialog;
import com.teach.javafx.controller.base.StudentSelectDialog;
import com.teach.javafx.request.DataRequest;
import com.teach.javafx.request.DataResponse;
import com.teach.javafx.request.HttpRequestUtil;
import com.teach.javafx.request.OptionItem;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.MapValueFactory;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.util.Callback;
import javafx.scene.layout.Priority;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 社会实践管理控制器
 */
public class SocialPracticeController {
    // 查询和列表展示相关组件
    @FXML
    private TextField keywordTextField;
    
    @FXML
    private ComboBox<OptionItem> practiceTypeComboBox;
    
    @FXML
    private TableView<Map<String, Object>> dataTableView;
    
    @FXML
    private TableColumn<Map<String, Object>, String> titleColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> typeColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> levelColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> startDateColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> endDateColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> studentNameColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> studentNumColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> organizationColumn;
    
    // 详情编辑相关组件
    @FXML
    private TextField titleField;
    
    @FXML
    private ComboBox<OptionItem> typeComboBox;
    
    @FXML
    private ComboBox<OptionItem> levelComboBox;
    
    @FXML
    private DatePicker startDatePicker;
    
    @FXML
    private DatePicker endDatePicker;
    
    @FXML
    private TextField organizationField;
    
    @FXML
    private TextField studentField;
    
    @FXML
    private TextField certificateNumberField;
    
    @FXML
    private TextArea descriptionTextArea;
    
    // 数据列表
    private ObservableList<Map<String, Object>> dataList = FXCollections.observableArrayList();
    
    // 当前选中的学生
    private Map<String, Object> selectedStudent = null;
    
    // 当前实践ID
    private Integer currentPracticeId = null;
    
    // 日期格式化器
    private final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    
    private SocialPracticeEditController socialPracticeEditController = null;
    private Stage editStage = null;
    
    private Map<String, String> practiceTypeMap;
    private Map<String, String> levelMap;

    @FXML
    public void initialize() {
        // 初始化表格列
        titleColumn.setCellValueFactory(cellData -> new SimpleStringProperty(String.valueOf(cellData.getValue().get("title"))));
        typeColumn.setCellValueFactory(cellData -> {
            String value = String.valueOf(cellData.getValue().get("practiceType"));
            String label = value;
            for (OptionItem item : typeComboBox.getItems()) {
                if (item.getValue().equals(value)) {
                    label = item.getTitle();
                    break;
                }
            }
            return new SimpleStringProperty(label);
        });
        levelColumn.setCellValueFactory(cellData -> {
            String value = String.valueOf(cellData.getValue().get("level"));
            String label = value;
            for (OptionItem item : levelComboBox.getItems()) {
                if (item.getValue().equals(value)) {
                    label = item.getTitle();
                    break;
                }
            }
            return new SimpleStringProperty(label);
        });
        startDateColumn.setCellValueFactory(cellData -> {
            Object value = cellData.getValue().get("startDate");
            if (value != null && !value.toString().isEmpty()) {
                try {
                    LocalDate date = LocalDate.parse(value.toString(), dateFormatter);
                    return new SimpleStringProperty(date.format(dateFormatter));
                } catch (Exception e) {
                    return new SimpleStringProperty(value.toString());
                }
            }
            return new SimpleStringProperty("");
        });
        endDateColumn.setCellValueFactory(cellData -> {
            Object value = cellData.getValue().get("endDate");
            if (value != null && !value.toString().isEmpty()) {
                try {
                    LocalDate date = LocalDate.parse(value.toString(), dateFormatter);
                    return new SimpleStringProperty(date.format(dateFormatter));
                } catch (Exception e) {
                    return new SimpleStringProperty(value.toString());
                }
            }
            return new SimpleStringProperty("");
        });
        studentNameColumn.setCellValueFactory(cellData -> new SimpleStringProperty(String.valueOf(cellData.getValue().get("studentName"))));
        studentNumColumn.setCellValueFactory(cellData -> new SimpleStringProperty(String.valueOf(cellData.getValue().get("studentNum"))));
        organizationColumn.setCellValueFactory(cellData -> new SimpleStringProperty(String.valueOf(cellData.getValue().get("organization"))));
        
        // 初始化下拉框选项
        practiceTypeMap = new HashMap<>();
        practiceTypeMap.put("社会调研", "社会调研");
        practiceTypeMap.put("志愿服务", "志愿服务");
        practiceTypeMap.put("实习实践", "实习实践");
        practiceTypeMap.put("其他", "其他");
        
        levelMap = new HashMap<>();
        levelMap.put("国家级", "国家级");
        levelMap.put("省级", "省级");
        levelMap.put("市级", "市级");
        levelMap.put("校级", "校级");
        levelMap.put("院级", "院级");
        
        // 设置下拉框选项
        List<OptionItem> practiceTypeItems = new ArrayList<>();
        practiceTypeItems.add(new OptionItem(0, "", "全部"));
        practiceTypeMap.forEach((key, value) -> practiceTypeItems.add(new OptionItem(practiceTypeItems.size(), value, value)));
        practiceTypeComboBox.setItems(FXCollections.observableArrayList(practiceTypeItems));
        practiceTypeComboBox.getSelectionModel().selectFirst();
        
        List<OptionItem> typeItems = new ArrayList<>();
        practiceTypeMap.forEach((key, value) -> typeItems.add(new OptionItem(typeItems.size(), value, value)));
        typeComboBox.setItems(FXCollections.observableArrayList(typeItems));
        
        List<OptionItem> levelItems = new ArrayList<>();
        levelMap.forEach((key, value) -> levelItems.add(new OptionItem(levelItems.size(), value, value)));
        levelComboBox.setItems(FXCollections.observableArrayList(levelItems));
        
        // 设置表格数据源
        dataTableView.setItems(dataList);
        
        // 添加表格选择监听器
        dataTableView.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                onTableRowSelected(newSelection);
            }
        });
        
        // 初始加载数据
        onQueryButtonClick(null);
        
        studentField.setEditable(false);
        studentField.setOnMouseClicked(event -> onSelectStudentButtonClick(null));
    }
    
    @FXML
    private void onQueryButtonClick(ActionEvent event) {
        String keyword = keywordTextField.getText();
        String practiceType = practiceTypeComboBox.getValue() != null ? practiceTypeComboBox.getValue().getValue() : "";
        
        DataRequest req = new DataRequest();
        req.add("keyword", keyword);
        req.add("practiceType", practiceType);
        
        DataResponse res = HttpRequestUtil.request("/api/social-practice/list", req);
        if (res.getCode() == 0) {
            dataList.clear();
            dataList.addAll((List<Map<String, Object>>) res.getData());
        } else {
            MessageDialog.showDialog(res.getMsg());
        }
    }
    
    @FXML
    private void onAddButtonClick(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(MainApplication.class.getResource("/com/teach/javafx/social-practice-edit-dialog.fxml"));
            VBox page = loader.load();

            Stage dialogStage = new Stage();
            dialogStage.setTitle("新增社会实践");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(MainApplication.getMainStage());
            Scene scene = new Scene(page);
            dialogStage.setScene(scene);

            SocialPracticeEditController controller = loader.getController();
            controller.setDialogStage(dialogStage);
            controller.showDialog(null); // 传null表示新增

            dialogStage.showAndWait();

            Map<String, Object> form = controller.getResultData();
            if (form != null) {
                DataRequest req = new DataRequest();
                req.add("form", form);
                DataResponse res = HttpRequestUtil.request("/api/social-practice/edit", req);
                if (res.getCode() == 0) {
                    MessageDialog.showDialog("保存成功");
                    keywordTextField.setText("");
                    practiceTypeComboBox.getSelectionModel().selectFirst();
                    onQueryButtonClick(null);
                } else {
                    MessageDialog.showDialog(res.getMsg());
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            MessageDialog.showDialog("打开新增实践窗口失败: " + e.getMessage());
        }
    }
    
    @FXML
    private void onDeleteButtonClick(ActionEvent event) {
        Map<String, Object> selectedItem = dataTableView.getSelectionModel().getSelectedItem();
        if (selectedItem == null) {
            MessageDialog.showDialog("请选择要删除的实践记录");
            return;
        }
        
        if (MessageDialog.choiceDialog("确定要删除选中的实践记录吗？") == MessageDialog.CHOICE_YES) {
            DataRequest req = new DataRequest();
            req.add("practiceId", selectedItem.get("practiceId"));
            
            DataResponse res = HttpRequestUtil.request("/api/social-practice/delete", req);
            if (res.getCode() == 0) {
                MessageDialog.showDialog("删除成功");
                onQueryButtonClick(null);
            } else {
                MessageDialog.showDialog(res.getMsg());
            }
        }
    }
    
    @FXML
    private void onSaveButtonClick(ActionEvent event) {
        if (selectedStudent == null) {
            MessageDialog.showDialog("请选择参与学生");
            return;
        }
        Map<String, Object> form = new HashMap<>();
        form.put("practiceId", currentPracticeId != null ? currentPracticeId : 0);
        form.put("studentId", selectedStudent.get("personId"));
        form.put("title", titleField.getText());
        form.put("practiceType", typeComboBox.getValue() != null ? typeComboBox.getValue().getTitle() : "");
        form.put("level", levelComboBox.getValue() != null ? levelComboBox.getValue().getTitle() : "");
        form.put("startDate", startDatePicker.getValue() != null ? startDatePicker.getValue().toString() : "");
        form.put("endDate", endDatePicker.getValue() != null ? endDatePicker.getValue().toString() : "");
        form.put("organization", organizationField.getText());
        form.put("certificateNumber", certificateNumberField.getText());
        form.put("description", descriptionTextArea.getText());

        Object pid = form.get("practiceId");
        int practiceId = 0;
        if (pid instanceof Number) {
            practiceId = ((Number) pid).intValue();
        } else if (pid instanceof String && !((String) pid).isEmpty()) {
            try { practiceId = Integer.parseInt((String) pid); } catch (Exception e) {}
        }
        form.put("practiceId", practiceId);

        DataRequest req = new DataRequest();
        req.add("form", form);

        DataResponse res = HttpRequestUtil.request("/api/social-practice/edit", req);
        if (res.getCode() == 0) {
            MessageDialog.showDialog("保存成功");
            keywordTextField.setText("");
            practiceTypeComboBox.getSelectionModel().selectFirst();
            onQueryButtonClick(null);
            clearForm();
        } else {
            MessageDialog.showDialog(res.getMsg());
        }
    }
    
    @FXML
    private void onClearButtonClick(ActionEvent event) {
        clearForm();
    }
    
    @FXML
    private void onSelectStudentButtonClick(ActionEvent event) {
        try {
            // 加载所有学生
            DataRequest request = new DataRequest();
            request.add("numName", ""); // 空字符串表示获取所有学生
            DataResponse response = HttpRequestUtil.request("/api/student/getStudentList", request);
            List<Map<String, Object>> studentsList = new ArrayList<>();
            if (response != null && response.getCode() == 0 && response.getData() != null) {
                studentsList = (List<Map<String, Object>>) response.getData();
                if (!studentsList.isEmpty()) {
                    showStudentSelectionDialog(studentsList);
                } else {
                    MessageDialog.showDialog("没有可选择的学生数据");
                }
            } else {
                String errorMsg = response != null ? response.getMsg() : "无法连接到服务器";
                MessageDialog.showDialog("获取学生列表失败: " + errorMsg);
            }
        } catch (Exception e) {
            e.printStackTrace();
            MessageDialog.showDialog("获取学生列表时发生错误: " + e.getMessage());
        }
    }

    private void showStudentSelectionDialog(List<Map<String, Object>> students) {
        try {
            // 搜索区域
            HBox searchBox = new HBox(10);
            searchBox.setPadding(new Insets(0, 0, 10, 0));
            TextField searchField = new TextField();
            searchField.setPromptText("输入学号或姓名搜索");
            searchField.setPrefWidth(200);
            Button searchButton = new Button("查询");
            searchBox.getChildren().addAll(new Label("搜索："), searchField, searchButton);

            TableView<Map<String, Object>> tableView = new TableView<>();
            tableView.setPrefSize(500, 400);

            TableColumn<Map<String, Object>, String> numCol = new TableColumn<>("学号");
            numCol.setCellValueFactory(cellData -> {
                Object value = cellData.getValue().get("num");
                return new SimpleStringProperty(value != null ? value.toString() : "");
            });
            numCol.setPrefWidth(100);

            TableColumn<Map<String, Object>, String> nameCol = new TableColumn<>("姓名");
            nameCol.setCellValueFactory(cellData -> {
                Object value = cellData.getValue().get("name");
                return new SimpleStringProperty(value != null ? value.toString() : "");
            });
            nameCol.setPrefWidth(100);

            TableColumn<Map<String, Object>, String> classCol = new TableColumn<>("班级");
            classCol.setCellValueFactory(cellData -> {
                Object value = cellData.getValue().get("className");
                return new SimpleStringProperty(value != null ? value.toString() : "");
            });
            classCol.setPrefWidth(120);

            TableColumn<Map<String, Object>, String> deptCol = new TableColumn<>("院系");
            deptCol.setCellValueFactory(cellData -> {
                Object value = cellData.getValue().get("dept");
                return new SimpleStringProperty(value != null ? value.toString() : "");
            });
            deptCol.setPrefWidth(120);

            tableView.getColumns().addAll(numCol, nameCol, classCol, deptCol);
            tableView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);

            ObservableList<Map<String, Object>> dataList = FXCollections.observableArrayList(students);
            tableView.setItems(dataList);

            // 查询按钮事件
            searchButton.setOnAction(e -> {
                String keyword = searchField.getText();
                DataRequest request = new DataRequest();
                request.add("numName", keyword == null ? "" : keyword);
                DataResponse response = HttpRequestUtil.request("/api/student/getStudentList", request);
                if (response != null && response.getCode() == 0 && response.getData() != null) {
                    List<Map<String, Object>> list = (List<Map<String, Object>>) response.getData();
                    dataList.setAll(list);
                } else {
                    dataList.clear();
                }
            });

            Button selectButton = new Button("选择");
            Button cancelButton = new Button("取消");
            HBox buttonBox = new HBox(10, selectButton, cancelButton);
            buttonBox.setStyle("-fx-alignment: center-right;");
            VBox vbox = new VBox(10, searchBox, tableView, buttonBox);
            vbox.setPadding(new Insets(10));

            Stage stage = new Stage();
            stage.setTitle("选择学生");
            stage.setScene(new Scene(vbox));
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setResizable(false);

            selectButton.setOnAction(e -> {
                Map<String, Object> selected = tableView.getSelectionModel().getSelectedItem();
                if (selected != null) {
                    selectedStudent = selected;
                    String studentName = String.valueOf(selected.get("name"));
                    String studentNum = String.valueOf(selected.get("num"));
                    studentField.setText(studentName + " (" + studentNum + ")");
                    stage.close();
                } else {
                    MessageDialog.showDialog("请选择一个学生");
                }
            });

            cancelButton.setOnAction(e -> stage.close());

            stage.showAndWait();
        } catch (Exception e) {
            e.printStackTrace();
            MessageDialog.showDialog("显示学生选择对话框失败: " + e.getMessage());
        }
    }
    
    private void onTableRowSelected(Map<String, Object> selectedItem) {
        currentPracticeId = Integer.parseInt(selectedItem.get("practiceId").toString());
        titleField.setText((String) selectedItem.get("title"));
        // 类型
        String practiceType = (String) selectedItem.get("practiceType");
        typeComboBox.getItems().stream()
            .filter(item -> item.getValue().equals(practiceType))
            .findFirst()
            .ifPresent(item -> typeComboBox.setValue(item));
        // 级别
        String level = (String) selectedItem.get("level");
        levelComboBox.getItems().stream()
            .filter(item -> item.getValue().equals(level))
            .findFirst()
            .ifPresent(item -> levelComboBox.setValue(item));
        // 开始日期
        String startDate = (String) selectedItem.get("startDate");
        if (startDate != null && !startDate.isEmpty()) {
            startDatePicker.setValue(LocalDate.parse(startDate));
        } else {
            startDatePicker.setValue(null);
        }
        // 结束日期
        String endDate = (String) selectedItem.get("endDate");
        if (endDate != null && !endDate.isEmpty()) {
            endDatePicker.setValue(LocalDate.parse(endDate));
        } else {
            endDatePicker.setValue(null);
        }
        organizationField.setText((String) selectedItem.get("organization"));
        certificateNumberField.setText((String) selectedItem.get("certificateNumber"));
        descriptionTextArea.setText((String) selectedItem.get("description"));

        // 设置选中的学生
        selectedStudent = new HashMap<>();
        selectedStudent.put("personId", selectedItem.get("personId"));
        selectedStudent.put("name", selectedItem.get("studentName"));
        selectedStudent.put("num", selectedItem.get("studentNum"));
        // 显示学生信息
        studentField.setText(selectedItem.get("studentName") + " (" + selectedItem.get("studentNum") + ")");
    }
    
    private void clearForm() {
        currentPracticeId = null;
        selectedStudent = null;
        titleField.clear();
        typeComboBox.getSelectionModel().clearSelection();
        levelComboBox.getSelectionModel().clearSelection();
        startDatePicker.setValue(null);
        endDatePicker.setValue(null);
        organizationField.clear();
        certificateNumberField.clear();
        descriptionTextArea.clear();
        studentField.clear();
    }
} 