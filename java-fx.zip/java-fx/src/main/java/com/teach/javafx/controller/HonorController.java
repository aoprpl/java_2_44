package com.teach.javafx.controller;

import com.teach.javafx.controller.base.MessageDialog;
import com.teach.javafx.request.DataRequest;
import com.teach.javafx.request.DataResponse;
import com.teach.javafx.request.HttpRequestUtil;
import com.teach.javafx.request.OptionItem;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.util.Callback;
import javafx.scene.layout.Priority;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 学生荣誉管理控制器
 */
public class HonorController {
    // 查询和列表展示相关组件
    @FXML
    private TextField keywordTextField;
    
    @FXML
    private ComboBox<OptionItem> honorTypeComboBox;
    
    @FXML
    private TableView<Map<String, Object>> dataTableView;
    
    @FXML
    private TableColumn<Map<String, Object>, String> titleColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> typeColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> levelColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> awardDateColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> studentNameColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> studentNumColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> issuerColumn;
    
    // 详情编辑相关组件
    @FXML
    private TextField titleField;
    
    @FXML
    private ComboBox<OptionItem> typeComboBox;
    
    @FXML
    private ComboBox<OptionItem> levelComboBox;
    
    @FXML
    private DatePicker awardDatePicker;
    
    @FXML
    private TextField issuerField;
    
    @FXML
    private TextField studentField;
    
    @FXML
    private TextField certificateNumberField;
    
    @FXML
    private TextArea descriptionTextArea;
    
    // 数据列表
    private ObservableList<Map<String, Object>> dataList = FXCollections.observableArrayList();
    
    // 当前选中的学生
    private Map<String, Object> selectedStudent = null;
    
    // 当前荣誉ID
    private Integer currentHonorId = null;
    
    // 日期格式化器
    private final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    
    private HonorEditController honorEditController = null;
    private Stage editStage = null;
    
    private Map<String, String> honorTypeMap;
    private Map<String, String> levelMap;
    
    /**
     * 初始化方法，JavaFX初始化时自动调用
     */
    @FXML
    private void initialize() {
        initMaps();
        
        // 设置表格基本样式
        dataTableView.setStyle("-fx-selection-bar: #cce5ff; -fx-selection-bar-non-focused: #e6f2ff;");
        
        // 添加CSS样式类
        dataTableView.getStyleClass().add("honor-table");
        
        // 创建并应用CSS样式
        String css = ".honor-table .table-row-cell:selected { -fx-background-color: #cce5ff; }\n" +
                    ".honor-table .table-row-cell:selected:focused { -fx-background-color: #cce5ff; }\n" +
                    ".honor-table .table-row-cell:selected .table-cell { -fx-text-fill: black; }";
        dataTableView.getStylesheets().add(createStylesheet(css));
        
        // 设置表格列的宽度
        titleColumn.setPrefWidth(200);        // 荣誉称号
        typeColumn.setPrefWidth(100);         // 荣誉类型
        levelColumn.setPrefWidth(100);        // 荣誉级别
        awardDateColumn.setPrefWidth(100);    // 获奖日期
        studentNameColumn.setPrefWidth(100);  // 学生姓名
        studentNumColumn.setPrefWidth(100);   // 学号
        issuerColumn.setPrefWidth(150);       // 授予单位
        
        // 设置表格列宽自动调整策略
        dataTableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        
        // 设置表格最大化显示
        VBox.setVgrow(dataTableView, Priority.ALWAYS);
        dataTableView.setMaxHeight(Double.MAX_VALUE);
        dataTableView.setMaxWidth(Double.MAX_VALUE);
        
        // 设置单元格工厂
        Callback<TableColumn<Map<String, Object>, String>, TableCell<Map<String, Object>, String>> cellFactory = 
            new Callback<TableColumn<Map<String, Object>, String>, TableCell<Map<String, Object>, String>>() {
                @Override
                public TableCell<Map<String, Object>, String> call(TableColumn<Map<String, Object>, String> param) {
                    return new TableCell<Map<String, Object>, String>() {
                        @Override
                        protected void updateItem(String item, boolean empty) {
                            super.updateItem(item, empty);
                            
                            if (empty || item == null) {
                                setText(null);
                                setStyle("");
                            } else {
                                setText(item);
                                // 设置单元格样式
                                String style = "-fx-padding: 5 10 5 10;";
                                
                                // 设置交替行背景色
                                if (getTableRow() != null && getTableRow().getIndex() % 2 == 1) {
                                    style += "-fx-background-color: #f9f9f9;";
                                } else {
                                    style += "-fx-background-color: white;";
                                }
                                
                                // 设置选中状态样式
                                if (getTableRow() != null && getTableRow().isSelected()) {
                                    style += "-fx-background-color: #cce5ff;";
                                }
                                
                                setStyle(style);
                            }
                        }
                    };
                }
            };

        // 为每一列应用单元格工厂
        titleColumn.setCellFactory(cellFactory);
        typeColumn.setCellFactory(cellFactory);
        levelColumn.setCellFactory(cellFactory);
        awardDateColumn.setCellFactory(cellFactory);
        studentNameColumn.setCellFactory(cellFactory);
        studentNumColumn.setCellFactory(cellFactory);
        issuerColumn.setCellFactory(cellFactory);

        // 设置表头样式
        String headerStyle = "-fx-background-color: #f2f2f2; -fx-border-color: #e0e0e0; " +
                           "-fx-border-width: 0 0 1 0; -fx-padding: 5 10 5 10;";
        for (TableColumn<?,?> column : dataTableView.getColumns()) {
            column.setStyle(headerStyle);
        }

        // 初始化表格列数据
        titleColumn.setCellValueFactory(cellData -> new SimpleStringProperty(String.valueOf(cellData.getValue().get("title"))));
        typeColumn.setCellValueFactory(cellData -> {
            String honorType = String.valueOf(cellData.getValue().get("honorType"));
            String displayText = honorTypeMap.getOrDefault(honorType, honorType);
            return new SimpleStringProperty(displayText);
        });
        levelColumn.setCellValueFactory(cellData -> {
            String level = String.valueOf(cellData.getValue().get("level"));
            String displayText = levelMap.getOrDefault(level, level);
            return new SimpleStringProperty(displayText);
        });
        awardDateColumn.setCellValueFactory(cellData -> {
            Object value = cellData.getValue().get("awardDate");
            if (value != null && !value.toString().isEmpty()) {
                try {
                    LocalDate date = LocalDate.parse(value.toString(), dateFormatter);
                    return new SimpleStringProperty(date.format(dateFormatter));
                } catch (Exception e) {
                    return new SimpleStringProperty(value.toString());
                }
            }
            return new SimpleStringProperty("");
        });
        studentNameColumn.setCellValueFactory(cellData -> {
            Map<String, Object> data = cellData.getValue();
            String name = "";
            if (data.containsKey("student")) {
                Map<String, Object> student = (Map<String, Object>) data.get("student");
                if (student != null) {
                    name = String.valueOf(student.get("name"));
                }
            }
            if (name.isEmpty() && data.containsKey("studentName")) {
                name = String.valueOf(data.get("studentName"));
            }
            return new SimpleStringProperty(name);
        });
        studentNumColumn.setCellValueFactory(cellData -> {
            Map<String, Object> data = cellData.getValue();
            String num = "";
            if (data.containsKey("student")) {
                Map<String, Object> student = (Map<String, Object>) data.get("student");
                if (student != null) {
                    num = String.valueOf(student.get("num"));
                }
            }
            if (num.isEmpty() && data.containsKey("studentNum")) {
                num = String.valueOf(data.get("studentNum"));
            }
            return new SimpleStringProperty(num);
        });
        issuerColumn.setCellValueFactory(cellData -> new SimpleStringProperty(String.valueOf(cellData.getValue().get("issuer"))));
        
        // 绑定数据列表到表格
        dataTableView.setItems(dataList);
        
        // 添加选择监听器
        dataTableView.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                dataTableView.refresh();
                displayHonorDetails(newSelection);
            }
        });
        
        // 设置选择模式
        dataTableView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        
        // 初始化下拉框
        initComboBoxes();
        
        // 加载数据
        loadData();
    }
    
    /**
     * 初始化下拉框
     */
    private void initComboBoxes() {
        // 荣誉类型下拉框
        List<OptionItem> honorTypes = HttpRequestUtil.getDictionaryOptionItemList("RYLX");
        
        // 如果从服务器获取的类型为空，添加一些默认值
        if (honorTypes == null || honorTypes.isEmpty()) {
            honorTypes = new ArrayList<>();
            honorTypes.add(new OptionItem(1, "1", "奖学金"));
            honorTypes.add(new OptionItem(2, "2", "学科竞赛"));
            honorTypes.add(new OptionItem(3, "3", "科研成果"));
            honorTypes.add(new OptionItem(4, "4", "社会工作"));
            honorTypes.add(new OptionItem(5, "5", "文体活动"));
            honorTypes.add(new OptionItem(6, "6", "荣誉称号"));
            honorTypes.add(new OptionItem(7, "7", "其他"));
        }
        
        honorTypeComboBox.setItems(FXCollections.observableArrayList(honorTypes));
        typeComboBox.setItems(FXCollections.observableArrayList(honorTypes));
        
        // 荣誉级别下拉框
        List<OptionItem> honorLevels = HttpRequestUtil.getDictionaryOptionItemList("RYJB");
        
        // 如果从服务器获取的级别为空，添加一些默认值
        if (honorLevels == null || honorLevels.isEmpty()) {
            honorLevels = new ArrayList<>();
            honorLevels.add(new OptionItem(1, "1", "国家级"));
            honorLevels.add(new OptionItem(2, "2", "省级"));
            honorLevels.add(new OptionItem(3, "3", "市级"));
            honorLevels.add(new OptionItem(4, "4", "校级"));
            honorLevels.add(new OptionItem(5, "5", "院级"));
            honorLevels.add(new OptionItem(6, "6", "班级"));
        }
        
        levelComboBox.setItems(FXCollections.observableArrayList(honorLevels));
        
        // 设置默认值
        if (!honorTypes.isEmpty()) {
            honorTypeComboBox.setValue(null); // 查询时默认不选择
            typeComboBox.setValue(honorTypes.get(0)); // 新建时默认第一个类型
        }
        
        if (!honorLevels.isEmpty()) {
            levelComboBox.setValue(honorLevels.get(0)); // 默认国家级
        }
    }
    
    /**
     * 加载荣誉数据
     */
    private void loadData() {
        DataRequest request = new DataRequest();
        
        String keyword = keywordTextField.getText();
        if (keyword != null && !keyword.isEmpty()) {
            request.add("keyword", keyword);
        }
        
        OptionItem selectedType = honorTypeComboBox.getValue();
        if (selectedType != null) {
            request.add("honorType", selectedType.getValue());
        }
        
        DataResponse response = HttpRequestUtil.request("/api/honor/getHonorList", request);
        if (response != null && response.getData() != null) {
            dataList.clear();
            List<Map<String, Object>> list = (List<Map<String, Object>>) response.getData();
            
            // 处理每条记录
            for (Map<String, Object> honor : list) {
                // 处理学生信息
                if (honor.containsKey("student")) {
                    Map<String, Object> student = (Map<String, Object>) honor.get("student");
                    if (student != null) {
                        // 直接设置学生信息到主对象
                        honor.put("studentName", student.get("name"));
                        honor.put("studentNum", student.get("num"));
                    }
                }
                
                // 处理日期格式
                Object awardDate = honor.get("awardDate");
                if (awardDate != null) {
                    try {
                        LocalDate date = LocalDate.parse(awardDate.toString(), dateFormatter);
                        honor.put("awardDate", date.format(dateFormatter));
                    } catch (Exception e) {
                        // 保持原始日期格式
                    }
                }
            }
            
            // 更新数据列表
            dataList.addAll(list);
            
            // 强制刷新表格
            dataTableView.setItems(null);
            dataTableView.setItems(dataList);
            dataTableView.refresh();
            dataTableView.requestLayout();
            
            // 如果有选中的记录，保持选中状态
            if (currentHonorId != null) {
                for (int i = 0; i < dataList.size(); i++) {
                    Map<String, Object> item = dataList.get(i);
                    if (currentHonorId.equals(safeGetInteger(item, "honorId"))) {
                        dataTableView.getSelectionModel().select(i);
                        break;
                    }
                }
            }
        }
    }
    
    /**
     * 显示荣誉详情
     */
    private void displayHonorDetails(Map<String, Object> honor) {
        try {
            // 安全地处理ID
            currentHonorId = safeGetInteger(honor, "honorId");
            
            titleField.setText(String.valueOf(honor.get("title")));
            
            String honorType = String.valueOf(honor.get("honorType"));
            for (OptionItem item : typeComboBox.getItems()) {
                if (item.getValue().equals(honorType)) {
                    typeComboBox.setValue(item);
                    break;
                }
            }
            
            String level = String.valueOf(honor.get("level"));
            for (OptionItem item : levelComboBox.getItems()) {
                if (item.getValue().equals(level)) {
                    levelComboBox.setValue(item);
                    break;
                }
            }
            
            Object awardDateObj = honor.get("awardDate");
            if (awardDateObj != null && !awardDateObj.toString().isEmpty()) {
                try {
                    LocalDate awardDate = LocalDate.parse(awardDateObj.toString(), dateFormatter);
                    awardDatePicker.setValue(awardDate);
                } catch (Exception e) {
                    awardDatePicker.setValue(null);
                }
            } else {
                awardDatePicker.setValue(null);
            }
            
            issuerField.setText(String.valueOf(honor.get("issuer")));
            certificateNumberField.setText(String.valueOf(honor.get("certificateNumber")));
            descriptionTextArea.setText(String.valueOf(honor.get("description")));
            
            // 处理学生信息
            Object studentObj = honor.get("student");
            if (studentObj instanceof Map) {
                Map<String, Object> student = (Map<String, Object>) studentObj;
                selectedStudent = student;
                // 获取学生姓名和学号，优先使用name/num字段，如果没有则尝试studentName/studentNum
                String name = getStudentField(student, "name", "studentName");
                String num = getStudentField(student, "num", "studentNum");
                studentField.setText(name + " (" + num + ")");
                
                // 打印调试信息
                System.out.println("显示学生信息: " + student);
            } else {
                // 尝试直接从荣誉对象中获取学生信息
                String name = getStudentField(honor, "studentName", "name");
                String num = getStudentField(honor, "studentNum", "num");
                if (!name.isEmpty() && !num.isEmpty()) {
                    Map<String, Object> student = new HashMap<>();
                    student.put("name", name);
                    student.put("num", num);
                    student.put("personId", honor.get("studentId"));
                    selectedStudent = student;
                    studentField.setText(name + " (" + num + ")");
                } else {
                    selectedStudent = null;
                    studentField.setText("");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("显示荣誉详情时出错: " + e.getMessage());
        }
    }
    
    /**
     * 从Map中获取学生字段值，支持多个可能的字段名
     */
    private String getStudentField(Map<String, Object> map, String... possibleKeys) {
        for (String key : possibleKeys) {
            Object value = map.get(key);
            if (value != null && !value.toString().trim().isEmpty() && !"null".equals(value.toString().trim())) {
                return value.toString().trim();
            }
        }
        return "";
    }
    
    /**
     * 清空表单
     */
    private void clearForm() {
        currentHonorId = null;
        titleField.setText("");
        issuerField.setText("");
        certificateNumberField.setText("");
        descriptionTextArea.setText("");
        selectedStudent = null;
        studentField.setText("");
        
        // 重置日期选择器
        awardDatePicker.setValue(LocalDate.now());
        
        // 设置默认值
        if (!typeComboBox.getItems().isEmpty()) {
            typeComboBox.setValue(typeComboBox.getItems().get(0));
        }
        
        if (!levelComboBox.getItems().isEmpty()) {
            levelComboBox.setValue(levelComboBox.getItems().get(0));
        }
    }
    
    /**
     * 添加按钮点击事件
     */
    @FXML
    private void onAddButtonClick() {
        initEditDialog();
        honorEditController.showDialog(null);
        editStage.showAndWait();
    }
    
    /**
     * 清空按钮点击事件
     */
    @FXML
    private void onClearButtonClick(ActionEvent event) {
        clearForm();
    }
    
    /**
     * 删除按钮点击事件
     */
    @FXML
    private void onDeleteButtonClick(ActionEvent event) {
        Map<String, Object> selectedHonor = dataTableView.getSelectionModel().getSelectedItem();
        if (selectedHonor == null) {
            MessageDialog.showDialog("请先选择一条荣誉记录");
            return;
        }
        
        // 安全地处理ID
        Integer honorId = safeGetInteger(selectedHonor, "honorId");
        
        if (honorId == null) {
            MessageDialog.showDialog("荣誉ID无效");
            return;
        }
        
        if (MessageDialog.choiceDialog("确定要删除该荣誉记录吗？") == MessageDialog.CHOICE_YES) {
            DataRequest request = new DataRequest();
            request.add("honorId", honorId);
            
            DataResponse response = HttpRequestUtil.request("/api/honor/honorDelete", request);
            if (response != null && response.getCode() == 0) {
                MessageDialog.showDialog("删除成功");
                
                // 重新加载数据
                DataRequest queryRequest = new DataRequest();
                String keyword = keywordTextField.getText();
                if (keyword != null && !keyword.isEmpty()) {
                    queryRequest.add("keyword", keyword);
                }
                
                OptionItem selectedType = honorTypeComboBox.getValue();
                if (selectedType != null) {
                    queryRequest.add("honorType", selectedType.getValue());
                }
                
                DataResponse queryResponse = HttpRequestUtil.request("/api/honor/getHonorList", queryRequest);
                if (queryResponse != null && queryResponse.getCode() == 0) {
                    dataList.clear();
                    List<Map<String, Object>> list = (List<Map<String, Object>>) queryResponse.getData();
                    dataList.addAll(list);
                    dataTableView.refresh();
                }
                
                clearForm(); // 清空表单
            } else {
                String errorMsg = response != null ? response.getMsg() : "未知错误";
                MessageDialog.showDialog("删除失败: " + errorMsg);
            }
        }
    }
    
    /**
     * 查询按钮点击事件
     */
    @FXML
    private void onQueryButtonClick() {
        try {
            // 构建查询请求
            DataRequest request = new DataRequest();
            
            // 添加关键词搜索
            String keyword = keywordTextField.getText();
            if (keyword != null && !keyword.isEmpty()) {
                // 处理多个关键词
                String[] keywords = keyword.split("\\s+");  // 按空格分割关键词
                if (keywords.length > 0) {
                    // 第一个关键词用于学生信息搜索
                    request.add("studentName", keywords[0]);  // 学生姓名
                    request.add("studentNum", keywords[0]);   // 同时搜索学号
                    
                    // 如果有第二个关键词，用于荣誉信息搜索
                    if (keywords.length > 1) {
                        request.add("title", keywords[1]);
                    }
                }
            }
            
            // 添加荣誉类型筛选
            OptionItem selectedType = honorTypeComboBox.getValue();
            if (selectedType != null) {
                request.add("honorType", selectedType.getValue());
            }
            
            // 打印请求参数，用于调试
            System.out.println("查询请求参数: " + request);
            
            // 发送查询请求
            DataResponse response = HttpRequestUtil.request("/api/honor/getHonorList", request);
            
            if (response != null && response.getCode() == 0) {
                // 清空现有数据
                dataList.clear();
                
                // 获取并处理返回的数据
                List<Map<String, Object>> list = (List<Map<String, Object>>) response.getData();
                if (list != null) {
                    // 打印返回的数据，用于调试
                    System.out.println("服务器返回数据: " + list);
                    
                    // 获取查询条件
                    String studentName = keyword != null && !keyword.isEmpty() ? keyword.split("\\s+")[0] : null;
                    String honorType = selectedType != null ? selectedType.getValue() : null;
                    
                    // 处理每条记录
                    for (Map<String, Object> honor : list) {
                        // 处理学生信息
                        if (honor.containsKey("student")) {
                            Map<String, Object> student = (Map<String, Object>) honor.get("student");
                            if (student != null) {
                                // 直接设置学生信息到主对象
                                honor.put("studentName", student.get("name"));
                                honor.put("studentNum", student.get("num"));
                            }
                        }
                        
                        // 处理日期格式
                        Object awardDate = honor.get("awardDate");
                        if (awardDate != null) {
                            try {
                                LocalDate date = LocalDate.parse(awardDate.toString(), dateFormatter);
                                honor.put("awardDate", date.format(dateFormatter));
                            } catch (Exception e) {
                                // 保持原始日期格式
                            }
                        }
                        
                        // 打印处理后的记录，用于调试
                        System.out.println("处理后的记录: " + honor);
                        
                        // 检查是否满足所有查询条件
                        boolean matchesStudent = studentName == null || 
                            (honor.get("studentName") != null && 
                             honor.get("studentName").toString().contains(studentName));
                        
                        boolean matchesType = honorType == null || 
                            (honor.get("honorType") != null && 
                             honor.get("honorType").toString().equals(honorType));
                        
                        // 只添加满足所有条件的记录
                        if (matchesStudent && matchesType) {
                            dataList.add(honor);
                        }
                    }
                }
                
                // 强制刷新表格
                dataTableView.setItems(null);
                dataTableView.setItems(dataList);
                dataTableView.refresh();
                dataTableView.requestLayout();
                
                // 清空表单
                clearForm();
                
                // 显示查询结果数量
                MessageDialog.showDialog("查询完成，共找到 " + dataList.size() + " 条记录");
            } else {
                String errorMsg = response != null ? response.getMsg() : "未知错误";
                MessageDialog.showDialog("查询失败: " + errorMsg);
            }
        } catch (Exception e) {
            e.printStackTrace();
            MessageDialog.showDialog("查询时发生异常: " + e.getMessage());
        }
    }
    
    /**
     * 保存按钮点击事件
     */
    @FXML
    private void onSaveButtonClick(ActionEvent event) {
        try {
            // 验证输入
            if (titleField.getText().isEmpty()) {
                MessageDialog.showDialog("荣誉称号不能为空");
                return;
            }
            
            if (typeComboBox.getValue() == null) {
                MessageDialog.showDialog("请选择荣誉类型");
                return;
            }
            
            if (levelComboBox.getValue() == null) {
                MessageDialog.showDialog("请选择荣誉级别");
                return;
            }
            
            if (awardDatePicker.getValue() == null) {
                MessageDialog.showDialog("请选择获奖日期");
                return;
            }
            
            if (selectedStudent == null) {
                MessageDialog.showDialog("请选择获奖学生");
                return;
            }
            
            // 构建请求数据
            DataRequest request = new DataRequest();
            request.add("honorId", currentHonorId);
            request.add("title", titleField.getText());
            request.add("honorType", typeComboBox.getValue().getValue());
            request.add("level", levelComboBox.getValue().getValue());
            request.add("awardDate", awardDatePicker.getValue().format(dateFormatter));
            request.add("issuer", issuerField.getText());
            request.add("certificateNumber", certificateNumberField.getText());
            request.add("description", descriptionTextArea.getText());
            request.add("studentId", selectedStudent.get("personId"));
            
            // 发送请求
            DataResponse response = HttpRequestUtil.request("/api/honor/honorSave", request);
            
            if (response != null) {
                if (response.getCode() == 0) {
                    MessageDialog.showDialog("保存成功");
                    
                    // 构建更新后的荣誉数据
                    Map<String, Object> updatedHonor = new HashMap<>();
                    updatedHonor.put("honorId", currentHonorId);
                    updatedHonor.put("title", titleField.getText());
                    updatedHonor.put("honorType", typeComboBox.getValue().getValue());
                    updatedHonor.put("level", levelComboBox.getValue().getValue());
                    updatedHonor.put("awardDate", awardDatePicker.getValue().format(dateFormatter));
                    updatedHonor.put("issuer", issuerField.getText());
                    updatedHonor.put("certificateNumber", certificateNumberField.getText());
                    updatedHonor.put("description", descriptionTextArea.getText());
                    
                    // 添加学生信息
                    Map<String, Object> studentInfo = new HashMap<>();
                    studentInfo.put("personId", selectedStudent.get("personId"));
                    studentInfo.put("name", selectedStudent.get("name"));
                    studentInfo.put("num", selectedStudent.get("num"));
                    updatedHonor.put("student", studentInfo);
                    updatedHonor.put("studentName", selectedStudent.get("name"));
                    updatedHonor.put("studentNum", selectedStudent.get("num"));
                    
                    // 更新表格数据
                    if (currentHonorId != null) {
                        // 更新现有记录
                        for (int i = 0; i < dataList.size(); i++) {
                            Map<String, Object> item = dataList.get(i);
                            if (currentHonorId.equals(safeGetInteger(item, "honorId"))) {
                                dataList.set(i, updatedHonor);
                                break;
                            }
                        }
                    } else {
                        // 添加新记录
                        dataList.add(updatedHonor);
                    }
                    
                    // 强制刷新表格
                    dataTableView.setItems(null);
                    dataTableView.setItems(dataList);
                    dataTableView.refresh();
                    dataTableView.requestLayout();
                    
                    // 重新选中当前记录
                    if (currentHonorId != null) {
                        for (int i = 0; i < dataList.size(); i++) {
                            Map<String, Object> item = dataList.get(i);
                            if (currentHonorId.equals(safeGetInteger(item, "honorId"))) {
                                dataTableView.getSelectionModel().select(i);
                                break;
                            }
                        }
                    } else {
                        dataTableView.getSelectionModel().select(dataList.size() - 1);
                    }
                    
                    // 清空表单
                    clearForm();
                } else {
                    String errorMsg = response.getMsg();
                    if (errorMsg == null || errorMsg.isEmpty()) {
                        errorMsg = "服务器返回未知错误";
                    }
                    MessageDialog.showDialog("保存失败: " + errorMsg);
                }
            } else {
                MessageDialog.showDialog("保存失败: 无法连接到服务器");
            }
        } catch (Exception e) {
            e.printStackTrace();
            MessageDialog.showDialog("保存时发生异常: " + e.getMessage());
        }
    }
    
    /**
     * 选择学生按钮点击事件
     */
    @FXML
    private void onSelectStudentButtonClick(ActionEvent event) {
        try {
            // 加载所有学生
            DataRequest request = new DataRequest();
            request.add("numName", ""); // 空字符串表示获取所有学生
            DataResponse response = HttpRequestUtil.request("/api/student/getStudentList", request);
            List<Map<String, Object>> studentsList = new ArrayList<>();
            
            if (response != null && response.getCode() == 0 && response.getData() != null) {
                studentsList = (List<Map<String, Object>>) response.getData();
                
                if (!studentsList.isEmpty()) {
                    // 创建学生选择对话框
                    showStudentSelectionDialog(studentsList);
                } else {
                    MessageDialog.showDialog("没有可选择的学生数据");
                }
            } else {
                String errorMsg = response != null ? response.getMsg() : "无法连接到服务器";
                MessageDialog.showDialog("获取学生列表失败: " + errorMsg);
            }
        } catch (Exception e) {
            e.printStackTrace();
            MessageDialog.showDialog("获取学生列表时发生错误: " + e.getMessage());
        }
    }
    
    private void showStudentSelectionDialog(List<Map<String, Object>> students) {
        try {
            // 创建一个临时表格
            TableView<Map<String, Object>> tableView = new TableView<>();
            tableView.setPrefSize(500, 400);
            
            // 添加列
            TableColumn<Map<String, Object>, String> numCol = new TableColumn<>("学号");
            numCol.setCellValueFactory(cellData -> {
                Object value = cellData.getValue().get("num");
                return new SimpleStringProperty(value != null ? value.toString() : "");
            });
            numCol.setPrefWidth(100);
            
            TableColumn<Map<String, Object>, String> nameCol = new TableColumn<>("姓名");
            nameCol.setCellValueFactory(cellData -> {
                Object value = cellData.getValue().get("name");
                return new SimpleStringProperty(value != null ? value.toString() : "");
            });
            nameCol.setPrefWidth(100);
            
            TableColumn<Map<String, Object>, String> classCol = new TableColumn<>("班级");
            classCol.setCellValueFactory(cellData -> {
                Object value = cellData.getValue().get("className");
                return new SimpleStringProperty(value != null ? value.toString() : "");
            });
            classCol.setPrefWidth(120);
            
            TableColumn<Map<String, Object>, String> deptCol = new TableColumn<>("院系");
            deptCol.setCellValueFactory(cellData -> {
                Object value = cellData.getValue().get("dept");
                return new SimpleStringProperty(value != null ? value.toString() : "");
            });
            deptCol.setPrefWidth(120);
            
            tableView.getColumns().addAll(numCol, nameCol, classCol, deptCol);
            tableView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
            
            // 添加数据
            ObservableList<Map<String, Object>> studentList = FXCollections.observableArrayList(students);
            tableView.setItems(studentList);
            
            // 添加搜索功能
            TextField searchField = new TextField();
            searchField.setPromptText("输入学号或姓名搜索");
            searchField.setPrefWidth(250);
            
            Button searchButton = new Button("搜索");
            searchButton.setOnAction(e -> {
                String keyword = searchField.getText().toLowerCase();
                ObservableList<Map<String, Object>> filteredList = FXCollections.observableArrayList();
                
                for (Map<String, Object> student : students) {
                    String num = String.valueOf(student.get("num")).toLowerCase();
                    String name = String.valueOf(student.get("name")).toLowerCase();
                    
                    if (num.contains(keyword) || name.contains(keyword)) {
                        filteredList.add(student);
                    }
                }
                
                tableView.setItems(filteredList);
            });
            
            HBox searchBox = new HBox(10, new Label("搜索:"), searchField, searchButton);
            searchBox.setPadding(new Insets(10));
            searchBox.setAlignment(Pos.CENTER_LEFT);
            
            // 创建布局
            VBox vbox = new VBox(10);
            vbox.setPadding(new Insets(10));
            
            Label titleLabel = new Label("选择获奖学生");
            titleLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 14px;");
            
            HBox buttonBox = new HBox(10);
            buttonBox.setAlignment(Pos.CENTER);
            
            Button selectButton = new Button("选择");
            Button cancelButton = new Button("取消");
            
            buttonBox.getChildren().addAll(selectButton, cancelButton);
            vbox.getChildren().addAll(titleLabel, searchBox, tableView, buttonBox);
            
            // 创建场景和舞台
            Scene scene = new Scene(vbox);
            Stage stage = new Stage();
            stage.setTitle("选择学生");
            stage.setScene(scene);
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setResizable(false);
            
            // 设置按钮事件
            selectButton.setOnAction(e -> {
                Map<String, Object> selectedStudent = tableView.getSelectionModel().getSelectedItem();
                if (selectedStudent != null) {
                    this.selectedStudent = selectedStudent;
                    String studentName = String.valueOf(selectedStudent.get("name"));
                    String studentNum = String.valueOf(selectedStudent.get("num"));
                    studentField.setText(studentName + " (" + studentNum + ")");
                    stage.close();
                } else {
                    MessageDialog.showDialog("请选择一个学生");
                }
            });
            
            cancelButton.setOnAction(e -> stage.close());
            
            // 显示舞台
            stage.showAndWait();
        } catch (Exception e) {
            e.printStackTrace();
            MessageDialog.showDialog("显示学生选择对话框失败: " + e.getMessage());
        }
    }
    
    /**
     * 安全地从Map中获取Integer值
     */
    private Integer safeGetInteger(Map<String, Object> map, String key) {
        Object value = map.get(key);
        return safeGetInteger(value);
    }
    
    /**
     * 安全地将对象转换为Integer
     */
    private Integer safeGetInteger(Object value) {
        if (value == null) {
            return null;
        }
        
        if (value instanceof Integer) {
            return (Integer) value;
        } else if (value instanceof Double) {
            return ((Double) value).intValue();
        } else if (value instanceof Number) {
            return ((Number) value).intValue();
        } else {
            try {
                return Integer.parseInt(value.toString());
            } catch (NumberFormatException e) {
                System.out.println("无法转换为Integer: " + value + ", 类型: " + value.getClass().getName());
                return null;
            }
        }
    }

    private void initEditDialog() {
        if (editStage == null) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/teach/javafx/honor-edit-dialog.fxml"));
                Scene scene = new Scene(loader.load());
                honorEditController = loader.getController();
                honorEditController.setHonorController(this);

                editStage = new Stage();
                editStage.setTitle("编辑荣誉信息");
                editStage.setScene(scene);
                editStage.initModality(Modality.APPLICATION_MODAL);
                editStage.setResizable(false);
            } catch (IOException e) {
                e.printStackTrace();
                MessageDialog.showDialog("加载编辑窗口失败：" + e.getMessage());
            }
        }
    }

    @FXML
    private void onEditButtonClick() {
        Map<String, Object> selectedItem = dataTableView.getSelectionModel().getSelectedItem();
        if (selectedItem == null) {
            MessageDialog.showDialog("请先选择要编辑的荣誉记录");
            return;
        }
        initEditDialog();
        honorEditController.showDialog(selectedItem);
        editStage.showAndWait();
    }

    public void doClose(String cmd, Map<String, Object> data) {
        editStage.close();
        if (!"ok".equals(cmd)) {
            return;
        }

        try {
            // 保存数据
            DataRequest req = new DataRequest();
            // 直接添加所有字段，不再包装在form对象中
            req.add("personId", data.get("personId"));
            req.add("honorId", data.get("honorId"));
            req.add("title", data.get("title"));
            req.add("honorType", data.get("honorType"));
            req.add("level", data.get("level"));
            req.add("awardDate", data.get("awardDate"));
            req.add("issuer", data.get("issuer"));
            req.add("certificateNumber", data.get("certificateNumber"));
            req.add("description", data.get("description"));
            
            // 打印请求数据，用于调试
            System.out.println("发送保存请求: " + req);
            
            DataResponse res = HttpRequestUtil.request("/api/honor/honorSave", req);
            System.out.println("保存响应: " + (res != null ? "code=" + res.getCode() + ", msg=" + res.getMsg() : "null"));
            
            if (res != null && res.getCode() == 0) {
                MessageDialog.showDialog("保存成功");
                onQueryButtonClick(); // 重新加载数据
            } else {
                String errorMsg = res != null ? res.getMsg() : "未知错误";
                MessageDialog.showDialog("保存失败：" + errorMsg);
                System.out.println("保存失败详情: " + errorMsg);
            }
        } catch (Exception e) {
            e.printStackTrace();
            MessageDialog.showDialog("保存时发生异常: " + e.getMessage());
        }
    }

    private void initMaps() {
        // 初始化荣誉类型映射
        honorTypeMap = new HashMap<>();
        honorTypeMap.put("1", "奖学金");
        honorTypeMap.put("2", "学科竞赛");
        honorTypeMap.put("3", "科研成果");
        honorTypeMap.put("4", "社会工作");
        honorTypeMap.put("5", "文体活动");
        honorTypeMap.put("6", "荣誉称号");
        honorTypeMap.put("7", "其他");

        // 初始化荣誉级别映射
        levelMap = new HashMap<>();
        levelMap.put("1", "国家级");
        levelMap.put("2", "省级");
        levelMap.put("3", "市级");
        levelMap.put("4", "校级");
        levelMap.put("5", "院级");
        levelMap.put("6", "班级");
    }

    /**
     * 创建内联样式表
     */
    private String createStylesheet(String css) {
        return "data:text/css;base64," + java.util.Base64.getEncoder().encodeToString(css.getBytes());
    }
} 