package com.teach.javafx.controller;

import com.teach.javafx.controller.base.MessageDialog;
import com.teach.javafx.request.DataRequest;
import com.teach.javafx.request.DataResponse;
import com.teach.javafx.request.HttpRequestUtil;
import com.teach.javafx.request.OptionItem;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.geometry.Insets;
import javafx.geometry.Pos;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 学生荣誉管理控制器
 */
public class HonorController {
    // 查询和列表展示相关组件
    @FXML
    private TextField keywordTextField;
    
    @FXML
    private ComboBox<OptionItem> honorTypeComboBox;
    
    @FXML
    private TableView<Map<String, Object>> dataTableView;
    
    @FXML
    private TableColumn<Map<String, Object>, String> titleColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> typeColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> levelColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> awardDateColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> studentNameColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> studentNumColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> issuerColumn;
    
    // 详情编辑相关组件
    @FXML
    private TextField titleField;
    
    @FXML
    private ComboBox<OptionItem> typeComboBox;
    
    @FXML
    private ComboBox<OptionItem> levelComboBox;
    
    @FXML
    private DatePicker awardDatePicker;
    
    @FXML
    private TextField issuerField;
    
    @FXML
    private TextField studentField;
    
    @FXML
    private TextField certificateNumberField;
    
    @FXML
    private TextArea descriptionTextArea;
    
    // 数据列表
    private ObservableList<Map<String, Object>> dataList = FXCollections.observableArrayList();
    
    // 当前选中的学生
    private Map<String, Object> selectedStudent = null;
    
    // 当前荣誉ID
    private Integer currentHonorId = null;
    
    // 日期格式化器
    private final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    
    /**
     * 初始化方法，JavaFX初始化时自动调用
     */
    @FXML
    private void initialize() {
        // 初始化表格列
        titleColumn.setCellValueFactory(cellData -> new SimpleStringProperty(String.valueOf(cellData.getValue().get("title"))));
        typeColumn.setCellValueFactory(cellData -> {
            String honorType = String.valueOf(cellData.getValue().get("honorType"));
            for (OptionItem item : honorTypeComboBox.getItems()) {
                if (item.getValue().equals(honorType)) {
                    return new SimpleStringProperty(item.getTitle());
                }
            }
            return new SimpleStringProperty(honorType);
        });
        
        levelColumn.setCellValueFactory(cellData -> {
            String level = String.valueOf(cellData.getValue().get("level"));
            for (OptionItem item : levelComboBox.getItems()) {
                if (item.getValue().equals(level)) {
                    return new SimpleStringProperty(item.getTitle());
                }
            }
            return new SimpleStringProperty(level);
        });
        
        awardDateColumn.setCellValueFactory(cellData -> {
            Object value = cellData.getValue().get("awardDate");
            if (value != null && !value.toString().isEmpty()) {
                try {
                    LocalDate date = LocalDate.parse(value.toString(), dateFormatter);
                    return new SimpleStringProperty(date.format(dateFormatter));
                } catch (Exception e) {
                    return new SimpleStringProperty(value.toString());
                }
            }
            return new SimpleStringProperty("");
        });
        
        studentNameColumn.setCellValueFactory(cellData -> {
            Map<String, Object> student = (Map<String, Object>) cellData.getValue().get("student");
            if (student != null) {
                return new SimpleStringProperty(String.valueOf(student.get("name")));
            }
            return new SimpleStringProperty("");
        });
        
        studentNumColumn.setCellValueFactory(cellData -> {
            Map<String, Object> student = (Map<String, Object>) cellData.getValue().get("student");
            if (student != null) {
                return new SimpleStringProperty(String.valueOf(student.get("num")));
            }
            return new SimpleStringProperty("");
        });
        
        issuerColumn.setCellValueFactory(cellData -> new SimpleStringProperty(String.valueOf(cellData.getValue().get("issuer"))));
        
        // 绑定数据列表到表格
        dataTableView.setItems(dataList);
        
        // 表格选择事件
        dataTableView.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                displayHonorDetails(newSelection);
            }
        });
        
        // 表格样式
        dataTableView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        
        // 初始化下拉框
        initComboBoxes();
        
        // 加载数据
        loadData();
    }
    
    /**
     * 初始化下拉框
     */
    private void initComboBoxes() {
        // 荣誉类型下拉框
        List<OptionItem> honorTypes = HttpRequestUtil.getDictionaryOptionItemList("RYLX");
        
        // 如果从服务器获取的类型为空，添加一些默认值
        if (honorTypes == null || honorTypes.isEmpty()) {
            honorTypes = new ArrayList<>();
            honorTypes.add(new OptionItem(1, "1", "奖学金"));
            honorTypes.add(new OptionItem(2, "2", "学科竞赛"));
            honorTypes.add(new OptionItem(3, "3", "科研成果"));
            honorTypes.add(new OptionItem(4, "4", "社会工作"));
            honorTypes.add(new OptionItem(5, "5", "文体活动"));
            honorTypes.add(new OptionItem(6, "6", "荣誉称号"));
            honorTypes.add(new OptionItem(7, "7", "其他"));
        }
        
        honorTypeComboBox.setItems(FXCollections.observableArrayList(honorTypes));
        typeComboBox.setItems(FXCollections.observableArrayList(honorTypes));
        
        // 荣誉级别下拉框
        List<OptionItem> honorLevels = HttpRequestUtil.getDictionaryOptionItemList("RYJB");
        
        // 如果从服务器获取的级别为空，添加一些默认值
        if (honorLevels == null || honorLevels.isEmpty()) {
            honorLevels = new ArrayList<>();
            honorLevels.add(new OptionItem(1, "1", "国家级"));
            honorLevels.add(new OptionItem(2, "2", "省级"));
            honorLevels.add(new OptionItem(3, "3", "市级"));
            honorLevels.add(new OptionItem(4, "4", "校级"));
            honorLevels.add(new OptionItem(5, "5", "院级"));
            honorLevels.add(new OptionItem(6, "6", "班级"));
        }
        
        levelComboBox.setItems(FXCollections.observableArrayList(honorLevels));
        
        // 设置默认值
        if (!honorTypes.isEmpty()) {
            honorTypeComboBox.setValue(null); // 查询时默认不选择
            typeComboBox.setValue(honorTypes.get(0)); // 新建时默认第一个类型
        }
        
        if (!honorLevels.isEmpty()) {
            levelComboBox.setValue(honorLevels.get(0)); // 默认国家级
        }
    }
    
    /**
     * 加载荣誉数据
     */
    private void loadData() {
        DataRequest request = new DataRequest();
        
        String keyword = keywordTextField.getText();
        if (keyword != null && !keyword.isEmpty()) {
            request.add("keyword", keyword);
        }
        
        OptionItem selectedType = honorTypeComboBox.getValue();
        if (selectedType != null) {
            request.add("honorType", selectedType.getValue());
        }
        
        DataResponse response = HttpRequestUtil.request("/api/honor/list", request);
        if (response != null && response.getData() != null) {
            dataList.clear();
            List<Map<String, Object>> list = (List<Map<String, Object>>) response.getData();
            dataList.addAll(list);
        }
    }
    
    /**
     * 显示荣誉详情
     */
    private void displayHonorDetails(Map<String, Object> honor) {
        // 安全地处理ID
        currentHonorId = safeGetInteger(honor, "honorId");
        
        titleField.setText(String.valueOf(honor.get("title")));
        
        String honorType = String.valueOf(honor.get("honorType"));
        for (OptionItem item : typeComboBox.getItems()) {
            if (item.getValue().equals(honorType)) {
                typeComboBox.setValue(item);
                break;
            }
        }
        
        String level = String.valueOf(honor.get("level"));
        for (OptionItem item : levelComboBox.getItems()) {
            if (item.getValue().equals(level)) {
                levelComboBox.setValue(item);
                break;
            }
        }
        
        Object awardDateObj = honor.get("awardDate");
        if (awardDateObj != null && !awardDateObj.toString().isEmpty()) {
            try {
                LocalDate awardDate = LocalDate.parse(awardDateObj.toString(), dateFormatter);
                awardDatePicker.setValue(awardDate);
            } catch (Exception e) {
                awardDatePicker.setValue(null);
            }
        } else {
            awardDatePicker.setValue(null);
        }
        
        issuerField.setText(String.valueOf(honor.get("issuer")));
        certificateNumberField.setText(String.valueOf(honor.get("certificateNumber")));
        descriptionTextArea.setText(String.valueOf(honor.get("description")));
        
        // 处理学生信息
        Map<String, Object> student = (Map<String, Object>) honor.get("student");
        if (student != null) {
            selectedStudent = student;
            studentField.setText(student.get("name") + " (" + student.get("num") + ")");
        } else {
            selectedStudent = null;
            studentField.setText("");
        }
    }
    
    /**
     * 清空表单
     */
    private void clearForm() {
        currentHonorId = null;
        titleField.setText("");
        issuerField.setText("");
        certificateNumberField.setText("");
        descriptionTextArea.setText("");
        selectedStudent = null;
        studentField.setText("");
        
        // 重置日期选择器
        awardDatePicker.setValue(LocalDate.now());
        
        // 设置默认值
        if (!typeComboBox.getItems().isEmpty()) {
            typeComboBox.setValue(typeComboBox.getItems().get(0));
        }
        
        if (!levelComboBox.getItems().isEmpty()) {
            levelComboBox.setValue(levelComboBox.getItems().get(0));
        }
    }
    
    /**
     * 添加按钮点击事件
     */
    @FXML
    private void onAddButtonClick(ActionEvent event) {
        clearForm();
    }
    
    /**
     * 清空按钮点击事件
     */
    @FXML
    private void onClearButtonClick(ActionEvent event) {
        clearForm();
    }
    
    /**
     * 删除按钮点击事件
     */
    @FXML
    private void onDeleteButtonClick(ActionEvent event) {
        Map<String, Object> selectedHonor = dataTableView.getSelectionModel().getSelectedItem();
        if (selectedHonor == null) {
            MessageDialog.showDialog("请先选择一条荣誉记录");
            return;
        }
        
        // 安全地处理ID
        Integer honorId = safeGetInteger(selectedHonor, "honorId");
        
        if (honorId == null) {
            MessageDialog.showDialog("荣誉ID无效");
            return;
        }
        
        if (MessageDialog.choiceDialog("确定要删除该荣誉记录吗？") == MessageDialog.CHOICE_YES) {
            DataRequest request = new DataRequest();
            request.add("honorId", honorId);
            
            DataResponse response = HttpRequestUtil.request("/api/honor/delete", request);
            if (response != null && response.getCode() == 0) {
                MessageDialog.showDialog("删除成功");
                loadData();
                clearForm();
            } else {
                MessageDialog.showDialog("删除失败: " + (response != null ? response.getMsg() : "未知错误"));
            }
        }
    }
    
    /**
     * 查询按钮点击事件
     */
    @FXML
    private void onQueryButtonClick(ActionEvent event) {
        loadData();
    }
    
    /**
     * 保存按钮点击事件
     */
    @FXML
    private void onSaveButtonClick(ActionEvent event) {
        try {
            // 验证输入
            if (titleField.getText().isEmpty()) {
                MessageDialog.showDialog("荣誉称号不能为空");
                return;
            }
            
            if (typeComboBox.getValue() == null) {
                MessageDialog.showDialog("请选择荣誉类型");
                return;
            }
            
            if (levelComboBox.getValue() == null) {
                MessageDialog.showDialog("请选择荣誉级别");
                return;
            }
            
            if (awardDatePicker.getValue() == null) {
                MessageDialog.showDialog("请选择获奖日期");
                return;
            }
            
            if (selectedStudent == null) {
                MessageDialog.showDialog("请选择获奖学生");
                return;
            }
            
            // 构建表单数据
            Map<String, Object> form = new HashMap<>();
            form.put("title", titleField.getText());
            form.put("honorType", typeComboBox.getValue().getValue());
            form.put("level", levelComboBox.getValue().getValue());
            form.put("awardDate", awardDatePicker.getValue().format(dateFormatter));
            form.put("issuer", issuerField.getText());
            form.put("certificateNumber", certificateNumberField.getText());
            form.put("description", descriptionTextArea.getText());
            form.put("studentId", selectedStudent.get("personId"));
            
            // 发送请求
            DataRequest request = new DataRequest();
            if (currentHonorId != null) {
                request.add("honorId", currentHonorId);
            }
            request.add("form", form);
            
            System.out.println("发送荣誉保存请求: " + (currentHonorId != null ? "更新ID=" + currentHonorId : "新增"));
            DataResponse response = HttpRequestUtil.request("/api/honor/edit", request);
            
            if (response != null) {
                System.out.println("荣誉保存响应: code=" + response.getCode() + ", msg=" + response.getMsg() + ", data=" + (response.getData() != null ? response.getData() : "null"));
                
                if (response.getCode() == 0) {
                    MessageDialog.showDialog("保存成功");
                    
                    // 如果是新增，获取新的ID并更新currentHonorId
                    if (currentHonorId == null && response.getData() != null) {
                        currentHonorId = safeGetInteger(response.getData());
                        System.out.println("新荣誉ID: " + currentHonorId);
                    }
                    
                    // 刷新荣誉列表
                    loadData();
                    
                    // 使用当前表单数据刷新展示，无需再次从服务器获取
                    if (currentHonorId == null) {
                        clearForm(); // 如果保存的是新荣誉，清空表单
                    } else {
                        // 对于已有荣誉，保留当前编辑状态，无需重新加载
                        // 更新当前页面显示的数据
                        Map<String, Object> currentFormData = new HashMap<>();
                        currentFormData.put("honorId", currentHonorId);
                        currentFormData.put("title", titleField.getText());
                        currentFormData.put("honorType", typeComboBox.getValue().getValue());
                        currentFormData.put("level", levelComboBox.getValue().getValue());
                        currentFormData.put("awardDate", awardDatePicker.getValue().format(dateFormatter));
                        currentFormData.put("issuer", issuerField.getText());
                        currentFormData.put("certificateNumber", certificateNumberField.getText());
                        currentFormData.put("description", descriptionTextArea.getText());
                        currentFormData.put("student", selectedStudent);
                    }
                } else {
                    String errorMsg = response.getMsg();
                    if (errorMsg == null || errorMsg.isEmpty()) {
                        errorMsg = "服务器返回未知错误";
                    }
                    MessageDialog.showDialog("保存失败: " + errorMsg);
                }
            } else {
                System.out.println("荣誉保存失败: 服务器无响应");
                MessageDialog.showDialog("保存失败: 无法连接到服务器");
            }
        } catch (Exception e) {
            e.printStackTrace();
            MessageDialog.showDialog("保存时发生异常: " + e.getMessage());
        }
    }
    
    /**
     * 选择学生按钮点击事件
     */
    @FXML
    private void onSelectStudentButtonClick(ActionEvent event) {
        try {
            // 加载所有学生
            DataRequest request = new DataRequest();
            DataResponse response = HttpRequestUtil.request("/api/student/list", request);
            List<Map<String, Object>> studentsList = new ArrayList<>();
            
            if (response != null && response.getData() != null) {
                studentsList = (List<Map<String, Object>>) response.getData();
            }
            
            if (studentsList.isEmpty()) {
                MessageDialog.showDialog("未能加载学生列表");
                return;
            }
            
            // 创建学生选择对话框
            showStudentSelectionDialog(studentsList);
        } catch (Exception e) {
            e.printStackTrace();
            MessageDialog.showDialog("获取学生列表失败: " + e.getMessage());
        }
    }
    
    /**
     * 显示学生选择对话框
     */
    private void showStudentSelectionDialog(List<Map<String, Object>> students) {
        try {
            // 创建一个临时表格
            TableView<Map<String, Object>> tableView = new TableView<>();
            tableView.setPrefSize(500, 400);
            
            // 添加列
            TableColumn<Map<String, Object>, String> numCol = new TableColumn<>("学号");
            numCol.setCellValueFactory(cellData -> new SimpleStringProperty(String.valueOf(cellData.getValue().get("num"))));
            numCol.setPrefWidth(100);
            
            TableColumn<Map<String, Object>, String> nameCol = new TableColumn<>("姓名");
            nameCol.setCellValueFactory(cellData -> new SimpleStringProperty(String.valueOf(cellData.getValue().get("name"))));
            nameCol.setPrefWidth(100);
            
            TableColumn<Map<String, Object>, String> classCol = new TableColumn<>("班级");
            classCol.setCellValueFactory(cellData -> new SimpleStringProperty(String.valueOf(cellData.getValue().get("className"))));
            classCol.setPrefWidth(120);
            
            TableColumn<Map<String, Object>, String> deptCol = new TableColumn<>("院系");
            deptCol.setCellValueFactory(cellData -> new SimpleStringProperty(String.valueOf(cellData.getValue().get("dept"))));
            deptCol.setPrefWidth(120);
            
            tableView.getColumns().addAll(numCol, nameCol, classCol, deptCol);
            tableView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
            
            // 添加数据
            ObservableList<Map<String, Object>> studentList = FXCollections.observableArrayList(students);
            tableView.setItems(studentList);
            
            // 添加搜索功能
            TextField searchField = new TextField();
            searchField.setPromptText("输入学号或姓名搜索");
            searchField.setPrefWidth(250);
            
            Button searchButton = new Button("搜索");
            searchButton.setOnAction(e -> {
                String keyword = searchField.getText().toLowerCase();
                ObservableList<Map<String, Object>> filteredList = FXCollections.observableArrayList();
                
                for (Map<String, Object> student : students) {
                    String num = String.valueOf(student.get("num")).toLowerCase();
                    String name = String.valueOf(student.get("name")).toLowerCase();
                    
                    if (num.contains(keyword) || name.contains(keyword)) {
                        filteredList.add(student);
                    }
                }
                
                tableView.setItems(filteredList);
            });
            
            HBox searchBox = new HBox(10, new Label("搜索:"), searchField, searchButton);
            searchBox.setPadding(new Insets(10));
            searchBox.setAlignment(Pos.CENTER_LEFT);
            
            // 创建布局
            VBox vbox = new VBox(10);
            vbox.setPadding(new Insets(10));
            
            Label titleLabel = new Label("选择获奖学生");
            titleLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 14px;");
            
            HBox buttonBox = new HBox(10);
            buttonBox.setAlignment(Pos.CENTER);
            
            Button selectButton = new Button("选择");
            Button cancelButton = new Button("取消");
            
            buttonBox.getChildren().addAll(selectButton, cancelButton);
            vbox.getChildren().addAll(titleLabel, searchBox, tableView, buttonBox);
            
            // 创建场景和舞台
            Scene scene = new Scene(vbox);
            Stage stage = new Stage();
            stage.setTitle("选择学生");
            stage.setScene(scene);
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setResizable(false);
            
            // 设置按钮事件
            selectButton.setOnAction(e -> {
                Map<String, Object> selectedStudent = tableView.getSelectionModel().getSelectedItem();
                if (selectedStudent != null) {
                    this.selectedStudent = selectedStudent;
                    studentField.setText(selectedStudent.get("name") + " (" + selectedStudent.get("num") + ")");
                    stage.close();
                } else {
                    MessageDialog.showDialog("请选择一个学生");
                }
            });
            
            cancelButton.setOnAction(e -> stage.close());
            
            // 显示舞台
            stage.showAndWait();
        } catch (Exception e) {
            e.printStackTrace();
            MessageDialog.showDialog("显示学生选择对话框失败: " + e.getMessage());
        }
    }
    
    /**
     * 安全地从Map中获取Integer值
     */
    private Integer safeGetInteger(Map<String, Object> map, String key) {
        Object value = map.get(key);
        return safeGetInteger(value);
    }
    
    /**
     * 安全地将对象转换为Integer
     */
    private Integer safeGetInteger(Object value) {
        if (value == null) {
            return null;
        }
        
        if (value instanceof Integer) {
            return (Integer) value;
        } else if (value instanceof Double) {
            return ((Double) value).intValue();
        } else if (value instanceof Number) {
            return ((Number) value).intValue();
        } else {
            try {
                return Integer.parseInt(value.toString());
            } catch (NumberFormatException e) {
                System.out.println("无法转换为Integer: " + value + ", 类型: " + value.getClass().getName());
                return null;
            }
        }
    }
} 