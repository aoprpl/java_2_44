package com.teach.javafx.controller;

import com.teach.javafx.controller.base.MessageDialog;
import com.teach.javafx.request.DataRequest;
import com.teach.javafx.request.DataResponse;
import com.teach.javafx.request.HttpRequestUtil;
import com.teach.javafx.request.OptionItem;
import com.teach.javafx.util.CommonMethod;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StudentEditController {
    @FXML
    private TextField numField;
    @FXML
    private TextField nameField;
    @FXML
    private TextField deptField;
    @FXML
    private TextField majorField;
    @FXML
    private TextField classNameField;
    @FXML
    private TextField cardField;
    @FXML
    private ComboBox<OptionItem> genderComboBox;
    @FXML
    private DatePicker birthdayPicker;
    @FXML
    private TextField emailField;
    @FXML
    private TextField phoneField;
    @FXML
    private TextField addressField;

    private StudentController studentController;
    private Integer personId;
    private List<OptionItem> genderList;
    private final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    @FXML
    public void initialize() {
        initGenderComboBox();
    }

    /**
     * 初始化性别下拉框
     */
    private void initGenderComboBox() {
        // 性别选项
        genderList = new ArrayList<>();
        genderList.add(new OptionItem(1, "1", "男"));
        genderList.add(new OptionItem(2, "2", "女"));
        genderComboBox.getItems().setAll(genderList);
        genderComboBox.setValue(genderList.get(0)); // 默认选择男性
    }

    /**
     * 设置学生控制器，用于数据回传
     */
    public void setStudentController(StudentController studentController) {
        this.studentController = studentController;
    }

    /**
     * 设置要编辑的学生数据
     */
    public void setStudentData(Map<String, Object> studentData) {
        if (studentData != null) {
            personId = CommonMethod.getInteger(studentData, "personId");
            numField.setText(CommonMethod.getString(studentData, "num"));
            nameField.setText(CommonMethod.getString(studentData, "name"));
            deptField.setText(CommonMethod.getString(studentData, "dept"));
            majorField.setText(CommonMethod.getString(studentData, "major"));
            classNameField.setText(CommonMethod.getString(studentData, "className"));
            cardField.setText(CommonMethod.getString(studentData, "card"));
            
            // 设置性别
            String gender = CommonMethod.getString(studentData, "gender");
            if (gender.isEmpty()) {
                gender = "1";  // 默认性别为男
            }
            for (OptionItem item : genderList) {
                if (item.getValue().equals(gender)) {
                    genderComboBox.setValue(item);
                    break;
                }
            }
            
            // 设置出生日期
            String birthday = CommonMethod.getString(studentData, "birthday");
            if (!birthday.isEmpty()) {
                try {
                    LocalDate date = LocalDate.parse(birthday, dateFormatter);
                    birthdayPicker.setValue(date);
                } catch (Exception e) {
                    birthdayPicker.setValue(null);
                }
            }
            
            emailField.setText(CommonMethod.getString(studentData, "email"));
            phoneField.setText(CommonMethod.getString(studentData, "phone"));
            addressField.setText(CommonMethod.getString(studentData, "address"));
        } else {
            personId = null;
            numField.setText("");
            nameField.setText("");
            deptField.setText("");
            majorField.setText("");
            classNameField.setText("");
            cardField.setText("");
            genderComboBox.setValue(genderList.get(0));
            birthdayPicker.setValue(null);
            emailField.setText("");
            phoneField.setText("");
            addressField.setText("");
        }
    }

    /**
     * 保存按钮点击事件
     */
    @FXML
    private void onSaveButtonClick() {
        // 表单验证
        if (numField.getText().trim().isEmpty()) {
            MessageDialog.showDialog("学号不能为空");
            return;
        }
        
        if (nameField.getText().trim().isEmpty()) {
            MessageDialog.showDialog("姓名不能为空");
            return;
        }
        
        // 构建表单数据
        Map<String, Object> form = new HashMap<>();
        form.put("num", numField.getText().trim());
        form.put("name", nameField.getText().trim());
        form.put("dept", deptField.getText().trim());
        form.put("major", majorField.getText().trim());
        form.put("className", classNameField.getText().trim());
        form.put("card", cardField.getText().trim());
        
        OptionItem selectedGender = genderComboBox.getValue();
        if (selectedGender != null) {
            form.put("gender", selectedGender.getValue());
        }
        
        if (birthdayPicker.getValue() != null) {
            form.put("birthday", birthdayPicker.getValue().format(dateFormatter));
        }
        
        form.put("email", emailField.getText().trim());
        form.put("phone", phoneField.getText().trim());
        form.put("address", addressField.getText().trim());
        
        // 构建请求
        DataRequest request = new DataRequest();
        request.add("personId", personId);
        request.add("form", form);
        
        // 发送请求
        DataResponse response = HttpRequestUtil.request("/api/student/studentEditSave", request);
        
        if (response != null && response.getCode() == 0) {
            MessageDialog.showDialog("保存成功");
            
            // 构建更新后的学生数据
            Map<String, Object> updatedStudent = new HashMap<>();
            updatedStudent.put("personId", personId != null ? personId : response.getData());
            updatedStudent.put("num", numField.getText().trim());
            updatedStudent.put("name", nameField.getText().trim());
            updatedStudent.put("dept", deptField.getText().trim());
            updatedStudent.put("major", majorField.getText().trim());
            updatedStudent.put("className", classNameField.getText().trim());
            updatedStudent.put("card", cardField.getText().trim());
            
            if (selectedGender != null) {
                updatedStudent.put("gender", selectedGender.getValue());
                updatedStudent.put("genderName", selectedGender.getTitle());
            }
            
            if (birthdayPicker.getValue() != null) {
                updatedStudent.put("birthday", birthdayPicker.getValue().format(dateFormatter));
            }
            
            updatedStudent.put("email", emailField.getText().trim());
            updatedStudent.put("phone", phoneField.getText().trim());
            updatedStudent.put("address", addressField.getText().trim());
            
            // 回传数据给学生控制器
            if (studentController != null) {
                studentController.updateStudentData(updatedStudent);
            }
            
            // 关闭窗口
            Stage stage = (Stage) numField.getScene().getWindow();
            stage.close();
        } else {
            MessageDialog.showDialog("保存失败: " + (response != null ? response.getMsg() : "未知错误"));
        }
    }

    /**
     * 取消按钮点击事件
     */
    @FXML
    private void onCancelButtonClick() {
        Stage stage = (Stage) numField.getScene().getWindow();
        stage.close();
    }
} 