package com.teach.javafx.controller;

import com.teach.javafx.controller.base.MessageDialog;
import com.teach.javafx.controller.base.StudentSelectDialog;
import com.teach.javafx.request.DataRequest;
import com.teach.javafx.request.DataResponse;
import com.teach.javafx.request.HttpRequestUtil;
import com.teach.javafx.request.OptionItem;
import com.teach.javafx.util.CommonMethod;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class SocialPracticeEditController {
    @FXML
    private ComboBox<OptionItem> studentComboBox;
    @FXML
    private TextField titleField;
    @FXML
    private ComboBox<OptionItem> practiceTypeComboBox;
    @FXML
    private ComboBox<OptionItem> levelComboBox;
    @FXML
    private DatePicker startDatePicker;
    @FXML
    private DatePicker endDatePicker;
    @FXML
    private TextField organizationField;
    @FXML
    private TextField certificateNumberField;
    @FXML
    private TextArea descriptionArea;

    private SocialPracticeController socialPracticeController;
    private Integer practiceId;
    private List<OptionItem> studentList;
    private List<OptionItem> practiceTypeList;
    private List<OptionItem> levelList;
    private final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private Stage dialogStage;
    private Map<String, Object> resultData = null;

    @FXML
    public void initialize() {
        initComboBoxes();
    }

    private void initComboBoxes() {
        // 获取学生列表
        DataRequest req = new DataRequest();
        List<OptionItem> studentItems = HttpRequestUtil.requestOptionItemList("/api/social-practice/getStudentItemOptionList", req);
        if (studentItems != null) {
            studentList = studentItems;
            // 添加"请选择"选项
            OptionItem defaultItem = new OptionItem(null, "0", "请选择");
            studentComboBox.getItems().add(defaultItem);
            studentComboBox.getItems().addAll(studentList);
            studentComboBox.setValue(defaultItem);
        }

        // 初始化实践类型
        practiceTypeList = new ArrayList<>();
        practiceTypeList.add(new OptionItem(1, "shehuidiaoyan", "社会调研"));
        practiceTypeList.add(new OptionItem(2, "zhiyuanfuwu", "志愿服务"));
        practiceTypeList.add(new OptionItem(3, "shixishijian", "实习实践"));
        practiceTypeList.add(new OptionItem(4, "qita", "其他"));
        practiceTypeComboBox.getItems().setAll(practiceTypeList);

        // 初始化实践级别
        levelList = new ArrayList<>();
        levelList.add(new OptionItem(1, "guojiaji", "国家级"));
        levelList.add(new OptionItem(2, "shengji", "省级"));
        levelList.add(new OptionItem(3, "shiji", "市级"));
        levelList.add(new OptionItem(4, "xiaoji", "校级"));
        levelList.add(new OptionItem(5, "yuanji", "院级"));
        levelList.add(new OptionItem(6, "banji", "班级"));
        levelComboBox.getItems().setAll(levelList);

        // 设置默认值
        if (!practiceTypeList.isEmpty()) {
            practiceTypeComboBox.setValue(practiceTypeList.get(0));
        }
        if (!levelList.isEmpty()) {
            levelComboBox.setValue(levelList.get(0));
        }
        startDatePicker.setValue(LocalDate.now());
        endDatePicker.setValue(LocalDate.now());
    }

    public void setSocialPracticeController(SocialPracticeController controller) {
        this.socialPracticeController = controller;
    }

    public void showDialog(Map<String, Object> data) {
        if (data == null) {
            // 新增模式
            practiceId = null;
            clearForm();
        } else {
            // 编辑模式
            practiceId = CommonMethod.getInteger(data, "practiceId");
            titleField.setText(CommonMethod.getString(data, "title"));
            
            // 设置学生
            Map<String, Object> student = (Map<String, Object>) data.get("student");
            if (student != null) {
                String personId = String.valueOf(student.get("personId"));
                for (OptionItem item : studentList) {
                    if (personId.equals(item.getValue())) {
                        studentComboBox.setValue(item);
                        break;
                    }
                }
                studentComboBox.setDisable(true); // 编辑模式下不允许更改学生
            } else {
                // 如果没有学生信息，设置为"请选择"
                studentComboBox.setValue(studentComboBox.getItems().get(0));
                studentComboBox.setDisable(false);
            }

            // 设置实践类型
            String practiceType = CommonMethod.getString(data, "practiceType");
            for (OptionItem item : practiceTypeList) {
                if (item.getValue().equals(practiceType)) {
                    practiceTypeComboBox.setValue(item);
                    break;
                }
            }

            // 设置实践级别
            String level = CommonMethod.getString(data, "level");
            for (OptionItem item : levelList) {
                if (item.getValue().equals(level)) {
                    levelComboBox.setValue(item);
                    break;
                }
            }

            // 设置日期
            String startDate = CommonMethod.getString(data, "startDate");
            if (startDate != null && !startDate.isEmpty()) {
                startDatePicker.setValue(LocalDate.parse(startDate));
            }
            String endDate = CommonMethod.getString(data, "endDate");
            if (endDate != null && !endDate.isEmpty()) {
                endDatePicker.setValue(LocalDate.parse(endDate));
            }

            organizationField.setText(CommonMethod.getString(data, "organization"));
            certificateNumberField.setText(CommonMethod.getString(data, "certificateNumber"));
            descriptionArea.setText(CommonMethod.getString(data, "description"));
        }
    }

    private void clearForm() {
        titleField.clear();
        studentComboBox.setValue(studentComboBox.getItems().get(0));
        studentComboBox.setDisable(false);
        if (!practiceTypeList.isEmpty()) {
            practiceTypeComboBox.setValue(practiceTypeList.get(0));
        }
        if (!levelList.isEmpty()) {
            levelComboBox.setValue(levelList.get(0));
        }
        startDatePicker.setValue(LocalDate.now());
        endDatePicker.setValue(LocalDate.now());
        organizationField.clear();
        certificateNumberField.clear();
        descriptionArea.clear();
    }

    public void setDialogStage(Stage stage) {
        this.dialogStage = stage;
    }

    public Map<String, Object> getResultData() {
        return resultData;
    }

    @FXML
    private void onSaveButtonClick() {
        OptionItem selectedStudent = studentComboBox.getValue();
        if (selectedStudent == null || selectedStudent.getValue().equals("0")) {
            MessageDialog.showDialog("请选择学生");
            return;
        }
        if (titleField.getText().trim().isEmpty()) {
            MessageDialog.showDialog("请输入实践名称");
            return;
        }
        if (practiceTypeComboBox.getValue() == null) {
            MessageDialog.showDialog("请选择实践类型");
            return;
        }
        if (levelComboBox.getValue() == null) {
            MessageDialog.showDialog("请选择实践级别");
            return;
        }
        if (startDatePicker.getValue() == null) {
            MessageDialog.showDialog("请选择开始时间");
            return;
        }
        if (endDatePicker.getValue() == null) {
            MessageDialog.showDialog("请选择结束时间");
            return;
        }
        if (endDatePicker.getValue().isBefore(startDatePicker.getValue())) {
            MessageDialog.showDialog("结束时间不能早于开始时间");
            return;
        }
        try {
            Map<String, Object> data = new HashMap<>();
            data.put("studentId", Integer.parseInt(selectedStudent.getValue()));
            data.put("practiceId", practiceId);
            data.put("title", titleField.getText().trim());
            data.put("practiceType", practiceTypeComboBox.getValue().getTitle());
            data.put("level", levelComboBox.getValue().getTitle());
            data.put("startDate", startDatePicker.getValue().format(dateFormatter));
            data.put("endDate", endDatePicker.getValue().format(dateFormatter));
            data.put("organization", organizationField.getText());
            data.put("certificateNumber", certificateNumberField.getText());
            data.put("description", descriptionArea.getText());
            resultData = data;
            if (dialogStage != null) {
                dialogStage.close();
            } else if (studentComboBox.getScene() != null) {
                studentComboBox.getScene().getWindow().hide();
            }
        } catch (Exception e) {
            e.printStackTrace();
            MessageDialog.showDialog("保存数据时发生错误: " + e.getMessage());
        }
    }

    @FXML
    private void onCancelButtonClick() {
        resultData = null;
        if (dialogStage != null) {
            dialogStage.close();
        } else if (studentComboBox.getScene() != null) {
            studentComboBox.getScene().getWindow().hide();
        }
    }

    @FXML
    private void onSelectStudentButtonClick() {
        Map<String, Object> selectedStudent = StudentSelectDialog.showDialog();
        if (selectedStudent != null) {
            // 在学生列表中查找并选择对应的学生
            for (OptionItem item : studentList) {
                if (item.getValue().equals(selectedStudent.get("personId").toString())) {
                    studentComboBox.setValue(item);
                    break;
                }
            }
        }
    }
}
