package com.teach.javafx.controller;

import com.teach.javafx.controller.base.MessageDialog;
import com.teach.javafx.request.DataRequest;
import com.teach.javafx.request.DataResponse;
import com.teach.javafx.request.HttpRequestUtil;
import com.teach.javafx.request.OptionItem;
import com.teach.javafx.util.CommonMethod;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ActivityEditController {
    @FXML
    private TextField nameField;
    @FXML
    private ComboBox<OptionItem> activityTypeComboBox;
    @FXML
    private DatePicker startDatePicker;
    @FXML
    private TextField startTimeField;
    @FXML
    private DatePicker endDatePicker;
    @FXML
    private TextField endTimeField;
    @FXML
    private TextField locationField;
    @FXML
    private TextField organizerField;
    @FXML
    private ComboBox<OptionItem> statusComboBox;
    @FXML
    private TextField maxParticipantsField;
    @FXML
    private TextArea descriptionArea;

    private ActivityController activityController;
    private Integer activityId;
    private List<OptionItem> activityTypeList;
    private List<OptionItem> statusList;
    private final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private final DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");
    private final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    @FXML
    public void initialize() {
        initComboBoxes();
    }

    private void initComboBoxes() {
        // 初始化活动类型
        activityTypeList = new ArrayList<>();
        activityTypeList.add(new OptionItem(1, "1", "学术讲座"));
        activityTypeList.add(new OptionItem(2, "2", "文体活动"));
        activityTypeList.add(new OptionItem(3, "3", "社会实践"));
        activityTypeList.add(new OptionItem(4, "4", "志愿服务"));
        activityTypeList.add(new OptionItem(5, "5", "创新创业"));
        activityTypeList.add(new OptionItem(6, "6", "其他"));
        activityTypeComboBox.getItems().addAll(activityTypeList);

        // 初始化活动状态
        statusList = new ArrayList<>();
        statusList.add(new OptionItem(1, "1", "筹备中"));
        statusList.add(new OptionItem(2, "2", "报名中"));
        statusList.add(new OptionItem(3, "3", "进行中"));
        statusList.add(new OptionItem(4, "4", "已结束"));
        statusList.add(new OptionItem(5, "5", "已取消"));
        statusComboBox.getItems().addAll(statusList);

        // 设置默认值
        if (!activityTypeList.isEmpty()) {
            activityTypeComboBox.setValue(activityTypeList.get(0));
        }
        if (!statusList.isEmpty()) {
            statusComboBox.setValue(statusList.get(0));
        }
        
        startDatePicker.setValue(LocalDate.now());
        endDatePicker.setValue(LocalDate.now().plusDays(1));
        
        startTimeField.setText("09:00");
        endTimeField.setText("18:00");
    }

    public void setActivityController(ActivityController activityController) {
        this.activityController = activityController;
    }

    public void showDialog(Map<String, Object> data) {
        if (data == null) {
            // 新增模式
            activityId = null;
            clearForm();
        } else {
            // 编辑模式
            activityId = CommonMethod.getInteger(data, "activityId");
            nameField.setText(CommonMethod.getString(data, "name"));
            
            // 设置活动类型
            String activityType = CommonMethod.getString(data, "activityType");
            for (OptionItem item : activityTypeList) {
                if (item.getValue().equals(activityType)) {
                    activityTypeComboBox.setValue(item);
                    break;
                }
            }

            // 设置开始时间
            String startTime = CommonMethod.getString(data, "startTime");
            if (startTime != null && !startTime.isEmpty()) {
                try {
                    LocalDateTime dateTime = LocalDateTime.parse(startTime, dateTimeFormatter);
                    startDatePicker.setValue(dateTime.toLocalDate());
                    startTimeField.setText(dateTime.format(timeFormatter));
                } catch (Exception e) {
                    startDatePicker.setValue(LocalDate.now());
                    startTimeField.setText("09:00");
                }
            }

            // 设置结束时间
            String endTime = CommonMethod.getString(data, "endTime");
            if (endTime != null && !endTime.isEmpty()) {
                try {
                    LocalDateTime dateTime = LocalDateTime.parse(endTime, dateTimeFormatter);
                    endDatePicker.setValue(dateTime.toLocalDate());
                    endTimeField.setText(dateTime.format(timeFormatter));
                } catch (Exception e) {
                    endDatePicker.setValue(LocalDate.now().plusDays(1));
                    endTimeField.setText("18:00");
                }
            }

            locationField.setText(CommonMethod.getString(data, "location"));
            organizerField.setText(CommonMethod.getString(data, "organizer"));
            
            // 设置活动状态
            String status = CommonMethod.getString(data, "status");
            for (OptionItem item : statusList) {
                if (item.getValue().equals(status)) {
                    statusComboBox.setValue(item);
                    break;
                }
            }
            
            // 设置最大参与人数
            Integer maxParticipants = CommonMethod.getInteger(data, "maxParticipants");
            maxParticipantsField.setText(maxParticipants != null ? maxParticipants.toString() : "");
            
            descriptionArea.setText(CommonMethod.getString(data, "description"));
        }
    }

    private void clearForm() {
        nameField.clear();
        if (!activityTypeList.isEmpty()) {
            activityTypeComboBox.setValue(activityTypeList.get(0));
        }
        startDatePicker.setValue(LocalDate.now());
        startTimeField.setText("09:00");
        endDatePicker.setValue(LocalDate.now().plusDays(1));
        endTimeField.setText("18:00");
        locationField.clear();
        organizerField.clear();
        if (!statusList.isEmpty()) {
            statusComboBox.setValue(statusList.get(0));
        }
        maxParticipantsField.setText("");
        descriptionArea.clear();
    }

    @FXML
    private void onSaveButtonClick() {
        // 验证表单
        if (nameField.getText().trim().isEmpty()) {
            MessageDialog.showDialog("请输入活动名称");
            return;
        }
        if (activityTypeComboBox.getValue() == null) {
            MessageDialog.showDialog("请选择活动类型");
            return;
        }
        if (startDatePicker.getValue() == null) {
            MessageDialog.showDialog("请选择开始日期");
            return;
        }
        if (!isValidTimeFormat(startTimeField.getText())) {
            MessageDialog.showDialog("开始时间格式无效，请使用HH:mm格式");
            return;
        }
        if (endDatePicker.getValue() == null) {
            MessageDialog.showDialog("请选择结束日期");
            return;
        }
        if (!isValidTimeFormat(endTimeField.getText())) {
            MessageDialog.showDialog("结束时间格式无效，请使用HH:mm格式");
            return;
        }
        
        // 检查结束时间是否晚于开始时间
        LocalDateTime startDateTime = LocalDateTime.of(
            startDatePicker.getValue(), 
            parseTime(startTimeField.getText())
        );
        LocalDateTime endDateTime = LocalDateTime.of(
            endDatePicker.getValue(), 
            parseTime(endTimeField.getText())
        );
        
        if (endDateTime.isBefore(startDateTime)) {
            MessageDialog.showDialog("结束时间必须晚于开始时间");
            return;
        }
        
        // 验证最大参与人数是否为有效数字
        Integer maxParticipants = null;
        if (!maxParticipantsField.getText().trim().isEmpty()) {
            try {
                maxParticipants = Integer.parseInt(maxParticipantsField.getText().trim());
                if (maxParticipants < 0) {
                    MessageDialog.showDialog("最大参与人数不能为负数");
                    return;
                }
            } catch (NumberFormatException e) {
                MessageDialog.showDialog("最大参与人数必须是有效数字");
                return;
            }
        }

        try {
            // 构建保存数据
            Map<String, Object> data = new HashMap<>();
            data.put("activityId", activityId);
            data.put("name", nameField.getText().trim());
            data.put("activityType", activityTypeComboBox.getValue().getValue());
            
            // 格式化日期时间确保yyyy-MM-dd HH:mm:ss格式
            LocalDateTime startDT = LocalDateTime.of(
                startDatePicker.getValue(),
                parseTime(startTimeField.getText())
            );
            LocalDateTime endDT = LocalDateTime.of(
                endDatePicker.getValue(),
                parseTime(endTimeField.getText())
            );
            
            data.put("startTime", startDT.format(dateTimeFormatter));
            data.put("endTime", endDT.format(dateTimeFormatter));
            data.put("location", locationField.getText());
            data.put("organizer", organizerField.getText());
            data.put("status", statusComboBox.getValue().getValue());
            
            // 处理最大参与人数
            if (maxParticipants != null) {
                data.put("maxParticipants", maxParticipants);
            } else {
                data.put("maxParticipants", 0);
            }
            
            data.put("description", descriptionArea.getText());
            
            // 打印请求数据，用于调试
            System.out.println("保存活动数据: " + data);
            
            activityController.doClose("ok", data);
        } catch (Exception e) {
            e.printStackTrace();
            MessageDialog.showDialog("保存数据时发生错误: " + e.getMessage());
        }
    }

    @FXML
    private void onCancelButtonClick() {
        activityController.doClose("cancel", null);
    }
    
    /**
     * 验证时间格式是否有效 (HH:mm)
     */
    private boolean isValidTimeFormat(String timeStr) {
        if (timeStr == null || timeStr.trim().isEmpty()) {
            return false;
        }
        try {
            LocalTime.parse(timeStr, timeFormatter);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * 解析时间字符串为LocalTime对象
     */
    private LocalTime parseTime(String timeStr) {
        try {
            return LocalTime.parse(timeStr, timeFormatter);
        } catch (Exception e) {
            return LocalTime.of(0, 0); // 默认返回00:00
        }
    }
} 