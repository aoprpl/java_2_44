package com.teach.javafx.controller;

import com.teach.javafx.MainApplication;
import com.teach.javafx.controller.base.MessageDialog;
import com.teach.javafx.request.DataRequest;
import com.teach.javafx.request.DataResponse;
import com.teach.javafx.request.HttpRequestUtil;
import com.teach.javafx.request.OptionItem;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.layout.GridPane;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 学生活动管理控制器
 */
public class ActivityController {
    // 活动搜索和列表显示相关组件
    @FXML
    private TextField keywordTextField;
    
    @FXML
    private ComboBox<OptionItem> activityTypeComboBox;
    
    @FXML
    private TableView<Map<String, Object>> dataTableView;
    
    @FXML
    private TableColumn<Map<String, Object>, String> nameColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> typeColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> startTimeColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> endTimeColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> locationColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> organizerColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> statusColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> participantsCountColumn;
    
    // 活动详情编辑相关组件
    @FXML
    private TextField nameField;
    
    @FXML
    private ComboBox<OptionItem> typeComboBox;
    
    @FXML
    private DatePicker startTimePicker;
    
    @FXML
    private DatePicker endTimePicker;
    
    @FXML
    private TextField startTimeField;
    
    @FXML
    private TextField endTimeField;
    
    @FXML
    private TextField locationField;
    
    @FXML
    private TextField organizerField;
    
    @FXML
    private ComboBox<OptionItem> statusComboBox;
    
    @FXML
    private TextField maxParticipantsField;
    
    @FXML
    private TextArea descriptionTextArea;
    
    // 学生参与者管理相关组件
    @FXML
    private TextField studentSearchField;
    
    @FXML
    private TableView<Map<String, Object>> participantsTableView;
    
    @FXML
    private TableColumn<Map<String, Object>, String> studentNumColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> studentNameColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> studentClassColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> studentDeptColumn;
    
    // 新增列：学生参与状态和加入时间
    @FXML
    private TableColumn<Map<String, Object>, String> studentStatusColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> joinTimeColumn;
    
    // 数据列表
    private ObservableList<Map<String, Object>> dataList = FXCollections.observableArrayList();
    private ObservableList<Map<String, Object>> participantsList = FXCollections.observableArrayList();
    private List<Map<String, Object>> availableStudentsList = new ArrayList<>();
    
    private Integer currentActivityId = null;
    
    private final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private final DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");
    
    private ActivityEditController activityEditController = null;
    private Stage editStage = null;
    
    /**
     * 初始化方法，JavaFX初始化时自动调用
     */
    @FXML
    private void initialize() {
        // 初始化活动表格列
        nameColumn.setCellValueFactory(cellData -> {
            Object value = cellData.getValue().get("name");
            return new SimpleStringProperty(value != null ? value.toString() : "");
        });
        
        typeColumn.setCellValueFactory(cellData -> {
            String activityType = String.valueOf(cellData.getValue().get("activityType"));
            if (activityType != null && !activityType.equals("null")) {
                for (OptionItem item : activityTypeComboBox.getItems()) {
                    if (item.getValue().equals(activityType)) {
                        return new SimpleStringProperty(item.getTitle());
                    }
                }
            }
            return new SimpleStringProperty("");
        });
        
        startTimeColumn.setCellValueFactory(cellData -> {
            Object value = cellData.getValue().get("startTime");
            if (value != null && !value.toString().isEmpty() && !"null".equals(value.toString())) {
                try {
                    LocalDateTime dateTime = LocalDateTime.parse(value.toString(), dateTimeFormatter);
                    return new SimpleStringProperty(dateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")));
                } catch (Exception e) {
                    return new SimpleStringProperty(value.toString());
                }
            }
            return new SimpleStringProperty("");
        });
        
        endTimeColumn.setCellValueFactory(cellData -> {
            Object value = cellData.getValue().get("endTime");
            if (value != null && !value.toString().isEmpty() && !"null".equals(value.toString())) {
                try {
                    LocalDateTime dateTime = LocalDateTime.parse(value.toString(), dateTimeFormatter);
                    return new SimpleStringProperty(dateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")));
                } catch (Exception e) {
                    return new SimpleStringProperty(value.toString());
                }
            }
            return new SimpleStringProperty("");
        });
        
        locationColumn.setCellValueFactory(cellData -> {
            Object value = cellData.getValue().get("location");
            return new SimpleStringProperty(value != null && !"null".equals(value.toString()) ? value.toString() : "");
        });
        
        organizerColumn.setCellValueFactory(cellData -> {
            Object value = cellData.getValue().get("organizer");
            return new SimpleStringProperty(value != null && !"null".equals(value.toString()) ? value.toString() : "");
        });
        
        statusColumn.setCellValueFactory(cellData -> {
            String statusCode = String.valueOf(cellData.getValue().get("status"));
            if (statusCode != null && !statusCode.equals("null")) {
                for (OptionItem item : statusComboBox.getItems()) {
                    if (item.getValue().equals(statusCode)) {
                        return new SimpleStringProperty(item.getTitle());
                    }
                }
            }
            return new SimpleStringProperty("");
        });
        
        participantsCountColumn.setCellValueFactory(cellData -> {
            List<Map<String, Object>> participants = (List<Map<String, Object>>) cellData.getValue().get("participants");
            int count = (participants != null) ? participants.size() : 0;
            return new SimpleStringProperty(String.valueOf(count));
        });
        
        // 初始化参与者表格列
        studentNumColumn.setCellValueFactory(cellData -> new SimpleStringProperty(String.valueOf(cellData.getValue().get("num"))));
        studentNameColumn.setCellValueFactory(cellData -> new SimpleStringProperty(String.valueOf(cellData.getValue().get("name"))));
        studentClassColumn.setCellValueFactory(cellData -> new SimpleStringProperty(String.valueOf(cellData.getValue().get("className"))));
        studentDeptColumn.setCellValueFactory(cellData -> new SimpleStringProperty(String.valueOf(cellData.getValue().get("dept"))));
        
        // 初始化新增的学生参与状态和加入时间列
        studentStatusColumn.setCellValueFactory(cellData -> {
            String status = String.valueOf(cellData.getValue().get("participationStatus"));
            // 根据状态代码返回友好的文本描述
            switch (status) {
                case "1":
                    return new SimpleStringProperty("已报名");
                case "2":
                    return new SimpleStringProperty("已参加");
                case "3":
                    return new SimpleStringProperty("已完成");
                case "0":
                    return new SimpleStringProperty("已取消");
                default:
                    return new SimpleStringProperty("未知");
            }
        });
        
        joinTimeColumn.setCellValueFactory(cellData -> {
            Object value = cellData.getValue().get("joinTime");
            if (value != null && !value.toString().isEmpty()) {
                try {
                    LocalDateTime dateTime = LocalDateTime.parse(value.toString(), dateTimeFormatter);
                    return new SimpleStringProperty(dateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")));
                } catch (Exception e) {
                    return new SimpleStringProperty(value.toString());
                }
            }
            return new SimpleStringProperty("");
        });
        
        // 为学生表格行添加样式类，根据参与状态设置不同的背景颜色
        participantsTableView.setRowFactory(tv -> {
            TableRow<Map<String, Object>> row = new TableRow<>();
            row.itemProperty().addListener((obs, oldItem, newItem) -> {
                if (newItem != null) {
                    String status = String.valueOf(newItem.get("participationStatus"));
                    // 清除所有状态样式
                    row.getStyleClass().removeAll("student-active", "student-inactive", "student-pending");
                    
                    // 根据状态添加对应的样式类
                    if ("2".equals(status) || "3".equals(status)) {
                        row.getStyleClass().add("student-active");
                    } else if ("0".equals(status)) {
                        row.getStyleClass().add("student-inactive");
                    } else if ("1".equals(status)) {
                        row.getStyleClass().add("student-pending");
                    }
                }
            });
            return row;
        });
        
        // 绑定数据列表到表格
        dataTableView.setItems(dataList);
        participantsTableView.setItems(participantsList);
        
        // 表格行点击事件
        dataTableView.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                displayActivityDetails(newSelection);
            }
        });
        
        // 表格样式
        dataTableView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        participantsTableView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        
        // 初始化时间输入字段
        startTimeField.setText("08:00");
        endTimeField.setText("18:00");
        
        // 初始化下拉框
        initComboBoxes();
        
        // 加载数据
        loadData();
        
        // 加载可用学生
        loadAllStudents();

        // 添加调试输出每行数据的内容
        dataTableView.setRowFactory(tv -> {
            TableRow<Map<String, Object>> row = new TableRow<Map<String, Object>>() {
                @Override
                protected void updateItem(Map<String, Object> item, boolean empty) {
                    super.updateItem(item, empty);
                    if (item != null) {
                        System.out.println("行数据: " + item);
                    }
                }
            };
            return row;
        });
    }
    
    /**
     * 初始化下拉框
     */
    private void initComboBoxes() {
        // 活动类型下拉框
        List<OptionItem> activityTypes = HttpRequestUtil.getDictionaryOptionItemList("HDLX");
        
        // 如果从服务器获取的类型为空，添加一些默认值
        if (activityTypes == null || activityTypes.isEmpty()) {
            activityTypes = new ArrayList<>();
            activityTypes.add(new OptionItem(1, "1", "讲座"));
            activityTypes.add(new OptionItem(2, "2", "比赛"));
            activityTypes.add(new OptionItem(3, "3", "文艺演出"));
            activityTypes.add(new OptionItem(4, "4", "社团活动"));
            activityTypes.add(new OptionItem(5, "5", "义工服务"));
            activityTypes.add(new OptionItem(6, "6", "体育赛事"));
            activityTypes.add(new OptionItem(7, "7", "学术交流"));
            activityTypes.add(new OptionItem(8, "8", "其他"));
        }
        
        activityTypeComboBox.setItems(FXCollections.observableArrayList(activityTypes));
        typeComboBox.setItems(FXCollections.observableArrayList(activityTypes));
        
        // 状态下拉框
        List<OptionItem> statusTypes = HttpRequestUtil.getDictionaryOptionItemList("HDZT");
        
        // 如果从服务器获取的状态为空，添加一些默认值
        if (statusTypes == null || statusTypes.isEmpty()) {
            statusTypes = new ArrayList<>();
            statusTypes.add(new OptionItem(1, "1", "未开始"));
            statusTypes.add(new OptionItem(2, "2", "进行中"));
            statusTypes.add(new OptionItem(3, "3", "已结束"));
            statusTypes.add(new OptionItem(4, "4", "已取消"));
        }
        
        statusComboBox.setItems(FXCollections.observableArrayList(statusTypes));
        
        // 为新活动设置默认值
        if (!statusTypes.isEmpty()) {
            statusComboBox.setValue(statusTypes.get(0)); // 默认"未开始"
        }
        
        if (!activityTypes.isEmpty()) {
            activityTypeComboBox.setValue(null); // 查询时默认不选择类型
            typeComboBox.setValue(activityTypes.get(0)); // 新建时默认第一个类型
        }
    }
    
    /**
     * 加载活动数据
     */
    private void loadData() {
        try {
            DataRequest request = new DataRequest();
            
            String keyword = keywordTextField.getText();
            if (keyword != null && !keyword.isEmpty()) {
                request.add("keyword", keyword);
            }
            
            OptionItem selectedType = activityTypeComboBox.getValue();
            if (selectedType != null) {
                request.add("activityType", selectedType.getValue());
            }
            
            System.out.println("发送活动列表请求: " + request);
            
            // 修改为与荣誉管理一致的API路径
            DataResponse response = HttpRequestUtil.request("/api/activity/list", request);
            System.out.println("活动列表响应: " + (response != null ? "code=" + response.getCode() + ", msg=" + response.getMsg() : "null"));
            
            if (response != null && response.getData() != null) {
                dataList.clear();
                List<Map<String, Object>> list = (List<Map<String, Object>>) response.getData();
                
                // 添加调试日志
                System.out.println("从服务器获取的活动数据数量: " + list.size());
                
                // 转换数据格式，确保必要字段存在
                for (Map<String, Object> activity : list) {
                    // 创建新的Map以确保数据格式一致
                    Map<String, Object> formattedActivity = new HashMap<>(activity);
                    
                    // 确保必要字段至少有空值而不是null
                    if (!formattedActivity.containsKey("name") || formattedActivity.get("name") == null) {
                        formattedActivity.put("name", "");
                    }
                    
                    if (!formattedActivity.containsKey("activityType") || formattedActivity.get("activityType") == null) {
                        formattedActivity.put("activityType", "");
                    }
                    
                    if (!formattedActivity.containsKey("location") || formattedActivity.get("location") == null) {
                        formattedActivity.put("location", "");
                    }
                    
                    if (!formattedActivity.containsKey("organizer") || formattedActivity.get("organizer") == null) {
                        formattedActivity.put("organizer", "");
                    }
                    
                    if (!formattedActivity.containsKey("status") || formattedActivity.get("status") == null) {
                        formattedActivity.put("status", "1"); // 默认状态：未开始
                    }
                    
                    System.out.println("处理后的活动数据: " + formattedActivity);
                    dataList.add(formattedActivity);
                }
                
                dataTableView.setItems(dataList);
                dataTableView.refresh();
                
                if (!dataList.isEmpty()) {
                    dataTableView.getSelectionModel().select(0); // 选择第一项
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("加载活动列表时出错: " + e.getMessage());
        }
    }
    
    /**
     * 加载所有学生信息
     */
    private void loadAllStudents() {
        DataRequest request = new DataRequest();
        // 修改为与荣誉管理一致的API路径
        DataResponse response = HttpRequestUtil.request("/api/student/getStudentList", request);
        if (response != null && response.getData() != null) {
            List<Map<String, Object>> list = (List<Map<String, Object>>) response.getData();
            availableStudentsList.clear();
            availableStudentsList.addAll(list);
        }
    }
    
    /**
     * 搜索学生
     */
    private List<Map<String, Object>> searchStudents(String keyword) {
        List<Map<String, Object>> result = new ArrayList<>();
        if (keyword == null || keyword.trim().isEmpty()) {
            return availableStudentsList;
        }
        
        keyword = keyword.toLowerCase();
        for (Map<String, Object> student : availableStudentsList) {
            String num = String.valueOf(student.get("num")).toLowerCase();
            String name = String.valueOf(student.get("name")).toLowerCase();
            
            if (num.contains(keyword) || name.contains(keyword)) {
                result.add(student);
            }
        }
        return result;
    }
    
    /**
     * 显示活动详情
     */
    private void displayActivityDetails(Map<String, Object> activity) {
        // 安全地处理activityId
        currentActivityId = safeGetInteger(activity, "activityId");
        
        nameField.setText(String.valueOf(activity.get("name")));
        
        String activityType = String.valueOf(activity.get("activityType"));
        for (OptionItem item : typeComboBox.getItems()) {
            if (item.getValue().equals(activityType)) {
                typeComboBox.setValue(item);
                break;
            }
        }
        
        Object startTimeObj = activity.get("startTime");
        if (startTimeObj != null && !startTimeObj.toString().isEmpty()) {
            LocalDateTime startDateTime = LocalDateTime.parse(startTimeObj.toString(), dateTimeFormatter);
            startTimePicker.setValue(startDateTime.toLocalDate());
            startTimeField.setText(startDateTime.format(timeFormatter));
        } else {
            startTimePicker.setValue(null);
            startTimeField.setText("08:00");
        }
        
        Object endTimeObj = activity.get("endTime");
        if (endTimeObj != null && !endTimeObj.toString().isEmpty()) {
            LocalDateTime endDateTime = LocalDateTime.parse(endTimeObj.toString(), dateTimeFormatter);
            endTimePicker.setValue(endDateTime.toLocalDate());
            endTimeField.setText(endDateTime.format(timeFormatter));
        } else {
            endTimePicker.setValue(null);
            endTimeField.setText("18:00");
        }
        
        locationField.setText(String.valueOf(activity.get("location")));
        organizerField.setText(String.valueOf(activity.get("organizer")));
        
        String status = String.valueOf(activity.get("status"));
        for (OptionItem item : statusComboBox.getItems()) {
            if (item.getValue().equals(status)) {
                statusComboBox.setValue(item);
                break;
            }
        }
        
        // 设置最大人数字段
        Object maxParticipants = activity.get("maxParticipants");
        if (maxParticipants != null) {
            maxParticipantsField.setText(String.valueOf(maxParticipants));
        } else {
            maxParticipantsField.setText("");
        }
        
        descriptionTextArea.setText(String.valueOf(activity.get("description")));
        
        // 加载参与者
        loadParticipants(activity);
    }
    
    /**
     * 加载活动参与者数据
     */
    private void loadParticipants(Map<String, Object> activity) {
        participantsList.clear();
        
        // 获取活动ID
        Integer activityId = safeGetInteger(activity, "activityId");
        if (activityId == null) {
            return;
        }
        
        // 获取参与者列表
        List<Map<String, Object>> participants = (List<Map<String, Object>>) activity.get("participants");
        if (participants == null || participants.isEmpty()) {
            return;
        }
        
        // 为每个参与者填充详细信息并添加到表格
        for (Map<String, Object> participant : participants) {
            Map<String, Object> studentData = new HashMap<>();
            
            // 获取学生基本信息
            Map<String, Object> student = (Map<String, Object>) participant.get("student");
            if (student != null) {
                studentData.put("num", student.get("num"));
                studentData.put("name", student.get("name"));
                studentData.put("className", student.get("className"));
                studentData.put("dept", student.get("dept"));
                
                // 添加参与状态信息（如果后端没有提供，设置默认值）
                String status = participant.containsKey("status") ? 
                    String.valueOf(participant.get("status")) : "1"; // 默认为"已报名"
                studentData.put("participationStatus", status);
                
                // 添加加入时间信息
                String joinTime = participant.containsKey("joinTime") ? 
                    String.valueOf(participant.get("joinTime")) : 
                    LocalDateTime.now().format(dateTimeFormatter); // 默认为当前时间
                studentData.put("joinTime", joinTime);
                
                // 添加其他可能的参与者信息字段
                studentData.put("participantId", participant.get("participantId"));
                studentData.put("studentId", student.get("personId"));
                
                participantsList.add(studentData);
            }
        }
    }
    
    /**
     * 清空表单
     */
    private void clearForm() {
        currentActivityId = null;
        nameField.setText("");
        typeComboBox.setValue(null);
        startTimePicker.setValue(null);
        endTimePicker.setValue(null);
        startTimeField.setText("08:00");
        endTimeField.setText("18:00");
        locationField.setText("");
        organizerField.setText("");
        maxParticipantsField.setText("");
        
        // 设置默认状态为"未开始"
        for (OptionItem item : statusComboBox.getItems()) {
            if (item.getValue().equals("1")) { // 未开始
                statusComboBox.setValue(item);
                break;
            }
        }
        
        descriptionTextArea.setText("");
        participantsList.clear();
    }
    
    /**
     * 初始化活动编辑对话框
     */
    private void initEditDialog() {
        if (editStage == null) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/teach/javafx/activity-edit-dialog.fxml"));
                Scene scene = new Scene(loader.load());
                activityEditController = loader.getController();
                activityEditController.setActivityController(this);

                editStage = new Stage();
                editStage.setTitle("编辑活动信息");
                editStage.setScene(scene);
                editStage.initModality(Modality.APPLICATION_MODAL);
                editStage.setResizable(false);
            } catch (IOException e) {
                e.printStackTrace();
                MessageDialog.showDialog("加载编辑窗口失败：" + e.getMessage());
            }
        }
    }
    
    /**
     * 添加按钮点击事件
     */
    @FXML
    private void onAddButtonClick(ActionEvent event) {
        initEditDialog();
        activityEditController.showDialog(null);
        editStage.showAndWait();
    }
    
    /**
     * 编辑按钮点击事件
     */
    @FXML
    private void onEditButtonClick() {
        Map<String, Object> selectedItem = dataTableView.getSelectionModel().getSelectedItem();
        if (selectedItem == null) {
            MessageDialog.showDialog("请先选择要编辑的活动记录");
            return;
        }
        initEditDialog();
        activityEditController.showDialog(selectedItem);
        editStage.showAndWait();
    }
    
    /**
     * 删除按钮点击事件
     */
    @FXML
    private void onDeleteButtonClick(ActionEvent event) {
        Map<String, Object> selectedActivity = dataTableView.getSelectionModel().getSelectedItem();
        if (selectedActivity == null) {
            MessageDialog.showDialog("请先选择一条活动记录");
            return;
        }
        
        // 安全地处理ID
        Integer activityId = safeGetInteger(selectedActivity, "activityId");
        
        if (activityId == null) {
            MessageDialog.showDialog("活动ID无效");
            return;
        }
        
        if (MessageDialog.choiceDialog("确定要删除该活动记录吗？") == MessageDialog.CHOICE_YES) {
            DataRequest request = new DataRequest();
            request.add("activityId", activityId);
            
            DataResponse response = HttpRequestUtil.request("/api/activity/delete", request);
            if (response != null && response.getCode() == 0) {
                MessageDialog.showDialog("删除成功");
                loadData();
                clearForm();
            } else {
                MessageDialog.showDialog("删除失败: " + (response != null ? response.getMsg() : "未知错误"));
            }
        }
    }
    
    /**
     * 查询按钮点击事件
     */
    @FXML
    private void onQueryButtonClick(ActionEvent event) {
        loadData();
    }
    
    /**
     * 保存按钮点击事件
     */
    @FXML
    private void onSaveButtonClick(ActionEvent event) {
        Map<String, Object> selectedActivity = dataTableView.getSelectionModel().getSelectedItem();
        if (selectedActivity == null) {
            // 如果没有选中项，则创建新活动
            onAddButtonClick(event);
        } else {
            // 如果有选中项，则编辑现有活动
            onEditButtonClick();
        }
    }
    
    /**
     * 处理编辑对话框关闭事件
     */
    public void doClose(String cmd, Map<String, Object> data) {
        editStage.close();
        if (!"ok".equals(cmd)) {
            return;
        }

        try {
            // 打印完整的数据用于调试
            System.out.println("编辑对话框返回数据: " + data);
            
            // 构建请求
            DataRequest req = new DataRequest();
            
            // 添加ID（如果存在）
            Integer activityId = data.get("activityId") != null ? safeGetInteger(data.get("activityId")) : null;
            if (activityId != null) {
                req.add("activityId", activityId);
            }
            
            // 添加表单数据
            Map<String, Object> form = new HashMap<>();
            form.put("name", data.get("name"));
            form.put("activityType", data.get("activityType"));
            form.put("description", data.get("description"));
            form.put("location", data.get("location"));
            form.put("organizer", data.get("organizer")); 
            form.put("status", data.get("status"));
            form.put("maxParticipants", data.get("maxParticipants"));
            form.put("startTime", data.get("startTime"));
            form.put("endTime", data.get("endTime"));
            
            req.add("form", form);
            
            System.out.println("保存活动数据: " + form);
            
            // 发送保存请求
            DataResponse response = HttpRequestUtil.request("/api/activity/edit", req);
            
            if (response == null) {
                System.out.println("严重错误: API响应为null");
                MessageDialog.showDialog("保存失败，未知错误");
                return;
            }
            
            if (response.getCode() != 0) {
                System.out.println("保存失败: " + response.getMsg());
                MessageDialog.showDialog("保存失败: " + response.getMsg());
                return;
            }
            
            // 成功保存，刷新数据
            System.out.println("活动保存成功，正在刷新数据");
            loadData();
            MessageDialog.showDialog("保存成功");
            
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("严重异常: " + e.getMessage());
            MessageDialog.showDialog("保存失败: " + e.getMessage());
        }
    }
    
    /**
     * 安全地从Map中获取Integer值
     */
    private Integer safeGetInteger(Map<String, Object> map, String key) {
        Object value = map.get(key);
        return safeGetInteger(value);
    }
    
    /**
     * 安全地将对象转换为Integer
     */
    private Integer safeGetInteger(Object value) {
        if (value == null) {
            return null;
        }
        
        if (value instanceof Integer) {
            return (Integer) value;
        } else if (value instanceof Double) {
            return ((Double) value).intValue();
        } else if (value instanceof Number) {
            return ((Number) value).intValue();
        } else {
            try {
                return Integer.parseInt(value.toString());
            } catch (NumberFormatException e) {
                System.out.println("无法转换为Integer: " + value + ", 类型: " + value.getClass().getName());
                return null;
            }
        }
    }
    
    /**
     * 检查时间格式是否有效
     */
    private boolean isValidTimeFormat(String timeStr) {
        if (timeStr == null || timeStr.isEmpty()) {
            return false;
        }
        
        try {
            LocalTime.parse(timeStr, timeFormatter);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * 解析时间字符串为LocalTime
     */
    private LocalTime parseTime(String timeStr) {
        try {
            return LocalTime.parse(timeStr, timeFormatter);
        } catch (Exception e) {
            return LocalTime.of(0, 0);
        }
    }
    
    /**
     * 搜索学生按钮点击事件
     */
    @FXML
    private void onSearchStudentButtonClick(ActionEvent event) {
        String keyword = studentSearchField.getText();
        List<Map<String, Object>> students = searchStudents(keyword);
        
        if (students.isEmpty()) {
            MessageDialog.showDialog("未找到匹配的学生");
            return;
        }
        
        // 创建一个学生选择对话框
        showStudentSelectionDialog(students);
    }
    
    /**
     * 显示学生选择对话框
     */
    private void showStudentSelectionDialog(List<Map<String, Object>> students) {
        Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.setTitle("选择参与活动的学生");
        
        VBox dialogVBox = new VBox(10);
        dialogVBox.setPadding(new Insets(20));
        
        // 搜索框
        HBox searchBox = new HBox(10);
        searchBox.setAlignment(Pos.CENTER_LEFT);
        searchBox.getStyleClass().add("search-box");
        TextField searchField = new TextField();
        searchField.setPromptText("输入学号或姓名进行搜索");
        searchField.setPrefWidth(200);
        Button searchButton = new Button("搜索");
        searchButton.getStyleClass().add("button-search");
        searchBox.getChildren().addAll(new Label("关键字:"), searchField, searchButton);
        
        // 学生列表
        TableView<Map<String, Object>> studentTable = new TableView<>();
        studentTable.setPrefHeight(400);
        studentTable.getStyleClass().add("students-table");
        
        TableColumn<Map<String, Object>, String> numColumn = new TableColumn<>("学号");
        numColumn.setCellValueFactory(data -> new SimpleStringProperty(String.valueOf(data.getValue().get("num"))));
        numColumn.setPrefWidth(120);
        
        TableColumn<Map<String, Object>, String> nameColumn = new TableColumn<>("姓名");
        nameColumn.setCellValueFactory(data -> new SimpleStringProperty(String.valueOf(data.getValue().get("name"))));
        nameColumn.setPrefWidth(100);
        
        TableColumn<Map<String, Object>, String> classColumn = new TableColumn<>("班级");
        classColumn.setCellValueFactory(data -> new SimpleStringProperty(String.valueOf(data.getValue().get("className"))));
        classColumn.setPrefWidth(150);
        
        TableColumn<Map<String, Object>, String> deptColumn = new TableColumn<>("院系");
        deptColumn.setCellValueFactory(data -> new SimpleStringProperty(String.valueOf(data.getValue().get("dept"))));
        deptColumn.setPrefWidth(180);
        
        studentTable.getColumns().addAll(numColumn, nameColumn, classColumn, deptColumn);
        
        // 参与状态选择
        HBox statusBox = new HBox(10);
        statusBox.setAlignment(Pos.CENTER_LEFT);
        Label statusLabel = new Label("参与状态:");
        ComboBox<String> statusCombo = new ComboBox<>();
        statusCombo.getItems().addAll("已报名", "已参加", "已完成");
        statusCombo.setValue("已报名");
        statusBox.getChildren().addAll(statusLabel, statusCombo);
        
        // 确认按钮
        HBox buttonBox = new HBox(20);
        buttonBox.setAlignment(Pos.CENTER);
        Button addButton = new Button("添加选中学生");
        addButton.getStyleClass().add("button-success");
        Button cancelButton = new Button("取消");
        cancelButton.getStyleClass().add("button-secondary");
        buttonBox.getChildren().addAll(addButton, cancelButton);
        
        dialogVBox.getChildren().addAll(searchBox, studentTable, statusBox, buttonBox);
        
        // 加载学生数据
        ObservableList<Map<String, Object>> studentData = FXCollections.observableArrayList(students);
        studentTable.setItems(studentData);
        
        // 搜索功能
        searchButton.setOnAction(e -> {
            String keyword = searchField.getText().toLowerCase().trim();
            if (keyword.isEmpty()) {
                studentTable.setItems(studentData);
            } else {
                ObservableList<Map<String, Object>> filteredData = FXCollections.observableArrayList();
                for (Map<String, Object> student : students) {
                    String num = String.valueOf(student.get("num")).toLowerCase();
                    String name = String.valueOf(student.get("name")).toLowerCase();
                    String className = String.valueOf(student.get("className")).toLowerCase();
                    
                    if (num.contains(keyword) || name.contains(keyword) || className.contains(keyword)) {
                        filteredData.add(student);
                    }
                }
                studentTable.setItems(filteredData);
            }
        });
        
        // 确认添加学生
        addButton.setOnAction(e -> {
            ObservableList<Map<String, Object>> selectedItems = studentTable.getSelectionModel().getSelectedItems();
            if (selectedItems.isEmpty()) {
                MessageDialog.showDialog("请至少选择一名学生");
                return;
            }
            
            // 获取选中的参与状态
            String statusText = statusCombo.getValue();
            String statusCode = "1"; // 默认为"已报名"
            switch (statusText) {
                case "已参加":
                    statusCode = "2";
                    break;
                case "已完成":
                    statusCode = "3";
                    break;
            }
            
            // 处理选中的学生
            for (Map<String, Object> selectedStudent : selectedItems) {
                Map<String, Object> participantData = new HashMap<>(selectedStudent);
                
                // 添加参与状态信息
                participantData.put("participationStatus", statusCode);
                
                // 添加加入时间
                participantData.put("joinTime", LocalDateTime.now().format(dateTimeFormatter));
                
                // 添加到参与者列表
                participantsList.add(participantData);
                
                // 如果已连接到后端，向服务器发送添加参与者请求
                if (currentActivityId != null) {
                    DataRequest request = new DataRequest();
                    request.add("activityId", currentActivityId);
                    request.add("studentId", safeGetInteger(selectedStudent, "personId"));
                    request.add("status", statusCode);
                    
                    // 修正API路径，根据后端接口命名
                    DataResponse response = HttpRequestUtil.request("/api/activity/addStudent", request);
                    if (response == null || response.getCode() != 0) {
                        String errorMsg = response != null ? response.getMsg() : "未知错误";
                        System.out.println("添加学生到活动失败: " + errorMsg);
                        // 不显示错误给用户，因为本地已添加，这只是服务器同步
                    }
                }
            }
            
            dialog.close();
        });
        
        // 取消按钮
        cancelButton.setOnAction(e -> dialog.close());
        
        // 配置多选
        studentTable.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        
        Scene dialogScene = new Scene(dialogVBox, 600, 550);
        // 应用CSS样式
        dialogScene.getStylesheets().add(MainApplication.class.getResource("css/activity-panel.css").toExternalForm());
        dialog.setScene(dialogScene);
        dialog.showAndWait();
    }
    
    /**
     * 添加参与者按钮事件
     */
    @FXML
    private void onAddStudentButtonClick(ActionEvent event) {
        if (currentActivityId == null) {
            MessageDialog.showDialog("请先选择或保存活动");
            return;
        }
        
        // 获取可用学生列表，如果之前没有加载过则进行加载
        if (availableStudentsList.isEmpty()) {
            loadAllStudents();
        }
        
        // 显示学生选择对话框，并将选中的学生添加为参与者
        List<Map<String, Object>> availableStudents = new ArrayList<>(availableStudentsList);
        // 排除已经是参与者的学生
        for (Map<String, Object> participant : participantsList) {
            String studentNum = String.valueOf(participant.get("num"));
            availableStudents.removeIf(student -> String.valueOf(student.get("num")).equals(studentNum));
        }
        
        if (availableStudents.isEmpty()) {
            MessageDialog.showDialog("没有可添加的学生了");
            return;
        }
        
        showStudentSelectionDialog(availableStudents);
    }
    
    /**
     * 移除学生参与者按钮点击事件
     */
    @FXML
    private void onRemoveStudentButtonClick(ActionEvent event) {
        Map<String, Object> selectedStudent = participantsTableView.getSelectionModel().getSelectedItem();
        if (selectedStudent == null) {
            MessageDialog.showDialog("请先选择一个参与者");
            return;
        }
        
        if (currentActivityId == null) {
            // 本地移除
            participantsList.remove(selectedStudent);
            return;
        }
        
        if (MessageDialog.choiceDialog("确定要从活动中移除该学生吗？") == MessageDialog.CHOICE_YES) {
            // 本地移除
            participantsList.remove(selectedStudent);
            
            // 服务器移除
            Integer studentId = safeGetInteger(selectedStudent, "personId");
            
            if (studentId != null) {
                DataRequest request = new DataRequest();
                request.add("activityId", currentActivityId);
                request.add("studentId", studentId);
                
                // 修正API路径，根据后端接口命名
                DataResponse response = HttpRequestUtil.request("/api/activity/removeStudent", request);
                if (response == null || response.getCode() != 0) {
                    String errorMsg = response != null ? response.getMsg() : "未知错误";
                    System.out.println("从服务器移除参与者失败: " + errorMsg);
                    // 不显示错误给用户，因为本地已移除，这只是服务器同步
                }
            }
        }
    }
    
    /**
     * 导出参与者统计表按钮事件
     */
    @FXML
    private void onExportParticipantsButtonClick(ActionEvent event) {
        if (participantsList.isEmpty()) {
            MessageDialog.showDialog("没有参与者数据可导出");
            return;
        }
        
        // 获取活动名称
        final String activityName = nameField.getText() == null || nameField.getText().trim().isEmpty() ? 
                                   "未命名活动" : nameField.getText().trim();
        
        // 创建导出对话框
        Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.setTitle("导出学生参与活动统计表");
        
        VBox dialogVBox = new VBox(15);
        dialogVBox.setPadding(new Insets(20));
        
        // 标题和说明
        Label titleLabel = new Label("学生社会实践参与统计表");
        titleLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
        
        Label activityLabel = new Label("活动: " + activityName);
        activityLabel.setStyle("-fx-font-size: 14px;");
        
        // 统计信息
        GridPane statsGrid = new GridPane();
        statsGrid.setHgap(10);
        statsGrid.setVgap(10);
        statsGrid.add(new Label("参与总人数:"), 0, 0);
        statsGrid.add(new Label(String.valueOf(participantsList.size())), 1, 0);
        
        // 统计不同状态的人数
        int pendingCount = 0;
        int attendedCount = 0;
        int completedCount = 0;
        
        for (Map<String, Object> participant : participantsList) {
            String status = String.valueOf(participant.get("participationStatus"));
            if ("1".equals(status)) {
                pendingCount++;
            } else if ("2".equals(status)) {
                attendedCount++;
            } else if ("3".equals(status)) {
                completedCount++;
            }
        }
        
        statsGrid.add(new Label("已报名人数:"), 0, 1);
        statsGrid.add(new Label(String.valueOf(pendingCount)), 1, 1);
        
        statsGrid.add(new Label("已参加人数:"), 0, 2);
        statsGrid.add(new Label(String.valueOf(attendedCount)), 1, 2);
        
        statsGrid.add(new Label("已完成人数:"), 0, 3);
        statsGrid.add(new Label(String.valueOf(completedCount)), 1, 3);
        
        // 参与者详细列表
        TextArea exportTextArea = new TextArea();
        exportTextArea.setEditable(false);
        exportTextArea.setPrefHeight(300);
        exportTextArea.setWrapText(true);
        
        StringBuilder sb = new StringBuilder();
        sb.append("学生社会实践参与统计表\n");
        sb.append("活动: ").append(activityName).append("\n");
        sb.append("导出时间: ").append(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))).append("\n\n");
        
        sb.append(String.format("%-15s\t%-10s\t%-15s\t%-15s\t%-12s\t%-20s\n", 
                 "学号", "姓名", "班级", "院系", "参与状态", "加入时间"));
        sb.append("------------------------------------------------------------------------------------------------------\n");
        
        for (Map<String, Object> participant : participantsList) {
            String num = String.valueOf(participant.get("num"));
            String name = String.valueOf(participant.get("name"));
            String className = String.valueOf(participant.get("className"));
            String dept = String.valueOf(participant.get("dept"));
            
            // 获取状态文本
            String statusCode = String.valueOf(participant.get("participationStatus"));
            String status;
            switch (statusCode) {
                case "1": status = "已报名"; break;
                case "2": status = "已参加"; break;
                case "3": status = "已完成"; break;
                default: status = "未知状态"; break;
            }
            
            // 获取加入时间
            String joinTime = String.valueOf(participant.get("joinTime"));
            if (joinTime != null && !joinTime.equals("null") && !joinTime.isEmpty()) {
                try {
                    LocalDateTime dateTime = LocalDateTime.parse(joinTime, dateTimeFormatter);
                    joinTime = dateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
                } catch (Exception e) {
                    // 如果解析失败，保持原样
                }
            }
            
            sb.append(String.format("%-15s\t%-10s\t%-15s\t%-15s\t%-12s\t%-20s\n", 
                     num, name, className, dept, status, joinTime));
        }
        
        exportTextArea.setText(sb.toString());
        
        // 底部按钮
        HBox buttonBox = new HBox(20);
        buttonBox.setAlignment(Pos.CENTER);
        Button copyButton = new Button("复制到剪贴板");
        copyButton.getStyleClass().add("button-info");
        Button saveButton = new Button("保存到文件");
        saveButton.getStyleClass().add("button-primary");
        Button closeButton = new Button("关闭");
        closeButton.getStyleClass().add("button-secondary");
        
        buttonBox.getChildren().addAll(copyButton, saveButton, closeButton);
        
        dialogVBox.getChildren().addAll(titleLabel, activityLabel, statsGrid, new Label("详细数据:"), exportTextArea, buttonBox);
        
        // 设置按钮事件
        copyButton.setOnAction(e -> {
            final javafx.scene.input.Clipboard clipboard = javafx.scene.input.Clipboard.getSystemClipboard();
            final javafx.scene.input.ClipboardContent content = new javafx.scene.input.ClipboardContent();
            content.putString(exportTextArea.getText());
            clipboard.setContent(content);
            MessageDialog.showDialog("数据已复制到剪贴板");
        });
        
        saveButton.setOnAction(e -> {
            // 简单实现：保存到模拟文件
            String fileName = "学生社会实践统计表_" + activityName + "_" + 
                              LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")) + ".txt";
            
            MessageDialog.showDialog("数据已保存到文件: " + fileName);
        });
        
        closeButton.setOnAction(e -> dialog.close());
        
        Scene dialogScene = new Scene(dialogVBox, 650, 600);
        // 应用CSS样式
        dialogScene.getStylesheets().add(MainApplication.class.getResource("css/activity-panel.css").toExternalForm());
        dialog.setScene(dialogScene);
        dialog.showAndWait();
    }
    
    /**
     * 清空按钮点击事件
     */
    @FXML
    private void onClearButtonClick(ActionEvent event) {
        clearForm();
    }
} 