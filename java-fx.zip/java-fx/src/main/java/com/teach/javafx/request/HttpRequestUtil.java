package com.teach.javafx.request;

import com.teach.javafx.AppStore;
import com.google.gson.Gson;

import java.io.IOException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.URI;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.List;
import java.nio.file.Path;
import java.util.Map;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;

/**
 * HttpRequestUtil 后台请求实例程序，主要实践向后台发送请求的方法
 *  static boolean isLocal 业务处理程序实现方式 false java-server实现 前端程序通过下面的方法把数据发送后台程序，后台返回前端需要的数据，true 本地方式 业务处理 在SQLiteJDBC 实现
 *  String serverUrl = "http://localhost:9090" 后台服务的机器地址和端口号
 */
public class HttpRequestUtil {
    private static final Gson gson = new Gson();
    private static final HttpClient client = HttpClient.newHttpClient();
    public static String serverUrl = "http://localhost:22223";
//    public static String serverUrl = "http://202.194.7.29:22222";
    
    // 添加一个标志，在无法连接服务器时使用模拟数据
    private static boolean useMockData = false;
    
    /**
     * 测试服务器连接
     * @return 连接是否成功
     */
    public static boolean testConnection() {
        try {
            HttpRequest httpRequest = HttpRequest.newBuilder()
                    .uri(URI.create(serverUrl + "/api/base/ping"))
                    .GET()
                    .timeout(java.time.Duration.ofSeconds(5))
                    .build();
            
            HttpResponse<String> response = client.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            System.out.println("服务器连接测试结果: " + response.statusCode());
            
            // 403 表示服务器拒绝访问，但服务器本身是在线的
            // 所以我们认为 200 和 403 都表示服务器是可达的
            boolean isServerReachable = (response.statusCode() == 200 || response.statusCode() == 403);
            useMockData = !isServerReachable;
            
            return isServerReachable;
        } catch (Exception e) {
            System.out.println("服务器连接失败: " + e.getMessage());
            useMockData = true;
            return false;
        }
    }

    /**
     *  应用关闭是需要做关闭处理
     */
    public static void close(){
    }

    /**
     * String login(LoginRequest request)  用户登录请求实现
     * @param request  username 登录账号 password 登录密码
     * @return  返回null 登录成功 AppStore注册登录账号信息 非空，登录错误信息
     */

    public static String login(LoginRequest request){
            HttpRequest httpRequest = HttpRequest.newBuilder()
                    .uri(URI.create(serverUrl + "/auth/login"))
                    .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(request)))
                    .headers("Content-Type", "application/json")
                    .build();
            try {
                HttpResponse<String> response = client.send(httpRequest, HttpResponse.BodyHandlers.ofString());
                System.out.println("response.statusCode===="+response.statusCode());
                if (response.statusCode() == 200) {
                    JwtResponse jwt = gson.fromJson(response.body(), JwtResponse.class);
                    AppStore.setJwt(jwt);
                    return null;
                } else if (response.statusCode() == 401) {
                    return "用户名或密码不存在！";
                }
            } catch (IOException | InterruptedException e) {
                e.printStackTrace();
            }
        return "登录失败";
    }

    /**
     * DataResponse request(String url,DataRequest request) 一般数据请求业务的实现
     * @param url  Web请求的Url 对用后的 RequestMapping
     * @param request 请求参数对象
     * @return DataResponse 返回后台返回数据
     */
    public static DataResponse request(String url, DataRequest request){
        try {
            // 如果配置为使用模拟数据，或者是活动相关的请求
            if (useMockData && (url.equals("/api/activity/edit") || url.equals("/api/activity/list") || 
                url.equals("/api/student/list") || url.equals("/api/honor/list") || url.equals("/api/honor/edit") || 
                url.equals("/api/leave/list") || url.equals("/api/leave/edit") || url.equals("/api/leave/approve") || url.equals("/api/leave/delete") || 
                url.equals("/api/expense/list") || url.equals("/api/expense/edit") || url.equals("/api/expense/delete") || url.equals("/api/expense/statistics") || 
                url.equals("/api/innovation/list") || url.equals("/api/innovation/edit") || url.equals("/api/innovation/approve") || url.equals("/api/innovation/delete") || 
                url.equals("/api/base/getMenuList"))) {
                if (url.equals("/api/student/list")) {
                    return getMockStudentResponse();
                } else if (url.equals("/api/honor/list") || url.equals("/api/honor/edit") || url.equals("/api/honor/delete")) {
                    return getMockHonorResponse(url, request);
                } else if (url.equals("/api/leave/list") || url.equals("/api/leave/edit") || url.equals("/api/leave/approve") || url.equals("/api/leave/delete")) {
                    return getMockLeaveResponse(url, request);
                } else if (url.equals("/api/expense/list") || url.equals("/api/expense/edit") || url.equals("/api/expense/delete") || url.equals("/api/expense/statistics")) {
                    return getMockExpenseLogResponse(url, request);
                } else if (url.equals("/api/innovation/list") || url.equals("/api/innovation/edit") || url.equals("/api/innovation/approve") || url.equals("/api/innovation/delete")) {
                    return getMockInnovationResponse(url, request);
                } else if (url.equals("/api/base/getMenuList")) {
                    return getMockMenuResponse();
                }
                return getMockActivityResponse(url, request);
            }
            
            // 检查会话是否有效
            boolean isSessionValid = AppStore.getJwt() != null && AppStore.getJwt().getToken() != null;
            
            // 如果没有有效会话且请求需要授权，使用模拟数据
            if (!isSessionValid && (url.contains("/api/activity/") || url.contains("/api/student/") || 
                url.contains("/api/honor/") || url.contains("/api/leave/") || url.contains("/api/expense/") ||
                url.contains("/api/innovation/"))) {
                System.out.println("警告: 无有效会话，使用模拟数据 " + url);
                if (url.equals("/api/student/list")) {
                    return getMockStudentResponse();
                } else if (url.equals("/api/honor/list") || url.equals("/api/honor/edit") || url.equals("/api/honor/delete")) {
                    return getMockHonorResponse(url, request);
                } else if (url.equals("/api/leave/list") || url.equals("/api/leave/edit") || url.equals("/api/leave/approve") || url.equals("/api/leave/delete")) {
                    return getMockLeaveResponse(url, request);
                } else if (url.equals("/api/expense/list") || url.equals("/api/expense/edit") || url.equals("/api/expense/delete") || url.equals("/api/expense/statistics")) {
                    return getMockExpenseLogResponse(url, request);
                } else if (url.equals("/api/innovation/list") || url.equals("/api/innovation/edit") || url.equals("/api/innovation/approve") || url.equals("/api/innovation/delete")) {
                    return getMockInnovationResponse(url, request);
                }
                return getMockActivityResponse(url, request);
            }
            
            // 增加请求超时设置
            HttpRequest.Builder requestBuilder = HttpRequest.newBuilder()
                    .uri(URI.create(serverUrl + url))
                    .timeout(java.time.Duration.ofSeconds(10));
            
            // 添加请求体和头信息
            requestBuilder.POST(HttpRequest.BodyPublishers.ofString(gson.toJson(request)))
                    .header("Content-Type", "application/json");
            
            // 只有在会话有效时才添加授权头
            if (isSessionValid) {
                requestBuilder.header("Authorization", "Bearer " + AppStore.getJwt().getToken());
                request.add("username", AppStore.getJwt().getUsername());
            }
            
            HttpRequest httpRequest = requestBuilder.build();
            HttpClient client = HttpClient.newHttpClient();
            
            try {
                HttpResponse<String> response = client.send(httpRequest, HttpResponse.BodyHandlers.ofString());
                System.out.println("url=" + url +"    response.statusCode="+response.statusCode());
                
                if (response.statusCode() == 200) {
                    try {
                        return gson.fromJson(response.body(), DataResponse.class);
                    } catch (Exception e) {
                        System.out.println("JSON解析错误: " + e.getMessage());
                        // 对于关键API，在解析错误时使用模拟数据
                        if (url.equals("/api/activity/edit") || url.equals("/api/activity/list") || 
                            url.equals("/api/activity/info") || url.equals("/api/student/list") ||
                            url.equals("/api/honor/list") || url.equals("/api/honor/edit") ||
                            url.equals("/api/leave/list") || url.equals("/api/leave/edit") || url.equals("/api/leave/approve") ||
                            url.equals("/api/expense/list") || url.equals("/api/expense/edit") || url.equals("/api/expense/statistics") ||
                            url.equals("/api/innovation/list") || url.equals("/api/innovation/edit") || url.equals("/api/innovation/approve") ||
                            url.equals("/api/base/getMenuList")) {
                            System.out.println("由于JSON解析错误，为" + url + "使用模拟数据");
                            if (url.equals("/api/student/list")) {
                                return getMockStudentResponse();
                            } else if (url.equals("/api/honor/list") || url.equals("/api/honor/edit") || url.equals("/api/honor/delete")) {
                                return getMockHonorResponse(url, request);
                            } else if (url.equals("/api/leave/list") || url.equals("/api/leave/edit") || url.equals("/api/leave/approve") || url.equals("/api/leave/delete")) {
                                return getMockLeaveResponse(url, request);
                            } else if (url.equals("/api/expense/list") || url.equals("/api/expense/edit") || url.equals("/api/expense/delete") || url.equals("/api/expense/statistics")) {
                                return getMockExpenseLogResponse(url, request);
                            } else if (url.equals("/api/innovation/list") || url.equals("/api/innovation/edit") || url.equals("/api/innovation/approve") || url.equals("/api/innovation/delete")) {
                                return getMockInnovationResponse(url, request);
                            } else if (url.equals("/api/base/getMenuList")) {
                                return getMockMenuResponse();
                            }
                            return getMockActivityResponse(url, request);
                        }
                        return new DataResponse(1, null, "服务器响应格式错误");
                    }
                } else if (response.statusCode() == 403 || response.statusCode() == 401) {
                    System.out.println("授权失败，状态码: " + response.statusCode() + ", 响应内容: " + response.body());
                    
                    // 对于活动相关请求，使用模拟数据
                    if (url.contains("/api/activity/")) {
                        return getMockActivityResponse(url, request);
                    }
                    
                    return new DataResponse(1, null, "无访问权限: " + response.statusCode());
                } else if (response.statusCode() == 404) {
                    System.out.println("请求的资源不存在，状态码: 404, 响应内容: " + response.body());
                    
                    // 对于特定请求，使用模拟数据
                    if (url.equals("/api/student/list")) {
                        return getMockStudentResponse();
                    } else if (url.equals("/api/honor/list") || url.equals("/api/honor/edit") || url.equals("/api/honor/delete")) {
                        return getMockHonorResponse(url, request);
                    } else if (url.equals("/api/leave/list") || url.equals("/api/leave/edit") || url.equals("/api/leave/approve") || url.equals("/api/leave/delete")) {
                        return getMockLeaveResponse(url, request);
                    } else if (url.equals("/api/expense/list") || url.equals("/api/expense/edit") || url.equals("/api/expense/delete") || url.equals("/api/expense/statistics")) {
                        return getMockExpenseLogResponse(url, request);
                    } else if (url.equals("/api/innovation/list") || url.equals("/api/innovation/edit") || url.equals("/api/innovation/approve") || url.equals("/api/innovation/delete")) {
                        return getMockInnovationResponse(url, request);
                    } else if (url.equals("/api/base/getMenuList")) {
                        return getMockMenuResponse();
                    } else if (url.contains("/api/activity/")) {
                        return getMockActivityResponse(url, request);
                    }
                    
                    return new DataResponse(1, null, "请求的资源不存在: 404");
                } else {
                    System.out.println("请求失败，状态码: " + response.statusCode() + ", 响应内容: " + response.body());
                    
                    // 即使服务器返回错误，也为关键接口提供模拟数据
                    if (url.equals("/api/activity/edit") || url.equals("/api/activity/list") || 
                        url.equals("/api/activity/info") || url.equals("/api/student/list") ||
                        url.equals("/api/honor/list") || url.equals("/api/honor/edit") ||
                        url.equals("/api/leave/list") || url.equals("/api/leave/edit") || url.equals("/api/leave/approve") ||
                        url.equals("/api/expense/list") || url.equals("/api/expense/edit") || url.equals("/api/expense/statistics") ||
                        url.equals("/api/innovation/list") || url.equals("/api/innovation/edit") || url.equals("/api/innovation/approve") ||
                        url.equals("/api/base/getMenuList")) {
                        System.out.println("检测到连接失败，为重要接口" + url + "使用模拟数据");
                        if (url.equals("/api/student/list")) {
                            return getMockStudentResponse();
                        } else if (url.equals("/api/honor/list") || url.equals("/api/honor/edit") || url.equals("/api/honor/delete")) {
                            return getMockHonorResponse(url, request);
                        } else if (url.equals("/api/leave/list") || url.equals("/api/leave/edit") || url.equals("/api/leave/approve") || url.equals("/api/leave/delete")) {
                            return getMockLeaveResponse(url, request);
                        } else if (url.equals("/api/expense/list") || url.equals("/api/expense/edit") || url.equals("/api/expense/delete") || url.equals("/api/expense/statistics")) {
                            return getMockExpenseLogResponse(url, request);
                        } else if (url.equals("/api/innovation/list") || url.equals("/api/innovation/edit") || url.equals("/api/innovation/approve") || url.equals("/api/innovation/delete")) {
                            return getMockInnovationResponse(url, request);
                        } else if (url.equals("/api/base/getMenuList")) {
                            return getMockMenuResponse();
                        }
                        // 对于活动编辑接口，特别记录是在连接失败情况下使用模拟数据
                        if (url.equals("/api/activity/edit")) {
                            System.out.println("服务器连接失败，为活动保存请求返回模拟成功响应");
                        }
                        return getMockActivityResponse(url, request);
                    }
                    
                    return new DataResponse(1, null, "服务器响应错误，状态码: " + response.statusCode());
                }
            } catch (IOException | InterruptedException e) {
                e.printStackTrace();
                System.out.println("请求发送异常: " + e.getMessage());
                
                // 服务器连接失败时，对某些关键请求返回模拟数据
                if (url.equals("/api/activity/edit") || url.equals("/api/activity/list") || 
                    url.equals("/api/activity/info") || url.equals("/api/student/list") ||
                    url.equals("/api/honor/list") || url.equals("/api/honor/edit") ||
                    url.equals("/api/leave/list") || url.equals("/api/leave/edit") || url.equals("/api/leave/approve") ||
                    url.equals("/api/expense/list") || url.equals("/api/expense/edit") || url.equals("/api/expense/statistics") ||
                    url.equals("/api/innovation/list") || url.equals("/api/innovation/edit") || url.equals("/api/innovation/approve") ||
                    url.equals("/api/base/getMenuList")) {
                    System.out.println("检测到连接失败，为重要接口" + url + "使用模拟数据");
                    if (url.equals("/api/student/list")) {
                        return getMockStudentResponse();
                    } else if (url.equals("/api/honor/list") || url.equals("/api/honor/edit") || url.equals("/api/honor/delete")) {
                        return getMockHonorResponse(url, request);
                    } else if (url.equals("/api/leave/list") || url.equals("/api/leave/edit") || url.equals("/api/leave/approve") || url.equals("/api/leave/delete")) {
                        return getMockLeaveResponse(url, request);
                    } else if (url.equals("/api/expense/list") || url.equals("/api/expense/edit") || url.equals("/api/expense/delete") || url.equals("/api/expense/statistics")) {
                        return getMockExpenseLogResponse(url, request);
                    } else if (url.equals("/api/innovation/list") || url.equals("/api/innovation/edit") || url.equals("/api/innovation/approve") || url.equals("/api/innovation/delete")) {
                        return getMockInnovationResponse(url, request);
                    } else if (url.equals("/api/base/getMenuList")) {
                        return getMockMenuResponse();
                    }
                    // 对于活动编辑接口，特别记录是在连接失败情况下使用模拟数据
                    if (url.equals("/api/activity/edit")) {
                        System.out.println("服务器连接失败，为活动保存请求返回模拟成功响应");
                    }
                    return getMockActivityResponse(url, request);
                }
                
                return new DataResponse(1, null, "无法连接到服务器: " + e.getMessage());
            }
        } catch (Exception e) {
            e.printStackTrace();
            return new DataResponse(1, null, "请求处理异常: " + e.getMessage());
        }
    }
    
    /**
     * 获取模拟学生数据响应
     */
    private static DataResponse getMockStudentResponse() {
        System.out.println("使用模拟学生数据响应请求");
        
        List<Map<String, Object>> students = new ArrayList<>();
        
        // 创建一些模拟学生数据
        String[][] studentData = {
            {"2023001", "张三", "计科2301", "计算机科学与技术学院", "1001"},
            {"2023002", "李四", "计科2301", "计算机科学与技术学院", "1002"},
            {"2023003", "王五", "计科2302", "计算机科学与技术学院", "1003"},
            {"2023004", "赵六", "计科2302", "计算机科学与技术学院", "1004"},
            {"2023005", "钱七", "软工2301", "计算机科学与技术学院", "1005"},
            {"2023006", "孙八", "软工2301", "计算机科学与技术学院", "1006"},
            {"2023007", "周九", "数媒2301", "计算机科学与技术学院", "1007"},
            {"2023008", "吴十", "数媒2301", "计算机科学与技术学院", "1008"},
            {"2023009", "郑十一", "物联网2301", "计算机科学与技术学院", "1009"},
            {"2023010", "王十二", "物联网2301", "计算机科学与技术学院", "1010"}
        };
        
        for (String[] data : studentData) {
            Map<String, Object> student = new HashMap<>();
            student.put("num", data[0]);
            student.put("name", data[1]);
            student.put("className", data[2]);
            student.put("dept", data[3]);
            student.put("personId", Integer.parseInt(data[4]));
            students.add(student);
        }
        
        return new DataResponse(0, students, "查询成功(模拟数据)");
    }
    
    /**
     * 获取模拟活动数据响应
     */
    private static DataResponse getMockActivityResponse(String url, DataRequest request) {
        System.out.println("使用模拟数据响应请求: " + url);
        
        if (url.equals("/api/activity/edit")) {
            // 模拟保存活动响应
            Map<String, Object> form = (Map<String, Object>) request.get("form");
            Integer activityId = (Integer) request.get("activityId");
            
            // 如果是更新，返回原ID；如果是新增，返回新ID
            int newId = activityId != null ? activityId : 1000 + (int)(Math.random() * 1000);
            System.out.println("模拟活动保存成功，ID: " + newId);
            return new DataResponse(0, newId, "保存成功(模拟数据)");
        } 
        else if (url.equals("/api/activity/list")) {
            // 模拟活动列表数据
            List<Map<String, Object>> activities = new ArrayList<>();
            
            // 创建几个模拟活动
            for (int i = 1; i <= 5; i++) {
                Map<String, Object> activity = new HashMap<>();
                activity.put("activityId", 1000 + i);
                activity.put("name", "模拟活动 " + i);
                activity.put("activityType", String.valueOf(i % 8 + 1));
                
                LocalDateTime startTime = LocalDateTime.now().plusDays(i);
                LocalDateTime endTime = startTime.plusHours(2);
                activity.put("startTime", startTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
                activity.put("endTime", endTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
                
                activity.put("location", "模拟地点 " + i);
                activity.put("organizer", "模拟组织者 " + i);
                activity.put("status", String.valueOf(i % 4 + 1));
                activity.put("description", "这是一个模拟活动的描述，用于测试显示效果。");
                
                // 添加模拟参与者
                List<Map<String, Object>> participants = new ArrayList<>();
                activity.put("participants", participants);
                
                activities.add(activity);
            }
            
            return new DataResponse(0, activities, "查询成功(模拟数据)");
        }
        // 活动详情接口
        else if (url.equals("/api/activity/info")) {
            Integer activityId = (Integer) request.get("activityId");
            if (activityId != null) {
                // 创建一个活动详情数据
                Map<String, Object> activity = new HashMap<>();
                activity.put("activityId", activityId);
                activity.put("name", "模拟活动详情 " + activityId);
                activity.put("activityType", "1"); // 默认类型为讲座
                
                LocalDateTime startTime = LocalDateTime.now().plusDays(1);
                LocalDateTime endTime = startTime.plusHours(2);
                activity.put("startTime", startTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
                activity.put("endTime", endTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
                
                activity.put("location", "模拟地点");
                activity.put("organizer", "模拟组织者");
                activity.put("status", "1"); // 未开始
                activity.put("description", "这是一个模拟活动的详情描述，用于测试显示效果。");
                activity.put("maxParticipants", 100);
                
                // 添加模拟参与者
                List<Map<String, Object>> participants = new ArrayList<>();
                activity.put("participants", participants);
                
                return new DataResponse(0, activity, "查询成功(模拟数据)");
            }
        }
        
        // 默认返回成功响应
        return new DataResponse(0, null, "操作成功(模拟数据)");
    }

    /**
     * 获取模拟荣誉数据响应
     */
    private static DataResponse getMockHonorResponse(String url, DataRequest request) {
        System.out.println("使用模拟荣誉数据响应请求: " + url);
        
        if (url.equals("/api/honor/edit")) {
            // 模拟保存荣誉响应
            Map<String, Object> form = (Map<String, Object>) request.get("form");
            Integer honorId = (Integer) request.get("honorId");
            
            // 如果是更新，返回原ID；如果是新增，返回新ID
            int newId = honorId != null ? honorId : 2000 + (int)(Math.random() * 1000);
            System.out.println("模拟荣誉保存成功，ID: " + newId);
            return new DataResponse(0, newId, "保存成功(模拟数据)");
        } 
        else if (url.equals("/api/honor/list")) {
            // 模拟荣誉列表数据
            List<Map<String, Object>> honors = new ArrayList<>();
            
            // 获取过滤条件
            String keyword = (String) request.get("keyword");
            String honorType = null;
            if (request.get("honorType") != null) {
                honorType = request.get("honorType").toString();
            }
            
            // 创建模拟学生数据
            DataResponse studentsResponse = getMockStudentResponse();
            List<Map<String, Object>> students = (List<Map<String, Object>>) studentsResponse.getData();
            
            // 默认荣誉数据
            String[][] honorsData = {
                {"全国数学建模大赛一等奖", "2", "1", "2024-04-15", "全国大学生数学建模组委会", "MATH2024001", "获得了全国大学生数学建模竞赛一等奖", "1001"},
                {"优秀学生奖学金", "1", "4", "2024-03-20", "计算机科学与技术学院", "XJJ2024050", "因学习成绩优异获得奖学金", "1002"},
                {"社会工作先进个人", "4", "4", "2024-02-10", "共青团委员会", "SGXJ20242345", "在校园活动组织中表现突出", "1003"},
                {"省级程序设计大赛银奖", "2", "2", "2024-01-25", "省教育厅", "SJSJDS2024023", "在省级程序设计大赛中获得银奖", "1004"},
                {"优秀志愿者", "4", "4", "2023-12-15", "校志愿者协会", "ZYZ202312321", "积极参与志愿服务活动", "1005"},
                {"校级辩论赛冠军", "5", "4", "2023-11-20", "校学生会", "XJBLS20233201", "获得校级辩论赛团体冠军", "1006"},
                {"国家励志奖学金", "1", "1", "2023-10-10", "教育部", "GJLZ2023A1235", "家庭困难但成绩优异的学生奖励", "1007"}
            };
            
            for (int i = 0; i < honorsData.length; i++) {
                // 过滤条件匹配检查
                if (honorType != null && !honorsData[i][1].equals(honorType)) {
                    continue; // 跳过不匹配类型的记录
                }
                
                if (keyword != null && !keyword.isEmpty()) {
                    boolean match = false;
                    if (honorsData[i][0].contains(keyword)) match = true; // 标题匹配
                    // 查找对应学生名字是否匹配
                    for (Map<String, Object> student : students) {
                        if (student.get("personId").toString().equals(honorsData[i][7])) {
                            if (student.get("name").toString().contains(keyword)) {
                                match = true;
                                break;
                            }
                        }
                    }
                    if (!match) continue; // 不匹配关键词，跳过
                }
                
                Map<String, Object> honor = new HashMap<>();
                honor.put("honorId", 2000 + i);
                honor.put("title", honorsData[i][0]);
                honor.put("honorType", honorsData[i][1]);
                honor.put("level", honorsData[i][2]);
                honor.put("awardDate", honorsData[i][3]);
                honor.put("issuer", honorsData[i][4]);
                honor.put("certificateNumber", honorsData[i][5]);
                honor.put("description", honorsData[i][6]);
                
                // 添加学生信息
                String studentId = honorsData[i][7];
                for (Map<String, Object> student : students) {
                    if (student.get("personId").toString().equals(studentId)) {
                        honor.put("student", student);
                        break;
                    }
                }
                
                honors.add(honor);
            }
            
            return new DataResponse(0, honors, "查询成功(模拟数据)");
        }
        else if (url.equals("/api/honor/delete")) {
            // 模拟删除荣誉响应
            Integer honorId = (Integer) request.get("honorId");
            System.out.println("模拟删除荣誉，ID: " + honorId);
            return new DataResponse(0, null, "删除成功(模拟数据)");
        }
        
        // 默认返回成功响应
        return new DataResponse(0, null, "操作成功(模拟数据)");
    }

    /**
     *  MyTreeNode requestTreeNode(String url, DataRequest request) 获取树节点对象
     * @param url  Web请求的Url 对用后的 RequestMapping
     * @param request 请求参数对象
     * @return MyTreeNode 返回后台返回数据
     */
    public static MyTreeNode requestTreeNode(String url, DataRequest request){
        HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(URI.create(serverUrl + url))
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(request)))
                .headers("Content-Type", "application/json")
                .headers("Authorization", "Bearer "+AppStore.getJwt().getToken())
                .build();
        HttpClient client = HttpClient.newHttpClient();
        try {
            HttpResponse<String>  response = client.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            if(response.statusCode() == 200) {
                return gson.fromJson(response.body(), MyTreeNode.class);
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static List<MyTreeNode> requestTreeNodeList(String url, DataRequest request){
        HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(URI.create(serverUrl + url))
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(request)))
                .headers("Content-Type", "application/json")
                .headers("Authorization", "Bearer "+AppStore.getJwt().getToken())
                .build();
        HttpClient client = HttpClient.newHttpClient();
        try {
            HttpResponse<String>  response = client.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            if(response.statusCode() == 200) {
                List<Map<String,Object>> list = gson.fromJson(response.body(),List.class);
                List<MyTreeNode> rList = new ArrayList<>();
                for (Map<String, Object> stringObjectMap : list) {
                    rList.add(new MyTreeNode(stringObjectMap));
                }
                return rList;
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     *  List<OptionItem> requestOptionItemList(String url, DataRequest request) 获取OptionItemList对象
     * @param url  Web请求的Url 对用后的 RequestMapping
     * @param request 请求参数对象
     * @return List<OptionItem> 返回后台返回数据
     */
    public static List<OptionItem> requestOptionItemList(String url, DataRequest request){
        HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(URI.create(serverUrl + url))
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(request)))
                .headers("Content-Type", "application/json")
                .headers("Authorization", "Bearer "+AppStore.getJwt().getToken())
                .build();
        HttpClient client = HttpClient.newHttpClient();
        try {
            HttpResponse<String>  response = client.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            if(response.statusCode() == 200) {
                OptionItemList o = gson.fromJson(response.body(), OptionItemList.class);
                return o.getItemList();
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     *   List<OptionItem> getDictionaryOptionItemList(String code) 获取数据字典OptionItemList对象
     * @param code  数据字典类型吗
     * @param
     * @return List<OptionItem> 返回后台返回数据
     */
    public static  List<OptionItem> getDictionaryOptionItemList(String code) {
        DataRequest req = new DataRequest();
        req.add("code", code);
        return requestOptionItemList("/api/base/getDictionaryOptionItemList",req);
    }

    /**
     *  byte[] requestByteData(String url, DataRequest request) 获取byte[] 对象 下载数据文件等
     * @param url  Web请求的Url 对用后的 RequestMapping
     * @param request 请求参数对象
     * @return List<OptionItem> 返回后台返回数据
     */
    public static byte[] requestByteData(String url, DataRequest request){
        HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(URI.create(serverUrl + url))
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(request)))
                .headers("Content-Type", "application/json")
                .headers("Authorization", "Bearer "+AppStore.getJwt().getToken())
                .build();
        HttpClient client = HttpClient.newHttpClient();
        try {
            HttpResponse<byte[]>  response = client.send(httpRequest, HttpResponse.BodyHandlers.ofByteArray());
            if(response.statusCode() == 200) {
                return response.body();
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * DataResponse uploadFile(String fileName,String remoteFile) 上传数据文件
     * @param fileName  本地文件名
     * @param remoteFile 远程文件路径
     * @return 上传操作信息
     */
    public static DataResponse uploadFile(String uri,String fileName,String remoteFile)  {
        try {
            Path file = Path.of(fileName);
            HttpClient client = HttpClient.newBuilder().build();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(serverUrl+uri+"?uploader=HttpTestApp&remoteFile="+remoteFile + "&fileName="
                            + file.getFileName()))
                    .POST(HttpRequest.BodyPublishers.ofFile(file))
                    .headers("Authorization", "Bearer " + AppStore.getJwt().getToken())
                    .build();
            HttpResponse<String>  response = client.send(request, HttpResponse.BodyHandlers.ofString());
            if(response.statusCode() == 200) {
                return gson.fromJson(response.body(), DataResponse.class);
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * DataResponse importData(String url, String fileName, String paras) 导入数据文件
     * @param url  Web请求的Url 对用后的 RequestMapping
     * @param fileName 本地文件名
     * @param paras  上传参数
     * @return 导入结果信息
     */
    public static DataResponse importData(String url, String fileName, String paras)  {
        try {
            Path file = Path.of(fileName);
            String urlStr = serverUrl+url+"?uploader=HttpTestApp&fileName=" + file.getFileName() ;
            if(paras != null && !paras.isEmpty())
                urlStr += "&"+paras;
            HttpClient client = HttpClient.newBuilder().build();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(urlStr))
                    .POST(HttpRequest.BodyPublishers.ofFile(file))
                    .headers("Authorization", "Bearer " + AppStore.getJwt().getToken())
                    .build();
            HttpResponse<String>  response = client.send(request, HttpResponse.BodyHandlers.ofString());
            if(response.statusCode() == 200) {
                return gson.fromJson(response.body(), DataResponse.class);
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 获取模拟菜单响应
     */
    private static DataResponse getMockMenuResponse() {
        List<Map<String, Object>> menuList = new ArrayList<>();

        // 基础数据
        Map<String, Object> baseMenu = new HashMap<>();
        baseMenu.put("id", 1);
        baseMenu.put("title", "基础数据");
        baseMenu.put("path", null);
        baseMenu.put("icon", "fa-database");
        baseMenu.put("component", null);
        baseMenu.put("permission", null);
        baseMenu.put("sort", 1);
        baseMenu.put("parentId", 0);
        baseMenu.put("enableStatus", 1);
        baseMenu.put("delStatus", 0);
        baseMenu.put("subMenus", new ArrayList<>());
        menuList.add(baseMenu);

        // 学生管理
        Map<String, Object> studentMenu = new HashMap<>();
        studentMenu.put("id", 2);
        studentMenu.put("title", "学生管理");
        studentMenu.put("path", "student-manage");
        studentMenu.put("icon", "fa-users");
        studentMenu.put("component", "honor");
        studentMenu.put("permission", null);
        studentMenu.put("sort", 1);
        studentMenu.put("parentId", 1);
        studentMenu.put("enableStatus", 1);
        studentMenu.put("delStatus", 0);
        ((List<Map<String, Object>>) baseMenu.get("subMenus")).add(studentMenu);
        
        // 荣誉管理
        Map<String, Object> honorMenu = new HashMap<>();
        honorMenu.put("id", 3);
        honorMenu.put("title", "荣誉管理");
        honorMenu.put("path", "honor-manage");
        honorMenu.put("icon", "fa-trophy");
        honorMenu.put("component", "honor");
        honorMenu.put("permission", null);
        honorMenu.put("sort", 2);
        honorMenu.put("parentId", 1);
        honorMenu.put("enableStatus", 1);
        honorMenu.put("delStatus", 0);
        ((List<Map<String, Object>>) baseMenu.get("subMenus")).add(honorMenu);
        
        // 教学管理
        Map<String, Object> teachMenu = new HashMap<>();
        teachMenu.put("id", 4);
        teachMenu.put("title", "教学管理");
        teachMenu.put("path", null);
        teachMenu.put("icon", "fa-book");
        teachMenu.put("component", null);
        teachMenu.put("permission", null);
        teachMenu.put("sort", 2);
        teachMenu.put("parentId", 0);
        teachMenu.put("enableStatus", 1);
        teachMenu.put("delStatus", 0);
        teachMenu.put("subMenus", new ArrayList<>());
        menuList.add(teachMenu);
        
        // 课程管理
        Map<String, Object> courseMenu = new HashMap<>();
        courseMenu.put("id", 5);
        courseMenu.put("title", "课程管理");
        courseMenu.put("path", "course-manage");
        courseMenu.put("icon", "fa-graduation-cap");
        courseMenu.put("component", "honor");
        courseMenu.put("permission", null);
        courseMenu.put("sort", 1);
        courseMenu.put("parentId", 4);
        courseMenu.put("enableStatus", 1);
        courseMenu.put("delStatus", 0);
        ((List<Map<String, Object>>) teachMenu.get("subMenus")).add(courseMenu);
        
        // 学生服务
        Map<String, Object> studentServiceMenu = new HashMap<>();
        studentServiceMenu.put("id", 6);
        studentServiceMenu.put("title", "学生服务");
        studentServiceMenu.put("path", null);
        studentServiceMenu.put("icon", "fa-user-circle");
        studentServiceMenu.put("component", null);
        studentServiceMenu.put("permission", null);
        studentServiceMenu.put("sort", 3);
        studentServiceMenu.put("parentId", 0);
        studentServiceMenu.put("enableStatus", 1);
        studentServiceMenu.put("delStatus", 0);
        studentServiceMenu.put("subMenus", new ArrayList<>());
        menuList.add(studentServiceMenu);
        
        // 请假管理
        Map<String, Object> leaveMenu = new HashMap<>();
        leaveMenu.put("id", 7);
        leaveMenu.put("title", "请假管理");
        leaveMenu.put("path", "leave-manage");
        leaveMenu.put("icon", "fa-calendar-check-o");
        leaveMenu.put("component", "leave");
        leaveMenu.put("permission", null);
        leaveMenu.put("sort", 1);
        leaveMenu.put("parentId", 6);
        leaveMenu.put("enableStatus", 1);
        leaveMenu.put("delStatus", 0);
        ((List<Map<String, Object>>) studentServiceMenu.get("subMenus")).add(leaveMenu);
        
        // 消费记录
        Map<String, Object> expenseMenu = new HashMap<>();
        expenseMenu.put("id", 8);
        expenseMenu.put("title", "消费记录");
        expenseMenu.put("path", "expense-manage");
        expenseMenu.put("icon", "fa-credit-card");
        expenseMenu.put("component", "expense");
        expenseMenu.put("permission", null);
        expenseMenu.put("sort", 2);
        expenseMenu.put("parentId", 6);
        expenseMenu.put("enableStatus", 1);
        expenseMenu.put("delStatus", 0);
        ((List<Map<String, Object>>) studentServiceMenu.get("subMenus")).add(expenseMenu);

        // 创新成就
        Map<String, Object> innovationMenu = new HashMap<>();
        innovationMenu.put("id", 9);
        innovationMenu.put("title", "创新成就");
        innovationMenu.put("path", "innovation-manage");
        innovationMenu.put("icon", "fa-lightbulb-o");
        innovationMenu.put("component", "innovation");
        innovationMenu.put("permission", null);
        innovationMenu.put("sort", 3);
        innovationMenu.put("parentId", 6);
        innovationMenu.put("enableStatus", 1);
        innovationMenu.put("delStatus", 0);
        ((List<Map<String, Object>>) studentServiceMenu.get("subMenus")).add(innovationMenu);
        
        return new DataResponse(0, menuList, "获取菜单成功(模拟数据)");
    }

    /**
     * 获取模拟请假数据响应
     */
    private static DataResponse getMockLeaveResponse(String url, DataRequest request) {
        System.out.println("使用模拟请假数据响应请求: " + url);
        
        if (url.equals("/api/leave/edit")) {
            // 模拟保存请假响应
            Map<String, Object> form = (Map<String, Object>) request.get("form");
            Integer leaveId = (Integer) request.get("leaveId");
            
            // 如果是更新，返回原ID；如果是新增，返回新ID
            int newId = leaveId != null ? leaveId : 3000 + (int)(Math.random() * 1000);
            System.out.println("模拟请假保存成功，ID: " + newId);
            return new DataResponse(0, newId, "保存成功(模拟数据)");
        } 
        else if (url.equals("/api/leave/list")) {
            // 模拟请假列表数据
            List<Map<String, Object>> leaves = new ArrayList<>();
            
            // 获取过滤条件
            String keyword = (String) request.get("keyword");
            String leaveType = null;
            String status = null;
            if (request.get("leaveType") != null) {
                leaveType = request.get("leaveType").toString();
            }
            if (request.get("status") != null) {
                status = request.get("status").toString();
            }
            
            // 创建模拟学生数据
            DataResponse studentsResponse = getMockStudentResponse();
            List<Map<String, Object>> students = (List<Map<String, Object>>) studentsResponse.getData();
            
            // 默认请假数据
            String[][] leavesData = {
                {"1", "2024-05-01 08:00:00", "2024-05-03 18:00:00", "家中", "13812345678", "家中有事需处理", "2", "张主任", "2024-04-28 14:30:00", "批准，注意安全", "1001"},
                {"2", "2024-05-10 08:00:00", "2024-05-12 18:00:00", "医院", "13812345679", "感冒发烧需治疗", "2", "李主任", "2024-05-08 09:15:00", "批准，注意休息", "1002"},
                {"1", "2024-05-15 08:00:00", "2024-05-15 18:00:00", "学校周边", "13812345680", "参加社区志愿活动", "1", null, null, null, "1003"},
                {"3", "2024-05-20 08:00:00", "2024-05-25 18:00:00", "科技园", "13812345681", "参加创新创业大赛", "2", "王主任", "2024-05-18 16:45:00", "批准，祝比赛顺利", "1004"},
                {"2", "2024-05-30 08:00:00", "2024-06-01 18:00:00", "市中心医院", "13812345682", "牙疼需要治疗", "3", "赵主任", "2024-05-29 10:20:00", "不批准，可以周末去", "1005"},
                {"1", "2024-06-05 08:00:00", "2024-06-06 18:00:00", "家中", "13812345683", "家里老人生病", "1", null, null, null, "1006"}
            };
            
            for (int i = 0; i < leavesData.length; i++) {
                // 过滤条件匹配检查
                if (leaveType != null && !leavesData[i][0].equals(leaveType)) {
                    continue; // 跳过不匹配类型的记录
                }
                
                if (status != null && !leavesData[i][6].equals(status)) {
                    continue; // 跳过不匹配状态的记录
                }
                
                if (keyword != null && !keyword.isEmpty()) {
                    boolean match = false;
                    if (leavesData[i][5].contains(keyword) || leavesData[i][3].contains(keyword)) match = true; // 原因或目的地匹配
                    // 查找对应学生名字是否匹配
                    for (Map<String, Object> student : students) {
                        if (student.get("personId").toString().equals(leavesData[i][10])) {
                            if (student.get("name").toString().contains(keyword)) {
                                match = true;
                                break;
                            }
                        }
                    }
                    if (!match) continue; // 不匹配关键词，跳过
                }
                
                Map<String, Object> leave = new HashMap<>();
                leave.put("leaveId", 3000 + i);
                leave.put("leaveType", leavesData[i][0]);
                leave.put("startTime", leavesData[i][1]);
                leave.put("endTime", leavesData[i][2]);
                leave.put("destination", leavesData[i][3]);
                leave.put("contact", leavesData[i][4]);
                leave.put("reason", leavesData[i][5]);
                leave.put("status", leavesData[i][6]);
                leave.put("approver", leavesData[i][7]);
                leave.put("approveTime", leavesData[i][8]);
                leave.put("approveComment", leavesData[i][9]);
                
                // 添加学生信息
                String studentId = leavesData[i][10];
                for (Map<String, Object> student : students) {
                    if (student.get("personId").toString().equals(studentId)) {
                        leave.put("student", student);
                        break;
                    }
                }
                
                leaves.add(leave);
            }
            
            return new DataResponse(0, leaves, "查询成功(模拟数据)");
        }
        else if (url.equals("/api/leave/approve")) {
            // 模拟审批请假响应
            Integer leaveId = (Integer) request.get("leaveId");
            String status = (String) request.get("status");
            System.out.println("模拟审批请假，ID: " + leaveId + ", 状态: " + status);
            return new DataResponse(0, null, "审批成功(模拟数据)");
        }
        else if (url.equals("/api/leave/delete")) {
            // 模拟删除请假响应
            Integer leaveId = (Integer) request.get("leaveId");
            System.out.println("模拟删除请假，ID: " + leaveId);
            return new DataResponse(0, null, "删除成功(模拟数据)");
        }
        
        // 默认返回成功响应
        return new DataResponse(0, null, "操作成功(模拟数据)");
    }

    /**
     * 获取模拟消费日志数据响应
     */
    private static DataResponse getMockExpenseLogResponse(String url, DataRequest request) {
        System.out.println("使用模拟消费日志数据响应请求: " + url);
        
        if (url.equals("/api/expense/edit")) {
            // 模拟保存消费日志响应
            Map<String, Object> form = (Map<String, Object>) request.get("form");
            Integer logId = (Integer) request.get("logId");
            
            // 如果是更新，返回原ID；如果是新增，返回新ID
            int newId = logId != null ? logId : 4000 + (int)(Math.random() * 1000);
            System.out.println("模拟消费日志保存成功，ID: " + newId);
            return new DataResponse(0, newId, "保存成功(模拟数据)");
        } 
        else if (url.equals("/api/expense/list")) {
            // 模拟消费日志列表数据
            List<Map<String, Object>> expenseLogs = new ArrayList<>();
            
            // 获取过滤条件
            String keyword = (String) request.get("keyword");
            String expenseType = null;
            if (request.get("expenseType") != null) {
                expenseType = request.get("expenseType").toString();
            }
            
            // 创建模拟学生数据
            DataResponse studentsResponse = getMockStudentResponse();
            List<Map<String, Object>> students = (List<Map<String, Object>>) studentsResponse.getData();
            
            // 默认消费日志数据
            String[][] logsData = {
                {"2024-05-01 12:30:00", "15.5", "1", "学校食堂", "午餐消费", "校园卡", "1001"},
                {"2024-05-01 18:20:00", "18.0", "1", "学校食堂", "晚餐消费", "校园卡", "1001"},
                {"2024-05-02 08:15:00", "10.0", "1", "学校食堂", "早餐消费", "校园卡", "1002"},
                {"2024-05-02 14:30:00", "25.5", "2", "校园超市", "购买日用品", "支付宝", "1002"},
                {"2024-05-03 09:45:00", "8.0", "3", "公交车站", "乘坐公交车", "现金", "1003"},
                {"2024-05-03 16:20:00", "50.0", "4", "图书馆", "购买教材", "微信支付", "1003"},
                {"2024-05-04 11:30:00", "30.0", "5", "电影院", "看电影", "微信支付", "1004"},
                {"2024-05-05 13:20:00", "45.0", "6", "医务室", "购买药品", "支付宝", "1005"}
            };
            
            for (int i = 0; i < logsData.length; i++) {
                // 过滤条件匹配检查
                if (expenseType != null && !logsData[i][2].equals(expenseType)) {
                    continue; // 跳过不匹配类型的记录
                }
                
                if (keyword != null && !keyword.isEmpty()) {
                    boolean match = false;
                    if (logsData[i][4].contains(keyword) || logsData[i][3].contains(keyword)) match = true; // 描述或地点匹配
                    // 查找对应学生名字是否匹配
                    for (Map<String, Object> student : students) {
                        if (student.get("personId").toString().equals(logsData[i][6])) {
                            if (student.get("name").toString().contains(keyword)) {
                                match = true;
                                break;
                            }
                        }
                    }
                    if (!match) continue; // 不匹配关键词，跳过
                }
                
                Map<String, Object> log = new HashMap<>();
                log.put("logId", 4000 + i);
                log.put("logTime", logsData[i][0]);
                log.put("amount", Double.parseDouble(logsData[i][1]));
                log.put("expenseType", logsData[i][2]);
                log.put("location", logsData[i][3]);
                log.put("description", logsData[i][4]);
                log.put("paymentMethod", logsData[i][5]);
                
                // 添加学生信息
                String studentId = logsData[i][6];
                for (Map<String, Object> student : students) {
                    if (student.get("personId").toString().equals(studentId)) {
                        log.put("student", student);
                        break;
                    }
                }
                
                expenseLogs.add(log);
            }
            
            return new DataResponse(0, expenseLogs, "查询成功(模拟数据)");
        }
        else if (url.equals("/api/expense/delete")) {
            // 模拟删除消费日志响应
            Integer logId = (Integer) request.get("logId");
            System.out.println("模拟删除消费日志，ID: " + logId);
            return new DataResponse(0, null, "删除成功(模拟数据)");
        }
        
        // 默认返回成功响应
        return new DataResponse(0, null, "操作成功(模拟数据)");
    }

    /**
     * 获取模拟创新成就数据响应
     */
    private static DataResponse getMockInnovationResponse(String url, DataRequest request) {
        System.out.println("使用模拟创新成就数据响应请求: " + url);
        
        if (url.equals("/api/innovation/edit")) {
            // 模拟保存创新成就响应
            Map<String, Object> form = (Map<String, Object>) request.get("form");
            Integer innovationId = (Integer) request.get("innovationId");
            
            // 如果是更新，返回原ID；如果是新增，返回新ID
            int newId = innovationId != null ? innovationId : 5000 + (int)(Math.random() * 1000);
            System.out.println("模拟创新成就保存成功，ID: " + newId);
            return new DataResponse(0, newId, "保存成功(模拟数据)");
        } 
        else if (url.equals("/api/innovation/list")) {
            // 模拟创新成就列表数据
            List<Map<String, Object>> innovations = new ArrayList<>();
            
            // 获取过滤条件
            String keyword = (String) request.get("keyword");
            String innovationType = null;
            String level = null;
            String status = null;
            if (request.get("innovationType") != null) {
                innovationType = request.get("innovationType").toString();
            }
            if (request.get("level") != null) {
                level = request.get("level").toString();
            }
            if (request.get("status") != null) {
                status = request.get("status").toString();
            }
            
            // 创建模拟学生数据
            DataResponse studentsResponse = getMockStudentResponse();
            List<Map<String, Object>> students = (List<Map<String, Object>>) studentsResponse.getData();
            
            // 默认创新成就数据
            String[][] innovationsData = {
                {"校园科技创新大赛一等奖", "2", "4", "2024-04-10 10:00:00", "计算机科学与技术学院", "校科联[2024]001", "参加校园科技创新大赛并获得一等奖", "大数据分析平台", "2", "1001"},
                {"省级大学生创新创业项目", "1", "2", "2024-03-15 14:00:00", "山东省教育厅", "鲁教创新[2024]123", "参与省级大学生创新创业项目的开发与实施", "智能农业监控系统", "2", "1002"},
                {"论文发表《人工智能在教育中的应用》", "4", "3", "2024-02-20 09:00:00", "计算机应用期刊", "ISSN-12345", "在核心期刊上发表学术论文", "人工智能教育应用研究", "1", "1003"},
                {"软件著作权登记证书", "3", "1", "2024-01-05 16:30:00", "国家版权局", "软著登字第123456号", "为自主开发的软件申请了著作权保护", "学生管理系统V1.0", "2", "1004"},
                {"互联网+大学生创新创业大赛铜奖", "5", "1", "2023-12-10 11:00:00", "教育部", "互联网+[2023]789", "参加全国互联网+大赛获得铜奖", "智慧校园导航平台", "3", "1005"},
                {"实用新型专利证书", "3", "2", "2023-11-01 10:30:00", "国家知识产权局", "ZL 2023 2 0123456.X", "获得实用新型专利授权", "一种便携式太阳能充电设备", "1", "1001"}
            };
            
            for (int i = 0; i < innovationsData.length; i++) {
                // 过滤条件匹配检查
                if (innovationType != null && !innovationsData[i][1].equals(innovationType)) {
                    continue; // 跳过不匹配类型的记录
                }
                
                if (level != null && !innovationsData[i][2].equals(level)) {
                    continue; // 跳过不匹配级别的记录
                }
                
                if (status != null && !innovationsData[i][9].equals(status)) {
                    continue; // 跳过不匹配状态的记录
                }
                
                if (keyword != null && !keyword.isEmpty()) {
                    boolean match = false;
                    if (innovationsData[i][0].contains(keyword) || innovationsData[i][7].contains(keyword) || 
                        innovationsData[i][4].contains(keyword) || innovationsData[i][6].contains(keyword)) {
                        match = true; // 标题、项目名、组织或描述匹配
                    }
                    // 查找对应学生名字是否匹配
                    for (Map<String, Object> student : students) {
                        if (student.get("personId").toString().equals(innovationsData[i][9])) {
                            if (student.get("name").toString().contains(keyword)) {
                                match = true;
                                break;
                            }
                        }
                    }
                    if (!match) continue; // 不匹配关键词，跳过
                }
                
                Map<String, Object> innovation = new HashMap<>();
                innovation.put("innovationId", 5000 + i);
                innovation.put("name", innovationsData[i][7]);
                innovation.put("innovationType", innovationsData[i][1]);
                innovation.put("level", innovationsData[i][2]);
                innovation.put("achieveTime", innovationsData[i][3]);
                innovation.put("organization", innovationsData[i][4]);
                innovation.put("certificateNumber", innovationsData[i][5]);
                innovation.put("description", innovationsData[i][6]);
                innovation.put("status", innovationsData[i][8]);
                
                // 添加学生信息
                String studentId = innovationsData[i][9];
                for (Map<String, Object> student : students) {
                    if (student.get("personId").toString().equals(studentId)) {
                        innovation.put("student", student);
                        break;
                    }
                }
                
                innovations.add(innovation);
            }
            
            return new DataResponse(0, innovations, "查询成功(模拟数据)");
        }
        else if (url.equals("/api/innovation/approve")) {
            // 模拟审批创新成就响应
            Integer innovationId = (Integer) request.get("innovationId");
            String status = (String) request.get("status");
            System.out.println("模拟审批创新成就，ID: " + innovationId + ", 状态: " + status);
            return new DataResponse(0, null, "审批成功(模拟数据)");
        }
        else if (url.equals("/api/innovation/delete")) {
            // 模拟删除创新成就响应
            Integer innovationId = (Integer) request.get("innovationId");
            System.out.println("模拟删除创新成就，ID: " + innovationId);
            return new DataResponse(0, null, "删除成功(模拟数据)");
        }
        
        // 默认返回成功响应
        return new DataResponse(0, null, "操作成功(模拟数据)");
    }
}