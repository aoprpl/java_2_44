package com.teach.javafx.request;

import com.teach.javafx.AppStore;
import com.google.gson.Gson;

import java.io.IOException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.URI;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.List;
import java.nio.file.Path;
import java.util.Map;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.nio.file.Files;

/**
 * HttpRequestUtil 后台请求实例程序，主要实践向后台发送请求的方法
 *  static boolean isLocal 业务处理程序实现方式 false java-server实现 前端程序通过下面的方法把数据发送后台程序，后台返回前端需要的数据，true 本地方式 业务处理 在SQLiteJDBC 实现
 *  String serverUrl = "http://localhost:9090" 后台服务的机器地址和端口号
 */
public class HttpRequestUtil {
    private static final Gson gson = new Gson();
    private static final HttpClient client = HttpClient.newHttpClient();
    public static String serverUrl = "http://localhost:22223";
//    public static String serverUrl = "http://202.194.7.29:22222";
    
    /**
     * 测试服务器连接
     * @return 连接是否成功
     */
    public static boolean testConnection() {
        try {
            HttpRequest httpRequest = HttpRequest.newBuilder()
                    .uri(URI.create(serverUrl + "/api/base/ping"))
                    .GET()
                    .timeout(java.time.Duration.ofSeconds(5))
                    .build();
            
            HttpResponse<String> response = client.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            System.out.println("服务器连接测试结果: " + response.statusCode());
            
            // 403表示服务器拒绝访问但服务器可达，视为连接成功
            // 如果需要使用JWT验证的接口，登录成功后会自动添加JWT令牌
            return (response.statusCode() == 200 || response.statusCode() == 403);
        } catch (Exception e) {
            System.out.println("服务器连接失败: " + e.getMessage());
            return false;
        }
    }

    /**
     *  应用关闭是需要做关闭处理
     */
    public static void close(){
    }

    /**
     * String login(LoginRequest request)  用户登录请求实现
     * @param request  username 登录账号 password 登录密码
     * @return  返回null 登录成功 AppStore注册登录账号信息 非空，登录错误信息
     */
    public static String login(LoginRequest request){
        System.out.println("尝试登录，用户名: " + request.getUsername());
        System.out.println("发送登录请求到: " + serverUrl + "/auth/login");
        
        HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(URI.create(serverUrl + "/auth/login"))
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(request)))
                .headers("Content-Type", "application/json")
                .build();
        try {
            HttpResponse<String> response = client.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            System.out.println("登录响应状态码: " + response.statusCode());
            System.out.println("登录响应内容: " + response.body());
            
            if (response.statusCode() == 200) {
                try {
                    JwtResponse jwt = gson.fromJson(response.body(), JwtResponse.class);
                    if (jwt != null && jwt.getToken() != null && !jwt.getToken().isEmpty()) {
                        AppStore.setJwt(jwt);
                        // 设置用户名用于请求
                        if (jwt.getUsername() == null || jwt.getUsername().isEmpty()) {
                            jwt.setUsername(request.getUsername());
                        }
                        System.out.println("登录成功，用户: " + jwt.getUsername());
                        System.out.println("JWT Token: " + jwt.getToken().substring(0, Math.min(20, jwt.getToken().length())) + "...");
                        System.out.println("用户角色: " + jwt.getRole());
                        return null;
                    } else {
                        System.out.println("登录响应解析失败，JWT为空或无效: " + response.body());
                        return "登录成功但获取授权令牌失败";
                    }
                } catch (Exception e) {
                    System.out.println("解析JWT响应失败: " + e.getMessage());
                    System.out.println("原始响应内容: " + response.body());
                    e.printStackTrace();
                    return "登录响应格式无效: " + e.getMessage();
                }
            } else if (response.statusCode() == 401) {
                System.out.println("登录失败: 用户名或密码不正确");
                return "用户名或密码不存在！";
            } else {
                System.out.println("登录失败，服务器返回状态码: " + response.statusCode());
                System.out.println("响应内容: " + response.body());
                return "登录失败，服务器返回状态: " + response.statusCode() + "\n响应内容: " + response.body();
            }
        } catch (IOException | InterruptedException e) {
            System.out.println("登录请求发生异常: " + e.getMessage());
            e.printStackTrace();
            return "登录请求失败: " + e.getMessage();
        }
    }

    /**
     * DataResponse request(String url, DataRequest request) 一般数据请求业务的实现
     * @param url  Web请求的Url 对用后的 RequestMapping
     * @param request 请求参数对象
     * @return DataResponse 返回后台返回数据
     */
    public static DataResponse request(String url, DataRequest request) {
        try {
            System.out.println("url=" + url + "    request=" + (request != null ? request.toString() : "null"));
            String requestJson = gson.toJson(request);

            // 构建请求
            HttpRequest.Builder requestBuilder = HttpRequest.newBuilder()
                    .uri(URI.create(serverUrl + url))
                    .timeout(java.time.Duration.ofSeconds(10))
                    .header("Content-Type", "application/json");
                    
            // 添加授权头，如果JWT令牌存在
            if (AppStore.getJwt() != null && AppStore.getJwt().getToken() != null) {
                String token = AppStore.getJwt().getToken();
                System.out.println("添加授权头: Bearer " + token.substring(0, Math.min(10, token.length())) + "...");
                requestBuilder.header("Authorization", "Bearer " + token);
            } else {
                System.out.println("警告: 未添加授权头，JWT令牌不存在");
            }
            
            HttpRequest httpRequest = requestBuilder
                    .POST(HttpRequest.BodyPublishers.ofString(requestJson))
                    .build();

            // 发送请求并获取响应
            HttpResponse<String> response = client.send(httpRequest, HttpResponse.BodyHandlers.ofString());

            // 添加详细的响应日志
            System.out.println("原始响应状态码: " + response.statusCode());
            System.out.println("原始响应内容: " + response.body());
            
            if (response.statusCode() == 200) {
                try {
                    DataResponse dataResponse = gson.fromJson(response.body(), DataResponse.class);
                    System.out.println("解析后的响应: " + dataResponse);
                    return dataResponse;
                } catch (Exception e) {
                    System.out.println("解析响应失败: " + e.getMessage());
                    e.printStackTrace();
                    // 尝试直接返回原始信息
                    DataResponse errorResponse = new DataResponse();
                    errorResponse.setCode(-1);
                    errorResponse.setMsg("响应解析失败: " + e.getMessage() + ", 原始数据: " + response.body());
                    return errorResponse;
                }
            } else if (response.statusCode() == 403) {
                System.out.println("授权失败(403 Forbidden): " + response.body());
                DataResponse errorResponse = new DataResponse();
                errorResponse.setCode(403);
                errorResponse.setMsg("无访问权限，请确保您已正确登录并有访问该资源的权限。您可能需要重新登录。");
                return errorResponse;
            } else {
                System.out.println("HTTP请求失败，状态码: " + response.statusCode());
                DataResponse errorResponse = new DataResponse();
                errorResponse.setCode(-1);
                errorResponse.setMsg("HTTP请求失败，状态码: " + response.statusCode());
                return errorResponse;
            }
        } catch (Exception e) {
            System.out.println("请求异常: " + e.getMessage());
            e.printStackTrace();
            DataResponse errorResponse = new DataResponse();
            errorResponse.setCode(-1);
            errorResponse.setMsg("请求发生异常: " + e.getMessage());
            return errorResponse;
        }
    }

    /**
     *  MyTreeNode requestTreeNode(String url, DataRequest request) 获取树节点对象
     * @param url  Web请求的Url 对用后的 RequestMapping
     * @param request 请求参数对象
     * @return MyTreeNode 返回后台返回数据
     */
    public static MyTreeNode requestTreeNode(String url, DataRequest request){
        HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(URI.create(serverUrl + url))
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(request)))
                .headers("Content-Type", "application/json")
                .headers("Authorization", "Bearer "+AppStore.getJwt().getToken())
                .build();
        HttpClient client = HttpClient.newHttpClient();
        try {
            HttpResponse<String>  response = client.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            if(response.statusCode() == 200) {
                return gson.fromJson(response.body(), MyTreeNode.class);
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static List<MyTreeNode> requestTreeNodeList(String url, DataRequest request){
        HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(URI.create(serverUrl + url))
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(request)))
                .headers("Content-Type", "application/json")
                .headers("Authorization", "Bearer "+AppStore.getJwt().getToken())
                .build();
        HttpClient client = HttpClient.newHttpClient();
        try {
            HttpResponse<String>  response = client.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            if(response.statusCode() == 200) {
                List<Map<String,Object>> list = gson.fromJson(response.body(),List.class);
                List<MyTreeNode> rList = new ArrayList<>();
                for (Map<String, Object> stringObjectMap : list) {
                    rList.add(new MyTreeNode(stringObjectMap));
                }
                return rList;
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     *  List<OptionItem> requestOptionItemList(String url, DataRequest request) 获取OptionItemList对象
     * @param url  Web请求的Url 对用后的 RequestMapping
     * @param request 请求参数对象
     * @return List<OptionItem> 返回后台返回数据
     */
    public static List<OptionItem> requestOptionItemList(String url, DataRequest request){
        HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(URI.create(serverUrl + url))
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(request)))
                .headers("Content-Type", "application/json")
                .headers("Authorization", "Bearer "+AppStore.getJwt().getToken())
                .build();
        HttpClient client = HttpClient.newHttpClient();
        try {
            HttpResponse<String>  response = client.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            if(response.statusCode() == 200) {
                OptionItemList o = gson.fromJson(response.body(), OptionItemList.class);
                return o.getItemList();
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     *   List<OptionItem> getDictionaryOptionItemList(String code) 获取数据字典OptionItemList对象
     * @param code  数据字典类型吗
     * @param
     * @return List<OptionItem> 返回后台返回数据
     */
    public static  List<OptionItem> getDictionaryOptionItemList(String code) {
        DataRequest req = new DataRequest();
        req.add("code", code);
        return requestOptionItemList("/api/base/getDictionaryOptionItemList",req);
    }

    /**
     *  byte[] requestByteData(String url, DataRequest request) 获取byte[] 对象 下载数据文件等
     * @param url  Web请求的Url 对用后的 RequestMapping
     * @param request 请求参数对象
     * @return List<OptionItem> 返回后台返回数据
     */
    public static byte[] requestByteData(String url, DataRequest request){
        HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(URI.create(serverUrl + url))
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(request)))
                .headers("Content-Type", "application/json")
                .headers("Authorization", "Bearer "+AppStore.getJwt().getToken())
                .build();
        HttpClient client = HttpClient.newHttpClient();
        try {
            HttpResponse<byte[]>  response = client.send(httpRequest, HttpResponse.BodyHandlers.ofByteArray());
            if(response.statusCode() == 200) {
                return response.body();
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * DataResponse uploadFile(String uri,String fileName,String remoteFile) 上传数据文件
     * @param fileName  本地文件名
     * @param remoteFile 远程文件路径
     * @return 上传操作信息
     */
    public static DataResponse uploadFile(String uri,String fileName,String remoteFile)  {
        try {
            System.out.println("开始上传文件...");
            System.out.println("URI: " + uri);
            System.out.println("本地文件: " + fileName);
            System.out.println("远程文件: " + remoteFile);
            
            Path file = Path.of(fileName);
            if (!Files.exists(file)) {
                System.out.println("错误: 本地文件不存在");
                DataResponse errorResponse = new DataResponse();
                errorResponse.setCode(1);
                errorResponse.setMsg("本地文件不存在");
                return errorResponse;
            }
            
            if (!Files.isReadable(file)) {
                System.out.println("错误: 本地文件不可读");
                DataResponse errorResponse = new DataResponse();
                errorResponse.setCode(1);
                errorResponse.setMsg("本地文件不可读");
                return errorResponse;
            }
            
            // 检查JWT令牌
            if (AppStore.getJwt() == null || AppStore.getJwt().getToken() == null) {
                System.out.println("错误: JWT令牌不存在");
                DataResponse errorResponse = new DataResponse();
                errorResponse.setCode(1);
                errorResponse.setMsg("请先登录系统");
                return errorResponse;
            }
            
            // 检查文件大小
            long fileSize = Files.size(file);
            System.out.println("文件大小: " + fileSize + " bytes");
            if (fileSize > 10 * 1024 * 1024) { // 10MB
                System.out.println("错误: 文件太大");
                DataResponse errorResponse = new DataResponse();
                errorResponse.setCode(1);
                errorResponse.setMsg("文件大小超过限制（最大10MB）");
                return errorResponse;
            }
            
            // 检查文件格式
            String fileNameStr = file.getFileName().toString().toLowerCase();
            if (!fileNameStr.endsWith(".jpg") && !fileNameStr.endsWith(".jpeg")) {
                System.out.println("错误: 不支持的文件格式");
                DataResponse errorResponse = new DataResponse();
                errorResponse.setCode(1);
                errorResponse.setMsg("只支持JPG格式的图片");
                return errorResponse;
            }
            
            String urlStr = serverUrl + uri + "?uploader=HttpTestApp&remoteFile=" + remoteFile + "&fileName=" + file.getFileName();
            System.out.println("上传URL: " + urlStr);
            
            HttpClient client = HttpClient.newBuilder().build();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(urlStr))
                    .POST(HttpRequest.BodyPublishers.ofFile(file))
                    .headers("Authorization", "Bearer " + AppStore.getJwt().getToken())
                    .build();
                    
            System.out.println("发送上传请求...");
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            System.out.println("服务器响应状态码: " + response.statusCode());
            System.out.println("服务器响应内容: " + response.body());
            
            if(response.statusCode() == 200) {
                return gson.fromJson(response.body(), DataResponse.class);
            } else if(response.statusCode() == 403) {
                DataResponse errorResponse = new DataResponse();
                errorResponse.setCode(1);
                errorResponse.setMsg("无权限上传文件，请确保您已登录并有上传权限");
                return errorResponse;
            } else {
                DataResponse errorResponse = new DataResponse();
                errorResponse.setCode(1);
                errorResponse.setMsg("上传失败，服务器返回状态码: " + response.statusCode());
                return errorResponse;
            }
        } catch (IOException | InterruptedException e) {
            System.out.println("上传过程发生异常: " + e.getMessage());
            e.printStackTrace();
            DataResponse errorResponse = new DataResponse();
            errorResponse.setCode(1);
            errorResponse.setMsg("上传失败: " + e.getMessage());
            return errorResponse;
        }
    }

    /**
     * DataResponse importData(String url, String fileName, String paras) 导入数据文件
     * @param url  Web请求的Url 对用后的 RequestMapping
     * @param fileName 本地文件名
     * @param paras  上传参数
     * @return 导入结果信息
     */
    public static DataResponse importData(String url, String fileName, String paras)  {
        try {
            Path file = Path.of(fileName);
            String urlStr = serverUrl+url+"?uploader=HttpTestApp&fileName=" + file.getFileName() ;
            if(paras != null && !paras.isEmpty())
                urlStr += "&"+paras;
            HttpClient client = HttpClient.newBuilder().build();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(urlStr))
                    .POST(HttpRequest.BodyPublishers.ofFile(file))
                    .headers("Authorization", "Bearer " + AppStore.getJwt().getToken())
                    .build();
            HttpResponse<String>  response = client.send(request, HttpResponse.BodyHandlers.ofString());
            if(response.statusCode() == 200) {
                return gson.fromJson(response.body(), DataResponse.class);
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
        return null;
    }
}