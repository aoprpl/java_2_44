package com.teach.javafx.controller;

import com.teach.javafx.controller.base.MessageDialog;
import com.teach.javafx.request.DataRequest;
import com.teach.javafx.request.DataResponse;
import com.teach.javafx.request.HttpRequestUtil;
import com.teach.javafx.request.OptionItem;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.geometry.Insets;
import javafx.geometry.Pos;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
/**
 * 学生请假管理控制器
 */
public class LeaveController {
    // 查询和列表展示相关组件
    @FXML
    private TextField keywordTextField;
    
    @FXML
    private ComboBox<OptionItem> leaveTypeComboBox;
    
    @FXML
    private ComboBox<OptionItem> statusComboBox;
    
    @FXML
    private TableView<Map<String, Object>> dataTableView;
    
    @FXML
    private TableColumn<Map<String, Object>, String> studentNameColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> studentNumColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> leaveTypeColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> startTimeColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> endTimeColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> destinationColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> statusColumn;
    
    // 详情编辑相关组件
    @FXML
    private TextField studentField;
    
    @FXML
    private ComboBox<OptionItem> typeComboBox;
    
    @FXML
    private DatePicker startDatePicker;
    
    @FXML
    private DatePicker endDatePicker;
    
    @FXML
    private TextField destinationField;
    
    @FXML
    private TextField contactField;
    
    @FXML
    private ComboBox<OptionItem> leaveStatusComboBox;
    
    @FXML
    private TextField approverField;
    
    @FXML
    private TextArea reasonArea;
    
    // 数据列表
    private ObservableList<Map<String, Object>> dataList = FXCollections.observableArrayList();
    
    // 当前选中的学生
    private Map<String, Object> selectedStudent = null;
    
    // 当前请假ID
    private Integer currentLeaveId = null;
    
    // 日期时间格式化器
    private final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private Stage editStage = null;
    
    /**
     * 初始化方法，JavaFX初始化时自动调用
     */
    @FXML
    private void initialize() {
        // 初始化表格列
        studentNameColumn.setCellValueFactory(cellData -> {
            Map<String, Object> student = (Map<String, Object>) cellData.getValue().get("student");
            if (student != null) {
                return new SimpleStringProperty(String.valueOf(student.get("name")));
            }
            return new SimpleStringProperty("");
        });
        
        studentNumColumn.setCellValueFactory(cellData -> {
            Map<String, Object> student = (Map<String, Object>) cellData.getValue().get("student");
            if (student != null) {
                return new SimpleStringProperty(String.valueOf(student.get("num")));
            }
            return new SimpleStringProperty("");
        });
        
        leaveTypeColumn.setCellValueFactory(cellData -> {
            String leaveType = String.valueOf(cellData.getValue().get("leaveType"));
            for (OptionItem item : typeComboBox.getItems()) {
                if (item.getValue().equals(leaveType)) {
                    return new SimpleStringProperty(item.getTitle());
                }
            }
            return new SimpleStringProperty(leaveType);
        });
        
        startTimeColumn.setCellValueFactory(cellData -> {
            Object value = cellData.getValue().get("startTime");
            if (value != null && !value.toString().isEmpty()) {
                try {
                    LocalDateTime dateTime = LocalDateTime.parse(value.toString(), dateTimeFormatter);
                    return new SimpleStringProperty(dateTime.format(dateTimeFormatter));
                } catch (Exception e) {
                    return new SimpleStringProperty(value.toString());
                }
            }
            return new SimpleStringProperty("");
        });
        
        endTimeColumn.setCellValueFactory(cellData -> {
            Object value = cellData.getValue().get("endTime");
            if (value != null && !value.toString().isEmpty()) {
                try {
                    LocalDateTime dateTime = LocalDateTime.parse(value.toString(), dateTimeFormatter);
                    return new SimpleStringProperty(dateTime.format(dateTimeFormatter));
                } catch (Exception e) {
                    return new SimpleStringProperty(value.toString());
                }
            }
            return new SimpleStringProperty("");
        });
        
        destinationColumn.setCellValueFactory(cellData -> 
            new SimpleStringProperty(String.valueOf(cellData.getValue().get("destination"))));
        
        statusColumn.setCellValueFactory(cellData -> {
            String status = String.valueOf(cellData.getValue().get("status"));
            for (OptionItem item : leaveStatusComboBox.getItems()) {
                if (item.getValue().equals(status)) {
                    return new SimpleStringProperty(item.getTitle());
                }
            }
            return new SimpleStringProperty(status);
        });
        
        // 添加行样式类，根据状态设置不同的背景颜色
        dataTableView.setRowFactory(tv -> {
            TableRow<Map<String, Object>> row = new TableRow<>();
            row.itemProperty().addListener((obs, oldItem, newItem) -> {
                if (newItem != null) {
                    String status = String.valueOf(newItem.get("status"));
                    // 清除所有状态样式
                    row.getStyleClass().removeAll("status-approved", "status-pending", "status-rejected");
                    
                    // 根据状态添加对应的样式类
                    if ("2".equals(status)) {
                        row.getStyleClass().add("status-approved");
                    } else if ("1".equals(status)) {
                        row.getStyleClass().add("status-pending");
                    } else if ("3".equals(status)) {
                        row.getStyleClass().add("status-rejected");
                    }
                }
            });
            return row;
        });
        
        // 绑定数据列表到表格
        dataTableView.setItems(dataList);
        
        // 表格选择事件
        dataTableView.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                displayLeaveDetails(newSelection);
            }
        });
        
        // 表格样式
        dataTableView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        
        // 初始化下拉框
        initComboBoxes();
        
        // 加载数据
        loadData();
    }
    
    /**
     * 初始化下拉框
     */
    private void initComboBoxes() {
        // 请假类型下拉框
        List<OptionItem> leaveTypes = HttpRequestUtil.getDictionaryOptionItemList("QJLX");
        
        // 如果从服务器获取的类型为空，添加一些默认值
        if (leaveTypes == null || leaveTypes.isEmpty()) {
            leaveTypes = new ArrayList<>();
            leaveTypes.add(new OptionItem(1, "1", "事假"));
            leaveTypes.add(new OptionItem(2, "2", "病假"));
            leaveTypes.add(new OptionItem(3, "3", "外出"));
            leaveTypes.add(new OptionItem(4, "4", "实习"));
            leaveTypes.add(new OptionItem(5, "5", "其他"));
        }
        
        leaveTypeComboBox.setItems(FXCollections.observableArrayList(leaveTypes));
        typeComboBox.setItems(FXCollections.observableArrayList(leaveTypes));
        
        // 请假状态下拉框
        List<OptionItem> leaveStatus = HttpRequestUtil.getDictionaryOptionItemList("QJZT");
        
        // 如果从服务器获取的状态为空，添加一些默认值
        if (leaveStatus == null || leaveStatus.isEmpty()) {
            leaveStatus = new ArrayList<>();
            leaveStatus.add(new OptionItem(1, "1", "待审批"));
            leaveStatus.add(new OptionItem(2, "2", "已批准"));
            leaveStatus.add(new OptionItem(3, "3", "已拒绝"));
            leaveStatus.add(new OptionItem(4, "4", "已销假"));
        }
        
        statusComboBox.setItems(FXCollections.observableArrayList(leaveStatus));
        leaveStatusComboBox.setItems(FXCollections.observableArrayList(leaveStatus));
        
        // 设置默认值
        if (!leaveTypes.isEmpty()) {
            leaveTypeComboBox.setValue(null); // 查询时默认不选择
            typeComboBox.setValue(leaveTypes.get(0)); // 新建时默认第一个类型
        }
        
        if (!leaveStatus.isEmpty()) {
            statusComboBox.setValue(null); // 查询时默认不选择
            leaveStatusComboBox.setValue(leaveStatus.get(0)); // 默认待审批
        }
    }
    
    /**
     * 加载请假数据
     */
    public void loadData() {
        DataRequest request = new DataRequest();
        
        String keyword = keywordTextField.getText();
        if (keyword != null && !keyword.isEmpty()) {
            request.add("keyword", keyword);
        }
        
        OptionItem selectedType = leaveTypeComboBox.getValue();
        if (selectedType != null) {
            request.add("leaveType", selectedType.getValue());
        }
        
        OptionItem selectedStatus = statusComboBox.getValue();
        if (selectedStatus != null) {
            request.add("status", selectedStatus.getValue());
        }
        
        DataResponse response = HttpRequestUtil.request("/api/leave/list", request);
        if (response != null && response.getData() != null) {
            dataList.clear();
            List<Map<String, Object>> list = (List<Map<String, Object>>) response.getData();
            dataList.addAll(list);
        }
    }
    
    /**
     * 显示请假详情
     */
    private void displayLeaveDetails(Map<String, Object> leave) {
        clearForm();
        currentLeaveId = safeGetInteger(leave, "leaveId");
        Map<String, Object> student = (Map<String, Object>) leave.get("student");
        if (student != null && studentField != null) {
            selectedStudent = student;
            String name = String.valueOf(student.get("name"));
            String num = String.valueOf(student.get("num"));
            studentField.setText(name + " (" + num + ")");
        }
        String leaveType = String.valueOf(leave.get("leaveType"));
        if (typeComboBox != null) {
            for (OptionItem item : typeComboBox.getItems()) {
                if (item.getValue().equals(leaveType)) {
                    typeComboBox.setValue(item);
                    break;
                }
            }
        }
        String startTimeStr = (String) leave.get("startTime");
        if (startTimeStr != null && !startTimeStr.isEmpty() && startDatePicker != null) {
            try {
                LocalDateTime startTime = LocalDateTime.parse(startTimeStr, dateTimeFormatter);
                startDatePicker.setValue(startTime.toLocalDate());
            } catch (DateTimeParseException e) {
                System.err.println("Invalid start time format: " + startTimeStr);
            }
        }
        String endTimeStr = (String) leave.get("endTime");
        if (endTimeStr != null && !endTimeStr.isEmpty() && endDatePicker != null) {
            try {
                LocalDateTime endTime = LocalDateTime.parse(endTimeStr, dateTimeFormatter);
                endDatePicker.setValue(endTime.toLocalDate());
            } catch (DateTimeParseException e) {
                System.err.println("Invalid end time format: " + endTimeStr);
            }
        }
        if (destinationField != null) destinationField.setText(String.valueOf(leave.get("destination")));
        if (contactField != null) contactField.setText(String.valueOf(leave.get("contact")));
        String status = String.valueOf(leave.get("status"));
        if (leaveStatusComboBox != null) {
            for (OptionItem item : leaveStatusComboBox.getItems()) {
                if (item.getValue().equals(status)) {
                    leaveStatusComboBox.setValue(item);
                    break;
                }
            }
        }
        if (approverField != null) approverField.setText(String.valueOf(leave.get("approver")));
        if (reasonArea != null) reasonArea.setText(String.valueOf(leave.get("reason")));
    }
    
    /**
     * 清空表单
     */
    private void clearForm() {
        currentLeaveId = null;
        selectedStudent = null;
        if (studentField != null) studentField.clear();
        if (typeComboBox != null && !typeComboBox.getItems().isEmpty()) typeComboBox.setValue(typeComboBox.getItems().get(0));
        if (startDatePicker != null) startDatePicker.setValue(LocalDate.now());
        if (endDatePicker != null) endDatePicker.setValue(LocalDate.now().plusDays(1));
        if (destinationField != null) destinationField.clear();
        if (contactField != null) contactField.clear();
        if (leaveStatusComboBox != null && !leaveStatusComboBox.getItems().isEmpty()) leaveStatusComboBox.setValue(leaveStatusComboBox.getItems().get(0));
        if (approverField != null) approverField.clear();
        if (reasonArea != null) reasonArea.clear();
    }
    
    /**
     * 新增按钮事件
     */
    @FXML
    private void onAddButtonClick(ActionEvent event) {
        try {
            if (editStage == null) {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/teach/javafx/leave-edit-dialog.fxml"));
                Parent root = loader.load();
                editStage = new Stage();
                editStage.setTitle("添加请假");
                editStage.initModality(Modality.APPLICATION_MODAL);
                editStage.setScene(new Scene(root));
            }
            editStage.showAndWait();
            // 弹窗关闭后刷新列表并清空表单
            loadData();
            clearForm();
        } catch (IOException e) {
            e.printStackTrace();
            MessageDialog.showDialog("打开编辑窗口失败：" + e.getMessage());
        }
    }
    
    /**
     * 清空按钮事件
     */
    @FXML
    private void onClearButtonClick(ActionEvent event) {
        clearForm();
    }
    
    /**
     * 删除按钮事件
     */
    @FXML
    private void onDeleteButtonClick(ActionEvent event) {
        Map<String, Object> selected = dataTableView.getSelectionModel().getSelectedItem();
        System.out.println("选中行数据: " + selected);
        Integer leaveId = null;
        if (selected != null) {
            leaveId = safeGetInteger(selected, "leaveId");
            System.out.println("选中行leaveId: " + leaveId);
        }
        if (leaveId == null) {
            MessageDialog.showDialog("请先选择要删除的请假记录");
            return;
        }
        int choice = MessageDialog.choiceDialog("确定要删除该请假记录吗？");
        if (choice != MessageDialog.CHOICE_YES) {
            return;
        }
        DataRequest request = new DataRequest();
        request.add("leaveId", leaveId);
        DataResponse response = HttpRequestUtil.request("/api/leave/delete", request);
        if (response != null && response.getCode() == 0) {
            MessageDialog.showDialog("删除成功");
            loadData();
            clearForm();
        } else {
            String errorMsg = response != null ? response.getMsg() : "删除失败，请稍后重试";
            MessageDialog.showDialog(errorMsg);
        }
    }
    
    /**
     * 查询按钮事件
     */
    @FXML
    private void onQueryButtonClick(ActionEvent event) {
        loadData();
    }
    
    /**
     * 保存按钮事件
     */
    @FXML
    private void onSaveButtonClick(ActionEvent event) {
        // 验证表单
        if (selectedStudent == null) {
            MessageDialog.showDialog("请选择学生");
            return;
        }
        if (startDatePicker == null || startDatePicker.getValue() == null) {
            MessageDialog.showDialog("请选择开始时间");
            return;
        }
        if (endDatePicker == null || endDatePicker.getValue() == null) {
            MessageDialog.showDialog("请选择结束时间");
            return;
        }
        if (endDatePicker.getValue().isBefore(startDatePicker.getValue())) {
            MessageDialog.showDialog("结束时间不能早于开始时间");
            return;
        }
        if (reasonArea == null || reasonArea.getText().trim().isEmpty()) {
            MessageDialog.showDialog("请填写请假原因");
            return;
        }
        // 创建请求
        DataRequest request = new DataRequest();
        Map<String, Object> form = new HashMap<>();
        Integer studentId = safeGetInteger(selectedStudent, "personId");
        form.put("studentId", studentId);
        OptionItem selectedType = typeComboBox != null ? typeComboBox.getValue() : null;
        if (selectedType != null) {
            form.put("leaveType", selectedType.getValue());
        }
        LocalDateTime startDateTime = LocalDateTime.of(startDatePicker.getValue(), LocalTime.of(8, 0));
        form.put("startTime", startDateTime.format(dateTimeFormatter));
        LocalDateTime endDateTime = LocalDateTime.of(endDatePicker.getValue(), LocalTime.of(18, 0));
        form.put("endTime", endDateTime.format(dateTimeFormatter));
        form.put("destination", destinationField != null ? destinationField.getText() : "");
        form.put("contact", contactField != null ? contactField.getText() : "");
        form.put("reason", reasonArea != null ? reasonArea.getText() : "");
        OptionItem selectedStatus = leaveStatusComboBox != null ? leaveStatusComboBox.getValue() : null;
        if (selectedStatus != null) {
            form.put("status", selectedStatus.getValue());
            if (!"1".equals(selectedStatus.getValue())) {
                form.put("approver", approverField != null ? approverField.getText() : "");
            }
        }
        request.add("form", form);
        if (currentLeaveId != null) {
            request.add("leaveId", currentLeaveId);
        }
        DataResponse response = HttpRequestUtil.request("/api/leave/edit", request);
        if (response != null && response.getCode() == 0) {
            MessageDialog.showDialog("保存成功");
            // 只更新表格当前选中行
            Map<String, Object> selected = dataTableView.getSelectionModel().getSelectedItem();
            if (selected != null) {
                selected.put("leaveType", form.get("leaveType"));
                selected.put("startTime", form.get("startTime"));
                selected.put("endTime", form.get("endTime"));
                selected.put("destination", form.get("destination"));
                selected.put("contact", form.get("contact"));
                selected.put("reason", form.get("reason"));
                selected.put("status", form.get("status"));
                selected.put("approver", form.get("approver"));
                if (selectedStudent != null) {
                    selected.put("student", selectedStudent);
                }
                dataTableView.refresh();
            }
        } else {
            String errorMsg = response != null ? response.getMsg() : "保存失败，请稍后重试";
            MessageDialog.showDialog(errorMsg);
        }
    }
    
    /**
     * 审批按钮事件
     */
    @FXML
    private void onApproveButtonClick(ActionEvent event) {
        if (currentLeaveId == null) {
            MessageDialog.showDialog("请先选择要审批的请假记录");
            return;
        }
        
        // 创建审批对话框
        Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.setTitle("请假审批");
        
        VBox dialogVBox = new VBox(10);
        dialogVBox.setPadding(new Insets(20));
        
        // 状态选择
        HBox statusBox = new HBox(10);
        statusBox.setAlignment(Pos.CENTER_LEFT);
        Label statusLabel = new Label("审批结果：");
        ComboBox<OptionItem> statusSelector = new ComboBox<>();
        
        // 过滤出审批相关的状态（已批准/已拒绝）
        List<OptionItem> approvalStatus = new ArrayList<>();
        for (OptionItem item : leaveStatusComboBox.getItems()) {
            if ("2".equals(item.getValue()) || "3".equals(item.getValue())) {
                approvalStatus.add(item);
            }
        }
        
        statusSelector.setItems(FXCollections.observableArrayList(approvalStatus));
        if (!approvalStatus.isEmpty()) {
            statusSelector.setValue(approvalStatus.get(0));
        }
        
        statusBox.getChildren().addAll(statusLabel, statusSelector);
        
        // 审批人
        HBox approverBox = new HBox(10);
        approverBox.setAlignment(Pos.CENTER_LEFT);
        Label approverLabel = new Label("审批人：");
        TextField approverInput = new TextField();
        approverBox.getChildren().addAll(approverLabel, approverInput);
        
        // 审批意见
        Label commentLabel = new Label("审批意见：");
        TextArea commentArea = new TextArea();
        commentArea.setPrefHeight(100);
        
        // 按钮
        HBox buttonBox = new HBox(20);
        buttonBox.setAlignment(Pos.CENTER);
        Button confirmButton = new Button("确认");
        Button cancelButton = new Button("取消");
        buttonBox.getChildren().addAll(confirmButton, cancelButton);
        
        dialogVBox.getChildren().addAll(statusBox, approverBox, commentLabel, commentArea, buttonBox);
        
        // 设置事件
        cancelButton.setOnAction(e -> dialog.close());
        
        confirmButton.setOnAction(e -> {
            if (approverInput.getText().trim().isEmpty()) {
                MessageDialog.showDialog("请填写审批人");
                return;
            }
            
            // 发送审批请求
            DataRequest request = new DataRequest();
            request.add("leaveId", currentLeaveId);
            request.add("status", statusSelector.getValue().getValue());
            request.add("approver", approverInput.getText());
            request.add("approveComment", commentArea.getText());
            
            DataResponse response = HttpRequestUtil.request("/api/leave/approve", request);
            if (response != null && response.getCode() == 0) {
                MessageDialog.showDialog("审批成功");
                dialog.close();
                loadData();
            } else {
                String errorMsg = response != null ? response.getMsg() : "审批失败，请稍后重试";
                MessageDialog.showDialog(errorMsg);
            }
        });
        
        Scene dialogScene = new Scene(dialogVBox, 400, 300);
        dialog.setScene(dialogScene);
        dialog.showAndWait();
    }
    
    /**
     * 选择学生按钮事件
     */
    @FXML
    private void onSelectStudentButtonClick(ActionEvent event) {
        try {
            // 加载所有学生
            DataRequest request = new DataRequest();
            request.add("numName", ""); // 空字符串表示获取所有学生
            DataResponse response = HttpRequestUtil.request("/api/student/getStudentList", request);
            List<Map<String, Object>> studentsList = new ArrayList<>();
            
            if (response != null && response.getCode() == 0 && response.getData() != null) {
                studentsList = (List<Map<String, Object>>) response.getData();
                
                if (!studentsList.isEmpty()) {
                    // 创建学生选择对话框
                    showStudentSelectionDialog(studentsList);
                } else {
                    MessageDialog.showDialog("没有可选择的学生数据");
                }
            } else {
                String errorMsg = response != null ? response.getMsg() : "无法连接到服务器";
                MessageDialog.showDialog("获取学生列表失败: " + errorMsg);
            }
        } catch (Exception e) {
            e.printStackTrace();
            MessageDialog.showDialog("获取学生列表时发生错误: " + e.getMessage());
        }
    }
    
    private void showStudentSelectionDialog(List<Map<String, Object>> students) {
        try {
            // 创建一个临时表格
            TableView<Map<String, Object>> tableView = new TableView<>();
            tableView.setPrefSize(500, 400);
            
            // 添加列
            TableColumn<Map<String, Object>, String> numCol = new TableColumn<>("学号");
            numCol.setCellValueFactory(cellData -> {
                Object value = cellData.getValue().get("num");
                return new SimpleStringProperty(value != null ? value.toString() : "");
            });
            numCol.setPrefWidth(100);
            
            TableColumn<Map<String, Object>, String> nameCol = new TableColumn<>("姓名");
            nameCol.setCellValueFactory(cellData -> {
                Object value = cellData.getValue().get("name");
                return new SimpleStringProperty(value != null ? value.toString() : "");
            });
            nameCol.setPrefWidth(100);
            
            TableColumn<Map<String, Object>, String> classCol = new TableColumn<>("班级");
            classCol.setCellValueFactory(cellData -> {
                Object value = cellData.getValue().get("className");
                return new SimpleStringProperty(value != null ? value.toString() : "");
            });
            classCol.setPrefWidth(120);
            
            TableColumn<Map<String, Object>, String> deptCol = new TableColumn<>("院系");
            deptCol.setCellValueFactory(cellData -> {
                Object value = cellData.getValue().get("dept");
                return new SimpleStringProperty(value != null ? value.toString() : "");
            });
            deptCol.setPrefWidth(120);
            
            tableView.getColumns().addAll(numCol, nameCol, classCol, deptCol);
            tableView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
            
            // 添加数据
            ObservableList<Map<String, Object>> studentList = FXCollections.observableArrayList(students);
            tableView.setItems(studentList);
            
            // 添加搜索功能
            TextField searchField = new TextField();
            searchField.setPromptText("输入学号或姓名搜索");
            searchField.setPrefWidth(250);
            
            Button searchButton = new Button("搜索");
            searchButton.setOnAction(e -> {
                String keyword = searchField.getText().toLowerCase();
                ObservableList<Map<String, Object>> filteredList = FXCollections.observableArrayList();
                
                for (Map<String, Object> student : students) {
                    String num = String.valueOf(student.get("num")).toLowerCase();
                    String name = String.valueOf(student.get("name")).toLowerCase();
                    
                    if (num.contains(keyword) || name.contains(keyword)) {
                        filteredList.add(student);
                    }
                }
                
                tableView.setItems(filteredList);
            });
            
            HBox searchBox = new HBox(10, new Label("搜索:"), searchField, searchButton);
            searchBox.setPadding(new Insets(10));
            searchBox.setAlignment(Pos.CENTER_LEFT);
            
            // 创建布局
            VBox vbox = new VBox(10);
            vbox.setPadding(new Insets(10));
            
            Label titleLabel = new Label("选择请假学生");
            titleLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 14px;");
            
            HBox buttonBox = new HBox(10);
            buttonBox.setAlignment(Pos.CENTER);
            
            Button selectButton = new Button("选择");
            Button cancelButton = new Button("取消");
            
            buttonBox.getChildren().addAll(selectButton, cancelButton);
            vbox.getChildren().addAll(titleLabel, searchBox, tableView, buttonBox);
            
            // 创建场景和舞台
            Scene scene = new Scene(vbox);
            Stage stage = new Stage();
            stage.setTitle("选择学生");
            stage.setScene(scene);
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setResizable(false);
            
            // 设置按钮事件
            selectButton.setOnAction(e -> {
                Map<String, Object> selectedStudent = tableView.getSelectionModel().getSelectedItem();
                if (selectedStudent != null) {
                    this.selectedStudent = selectedStudent;
                    String studentName = String.valueOf(selectedStudent.get("name"));
                    String studentNum = String.valueOf(selectedStudent.get("num"));
                    studentField.setText(studentName + " (" + studentNum + ")");
                    stage.close();
                } else {
                    MessageDialog.showDialog("请选择一个学生");
                }
            });
            
            cancelButton.setOnAction(e -> stage.close());
            
            // 显示舞台
            stage.showAndWait();
        } catch (Exception e) {
            e.printStackTrace();
            MessageDialog.showDialog("显示学生选择对话框失败: " + e.getMessage());
        }
    }
    
    /**
     * 安全获取Map中的Integer值
     */
    private Integer safeGetInteger(Map<String, Object> map, String key) {
        Object value = map.get(key);
        return safeGetInteger(value);
    }
    
    /**
     * 安全转换Object为Integer
     */
    private Integer safeGetInteger(Object value) {
        if (value == null) {
            return null;
        }
        if (value instanceof Integer) {
            return (Integer) value;
        }
        if (value instanceof Double) {
            return ((Double) value).intValue();
        }
        try {
            return Integer.parseInt(value.toString());
        } catch (NumberFormatException e) {
            return null;
        }
    }
} 