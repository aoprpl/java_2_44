package com.teach.javafx.controller;

import com.teach.javafx.controller.base.MessageDialog;
import com.teach.javafx.request.DataRequest;
import com.teach.javafx.request.DataResponse;
import com.teach.javafx.request.HttpRequestUtil;
import com.teach.javafx.request.OptionItem;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.geometry.Insets;
import javafx.geometry.Pos;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
/**
 * 学生请假管理控制器
 */
public class LeaveController {
    // 查询和列表展示相关组件
    @FXML
    private TextField keywordTextField;
    
    @FXML
    private ComboBox<OptionItem> leaveTypeComboBox;
    
    @FXML
    private ComboBox<OptionItem> statusComboBox;
    
    @FXML
    private TableView<Map<String, Object>> dataTableView;
    
    @FXML
    private TableColumn<Map<String, Object>, String> studentNameColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> studentNumColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> leaveTypeColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> startTimeColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> endTimeColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> destinationColumn;
    
    @FXML
    private TableColumn<Map<String, Object>, String> statusColumn;
    
    // 详情编辑相关组件
    @FXML
    private TextField studentField;
    
    @FXML
    private ComboBox<OptionItem> typeComboBox;
    
    @FXML
    private DatePicker startDatePicker;
    
    @FXML
    private DatePicker endDatePicker;
    
    @FXML
    private TextField destinationField;
    
    @FXML
    private TextField contactField;
    
    @FXML
    private ComboBox<OptionItem> leaveStatusComboBox;
    
    @FXML
    private TextField approverField;
    
    @FXML
    private TextArea reasonTextArea;
    
    // 数据列表
    private ObservableList<Map<String, Object>> dataList = FXCollections.observableArrayList();
    
    // 当前选中的学生
    private Map<String, Object> selectedStudent = null;
    
    // 当前请假ID
    private Integer currentLeaveId = null;
    
    // 日期时间格式化器
    private final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private Stage editStage = null;
    
    /**
     * 初始化方法，JavaFX初始化时自动调用
     */
    @FXML
    private void initialize() {
        // 初始化表格列
        studentNameColumn.setCellValueFactory(cellData -> {
            Map<String, Object> student = (Map<String, Object>) cellData.getValue().get("student");
            if (student != null) {
                return new SimpleStringProperty(String.valueOf(student.get("name")));
            }
            return new SimpleStringProperty("");
        });
        
        studentNumColumn.setCellValueFactory(cellData -> {
            Map<String, Object> student = (Map<String, Object>) cellData.getValue().get("student");
            if (student != null) {
                return new SimpleStringProperty(String.valueOf(student.get("num")));
            }
            return new SimpleStringProperty("");
        });
        
        leaveTypeColumn.setCellValueFactory(cellData -> {
            String leaveType = String.valueOf(cellData.getValue().get("leaveType"));
            for (OptionItem item : typeComboBox.getItems()) {
                if (item.getValue().equals(leaveType)) {
                    return new SimpleStringProperty(item.getTitle());
                }
            }
            return new SimpleStringProperty(leaveType);
        });
        
        startTimeColumn.setCellValueFactory(cellData -> {
            Object value = cellData.getValue().get("startTime");
            if (value != null && !value.toString().isEmpty()) {
                try {
                    LocalDateTime dateTime = LocalDateTime.parse(value.toString(), dateTimeFormatter);
                    return new SimpleStringProperty(dateTime.format(dateTimeFormatter));
                } catch (Exception e) {
                    return new SimpleStringProperty(value.toString());
                }
            }
            return new SimpleStringProperty("");
        });
        
        endTimeColumn.setCellValueFactory(cellData -> {
            Object value = cellData.getValue().get("endTime");
            if (value != null && !value.toString().isEmpty()) {
                try {
                    LocalDateTime dateTime = LocalDateTime.parse(value.toString(), dateTimeFormatter);
                    return new SimpleStringProperty(dateTime.format(dateTimeFormatter));
                } catch (Exception e) {
                    return new SimpleStringProperty(value.toString());
                }
            }
            return new SimpleStringProperty("");
        });
        
        destinationColumn.setCellValueFactory(cellData -> 
            new SimpleStringProperty(String.valueOf(cellData.getValue().get("destination"))));
        
        statusColumn.setCellValueFactory(cellData -> {
            String status = String.valueOf(cellData.getValue().get("status"));
            for (OptionItem item : leaveStatusComboBox.getItems()) {
                if (item.getValue().equals(status)) {
                    return new SimpleStringProperty(item.getTitle());
                }
            }
            return new SimpleStringProperty(status);
        });
        
        // 添加行样式类，根据状态设置不同的背景颜色
        dataTableView.setRowFactory(tv -> {
            TableRow<Map<String, Object>> row = new TableRow<>();
            row.itemProperty().addListener((obs, oldItem, newItem) -> {
                if (newItem != null) {
                    String status = String.valueOf(newItem.get("status"));
                    // 清除所有状态样式
                    row.getStyleClass().removeAll("status-approved", "status-pending", "status-rejected");
                    
                    // 根据状态添加对应的样式类
                    if ("2".equals(status)) {
                        row.getStyleClass().add("status-approved");
                    } else if ("1".equals(status)) {
                        row.getStyleClass().add("status-pending");
                    } else if ("3".equals(status)) {
                        row.getStyleClass().add("status-rejected");
                    }
                }
            });
            return row;
        });
        
        // 绑定数据列表到表格
        dataTableView.setItems(dataList);
        
        // 表格选择事件
        dataTableView.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                displayLeaveDetails(newSelection);
            }
        });
        
        // 表格样式
        dataTableView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        
        // 初始化下拉框
        initComboBoxes();
        
        // 加载数据
        loadData();
    }
    
    /**
     * 初始化下拉框
     */
    private void initComboBoxes() {
        // 请假类型下拉框
        List<OptionItem> leaveTypes = HttpRequestUtil.getDictionaryOptionItemList("QJLX");
        
        // 如果从服务器获取的类型为空，添加一些默认值
        if (leaveTypes == null || leaveTypes.isEmpty()) {
            leaveTypes = new ArrayList<>();
            leaveTypes.add(new OptionItem(1, "1", "事假"));
            leaveTypes.add(new OptionItem(2, "2", "病假"));
            leaveTypes.add(new OptionItem(3, "3", "外出"));
            leaveTypes.add(new OptionItem(4, "4", "实习"));
            leaveTypes.add(new OptionItem(5, "5", "其他"));
        }
        
        leaveTypeComboBox.setItems(FXCollections.observableArrayList(leaveTypes));
        typeComboBox.setItems(FXCollections.observableArrayList(leaveTypes));
        
        // 请假状态下拉框
        List<OptionItem> leaveStatus = HttpRequestUtil.getDictionaryOptionItemList("QJZT");
        
        // 如果从服务器获取的状态为空，添加一些默认值
        if (leaveStatus == null || leaveStatus.isEmpty()) {
            leaveStatus = new ArrayList<>();
            leaveStatus.add(new OptionItem(1, "1", "待审批"));
            leaveStatus.add(new OptionItem(2, "2", "已批准"));
            leaveStatus.add(new OptionItem(3, "3", "已拒绝"));
            leaveStatus.add(new OptionItem(4, "4", "已销假"));
        }
        
        statusComboBox.setItems(FXCollections.observableArrayList(leaveStatus));
        leaveStatusComboBox.setItems(FXCollections.observableArrayList(leaveStatus));
        
        // 设置默认值
        if (!leaveTypes.isEmpty()) {
            leaveTypeComboBox.setValue(null); // 查询时默认不选择
            typeComboBox.setValue(leaveTypes.get(0)); // 新建时默认第一个类型
        }
        
        if (!leaveStatus.isEmpty()) {
            statusComboBox.setValue(null); // 查询时默认不选择
            leaveStatusComboBox.setValue(leaveStatus.get(0)); // 默认待审批
        }
    }
    
    /**
     * 加载请假数据
     */
    public void loadData() {
        DataRequest request = new DataRequest();
        
        String keyword = keywordTextField.getText();
        if (keyword != null && !keyword.isEmpty()) {
            request.add("keyword", keyword);
        }
        
        OptionItem selectedType = leaveTypeComboBox.getValue();
        if (selectedType != null) {
            request.add("leaveType", selectedType.getValue());
        }
        
        OptionItem selectedStatus = statusComboBox.getValue();
        if (selectedStatus != null) {
            request.add("status", selectedStatus.getValue());
        }
        
        DataResponse response = HttpRequestUtil.request("/api/leave/list", request);
        if (response != null && response.getData() != null) {
            dataList.clear();
            List<Map<String, Object>> list = (List<Map<String, Object>>) response.getData();
            dataList.addAll(list);
        }
    }
    
    /**
     * 显示请假详情
     */
    private void displayLeaveDetails(Map<String, Object> leave) {
        clearForm();
        
        // 设置当前请假ID
        currentLeaveId = safeGetInteger(leave, "leaveId");
        
        // 设置学生信息
        Map<String, Object> student = (Map<String, Object>) leave.get("student");
        if (student != null) {
            selectedStudent = student;
            String name = String.valueOf(student.get("name"));
            String num = String.valueOf(student.get("num"));
            studentField.setText(name + " (" + num + ")");
        }
        
        // 设置请假类型
        String leaveType = String.valueOf(leave.get("leaveType"));
        for (OptionItem item : typeComboBox.getItems()) {
            if (item.getValue().equals(leaveType)) {
                typeComboBox.setValue(item);
                break;
            }
        }
        
        // 设置开始和结束时间
        String startTimeStr = (String) leave.get("startTime");
        if (startTimeStr != null && !startTimeStr.isEmpty()) {
            try {
                LocalDateTime startTime = LocalDateTime.parse(startTimeStr, dateTimeFormatter);
                startDatePicker.setValue(startTime.toLocalDate());
            } catch (DateTimeParseException e) {
                System.err.println("Invalid start time format: " + startTimeStr);
            }
        }
        
        String endTimeStr = (String) leave.get("endTime");
        if (endTimeStr != null && !endTimeStr.isEmpty()) {
            try {
                LocalDateTime endTime = LocalDateTime.parse(endTimeStr, dateTimeFormatter);
                endDatePicker.setValue(endTime.toLocalDate());
            } catch (DateTimeParseException e) {
                System.err.println("Invalid end time format: " + endTimeStr);
            }
        }
        
        // 设置其他字段
        destinationField.setText(String.valueOf(leave.get("destination")));
        contactField.setText(String.valueOf(leave.get("contact")));
        
        // 设置状态
        String status = String.valueOf(leave.get("status"));
        for (OptionItem item : leaveStatusComboBox.getItems()) {
            if (item.getValue().equals(status)) {
                leaveStatusComboBox.setValue(item);
                break;
            }
        }
        
        approverField.setText(String.valueOf(leave.get("approver")));
        reasonTextArea.setText(String.valueOf(leave.get("reason")));
    }
    
    /**
     * 清空表单
     */
    private void clearForm() {
        currentLeaveId = null;
        selectedStudent = null;
        studentField.clear();
        
        if (!typeComboBox.getItems().isEmpty()) {
            typeComboBox.setValue(typeComboBox.getItems().get(0));
        }
        
        startDatePicker.setValue(LocalDate.now());
        endDatePicker.setValue(LocalDate.now().plusDays(1));
        destinationField.clear();
        contactField.clear();
        
        if (!leaveStatusComboBox.getItems().isEmpty()) {
            leaveStatusComboBox.setValue(leaveStatusComboBox.getItems().get(0)); // 默认"待审批"
        }
        
        approverField.clear();
        reasonTextArea.clear();
    }
    
    /**
     * 新增按钮事件
     */
    @FXML
    private void onAddButtonClick(ActionEvent event) {
        try {
            if (editStage == null) {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/teach/javafx/leave-edit-dialog.fxml"));
                Parent root = loader.load();
                editStage = new Stage();
                editStage.setTitle("添加请假");
                editStage.initModality(Modality.APPLICATION_MODAL);
                editStage.setScene(new Scene(root));
            }
            editStage.showAndWait();
        } catch (IOException e) {
            e.printStackTrace();
            MessageDialog.showDialog("打开编辑窗口失败：" + e.getMessage());
        }
    }
    
    /**
     * 清空按钮事件
     */
    @FXML
    private void onClearButtonClick(ActionEvent event) {
        clearForm();
    }
    
    /**
     * 删除按钮事件
     */
    @FXML
    private void onDeleteButtonClick(ActionEvent event) {
        if (currentLeaveId == null) {
            MessageDialog.showDialog("请先选择要删除的请假记录");
            return;
        }
        
        int choice = MessageDialog.choiceDialog("确定要删除该请假记录吗？");
        if (choice != MessageDialog.CHOICE_YES) {
            return;
        }
        
        DataRequest request = new DataRequest();
        request.add("leaveId", currentLeaveId);
        
        DataResponse response = HttpRequestUtil.request("/api/leave/delete", request);
        if (response != null && response.getCode() == 0) {
            MessageDialog.showDialog("删除成功");
            clearForm();
            loadData();
        } else {
            String errorMsg = response != null ? response.getMsg() : "删除失败，请稍后重试";
            MessageDialog.showDialog(errorMsg);
        }
    }
    
    /**
     * 查询按钮事件
     */
    @FXML
    private void onQueryButtonClick(ActionEvent event) {
        loadData();
    }
    
    /**
     * 保存按钮事件
     */
    @FXML
    private void onSaveButtonClick(ActionEvent event) {
        // 验证表单
        if (selectedStudent == null) {
            MessageDialog.showDialog("请选择学生");
            return;
        }
        
        if (startDatePicker.getValue() == null) {
            MessageDialog.showDialog("请选择开始时间");
            return;
        }
        
        if (endDatePicker.getValue() == null) {
            MessageDialog.showDialog("请选择结束时间");
            return;
        }
        
        if (endDatePicker.getValue().isBefore(startDatePicker.getValue())) {
            MessageDialog.showDialog("结束时间不能早于开始时间");
            return;
        }
        
        if (reasonTextArea.getText().trim().isEmpty()) {
            MessageDialog.showDialog("请填写请假原因");
            return;
        }
        
        // 创建请求
        DataRequest request = new DataRequest();
        Map<String, Object> form = new HashMap<>();
        
        // 设置学生ID
        Integer studentId = safeGetInteger(selectedStudent, "personId");
        form.put("studentId", studentId);
        
        // 设置请假类型
        OptionItem selectedType = typeComboBox.getValue();
        if (selectedType != null) {
            form.put("leaveType", selectedType.getValue());
        }
        
        // 设置开始和结束时间
        LocalDateTime startDateTime = LocalDateTime.of(startDatePicker.getValue(), LocalTime.of(8, 0));
        form.put("startTime", startDateTime.format(dateTimeFormatter));
        
        LocalDateTime endDateTime = LocalDateTime.of(endDatePicker.getValue(), LocalTime.of(18, 0));
        form.put("endTime", endDateTime.format(dateTimeFormatter));
        
        // 设置其他字段
        form.put("destination", destinationField.getText());
        form.put("contact", contactField.getText());
        form.put("reason", reasonTextArea.getText());
        
        // 设置状态和审批信息
        OptionItem selectedStatus = leaveStatusComboBox.getValue();
        if (selectedStatus != null) {
            form.put("status", selectedStatus.getValue());
            
            // 如果是审批相关状态，设置审批人
            if (!"1".equals(selectedStatus.getValue())) {
                form.put("approver", approverField.getText());
            }
        }
        
        request.add("form", form);
        
        // 如果是编辑已有请假，设置请假ID
        if (currentLeaveId != null) {
            request.add("leaveId", currentLeaveId);
        }
        
        // 发送请求
        DataResponse response = HttpRequestUtil.request("/api/leave/edit", request);
        if (response != null && response.getCode() == 0) {
            MessageDialog.showDialog("保存成功");
            
            // 如果是新建，设置返回的ID
            if (currentLeaveId == null && response.getData() != null) {
                currentLeaveId = safeGetInteger(response.getData());
            }
            
            // 重新加载数据
            loadData();
        } else {
            String errorMsg = response != null ? response.getMsg() : "保存失败，请稍后重试";
            MessageDialog.showDialog(errorMsg);
        }
    }
    
    /**
     * 审批按钮事件
     */
    @FXML
    private void onApproveButtonClick(ActionEvent event) {
        if (currentLeaveId == null) {
            MessageDialog.showDialog("请先选择要审批的请假记录");
            return;
        }
        
        // 创建审批对话框
        Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.setTitle("请假审批");
        
        VBox dialogVBox = new VBox(10);
        dialogVBox.setPadding(new Insets(20));
        
        // 状态选择
        HBox statusBox = new HBox(10);
        statusBox.setAlignment(Pos.CENTER_LEFT);
        Label statusLabel = new Label("审批结果：");
        ComboBox<OptionItem> statusSelector = new ComboBox<>();
        
        // 过滤出审批相关的状态（已批准/已拒绝）
        List<OptionItem> approvalStatus = new ArrayList<>();
        for (OptionItem item : leaveStatusComboBox.getItems()) {
            if ("2".equals(item.getValue()) || "3".equals(item.getValue())) {
                approvalStatus.add(item);
            }
        }
        
        statusSelector.setItems(FXCollections.observableArrayList(approvalStatus));
        if (!approvalStatus.isEmpty()) {
            statusSelector.setValue(approvalStatus.get(0));
        }
        
        statusBox.getChildren().addAll(statusLabel, statusSelector);
        
        // 审批人
        HBox approverBox = new HBox(10);
        approverBox.setAlignment(Pos.CENTER_LEFT);
        Label approverLabel = new Label("审批人：");
        TextField approverInput = new TextField();
        approverBox.getChildren().addAll(approverLabel, approverInput);
        
        // 审批意见
        Label commentLabel = new Label("审批意见：");
        TextArea commentArea = new TextArea();
        commentArea.setPrefHeight(100);
        
        // 按钮
        HBox buttonBox = new HBox(20);
        buttonBox.setAlignment(Pos.CENTER);
        Button confirmButton = new Button("确认");
        Button cancelButton = new Button("取消");
        buttonBox.getChildren().addAll(confirmButton, cancelButton);
        
        dialogVBox.getChildren().addAll(statusBox, approverBox, commentLabel, commentArea, buttonBox);
        
        // 设置事件
        cancelButton.setOnAction(e -> dialog.close());
        
        confirmButton.setOnAction(e -> {
            if (approverInput.getText().trim().isEmpty()) {
                MessageDialog.showDialog("请填写审批人");
                return;
            }
            
            // 发送审批请求
            DataRequest request = new DataRequest();
            request.add("leaveId", currentLeaveId);
            request.add("status", statusSelector.getValue().getValue());
            request.add("approver", approverInput.getText());
            request.add("approveComment", commentArea.getText());
            
            DataResponse response = HttpRequestUtil.request("/api/leave/approve", request);
            if (response != null && response.getCode() == 0) {
                MessageDialog.showDialog("审批成功");
                dialog.close();
                loadData();
            } else {
                String errorMsg = response != null ? response.getMsg() : "审批失败，请稍后重试";
                MessageDialog.showDialog(errorMsg);
            }
        });
        
        Scene dialogScene = new Scene(dialogVBox, 400, 300);
        dialog.setScene(dialogScene);
        dialog.showAndWait();
    }
    
    /**
     * 选择学生按钮事件
     */
    @FXML
    private void onSelectStudentButtonClick(ActionEvent event) {
        // 获取学生列表
        DataRequest request = new DataRequest();
        DataResponse response = HttpRequestUtil.request("/api/student/list", request);
        
        if (response != null && response.getData() != null) {
            List<Map<String, Object>> students = (List<Map<String, Object>>) response.getData();
            showStudentSelectionDialog(students);
        } else {
            MessageDialog.showDialog("获取学生列表失败，请稍后重试");
        }
    }
    
    /**
     * 显示学生选择对话框
     */
    private void showStudentSelectionDialog(List<Map<String, Object>> students) {
        Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.setTitle("选择学生");
        
        VBox dialogVBox = new VBox(10);
        dialogVBox.setPadding(new Insets(20));
        
        // 搜索框
        HBox searchBox = new HBox(10);
        TextField searchField = new TextField();
        searchField.setPromptText("输入学号或姓名搜索");
        searchField.setPrefWidth(200);
        Button searchButton = new Button("搜索");
        searchBox.getChildren().addAll(searchField, searchButton);
        
        // 学生列表
        TableView<Map<String, Object>> studentTable = new TableView<>();
        studentTable.setPrefHeight(300);
        
        TableColumn<Map<String, Object>, String> numColumn = new TableColumn<>("学号");
        numColumn.setCellValueFactory(data -> new SimpleStringProperty(String.valueOf(data.getValue().get("num"))));
        numColumn.setPrefWidth(120);
        
        TableColumn<Map<String, Object>, String> nameColumn = new TableColumn<>("姓名");
        nameColumn.setCellValueFactory(data -> new SimpleStringProperty(String.valueOf(data.getValue().get("name"))));
        nameColumn.setPrefWidth(100);
        
        TableColumn<Map<String, Object>, String> classColumn = new TableColumn<>("班级");
        classColumn.setCellValueFactory(data -> new SimpleStringProperty(String.valueOf(data.getValue().get("className"))));
        classColumn.setPrefWidth(120);
        
        studentTable.getColumns().addAll(numColumn, nameColumn, classColumn);
        
        // 确认按钮
        HBox buttonBox = new HBox(20);
        buttonBox.setAlignment(Pos.CENTER);
        Button selectButton = new Button("选择");
        Button cancelButton = new Button("取消");
        buttonBox.getChildren().addAll(selectButton, cancelButton);
        
        dialogVBox.getChildren().addAll(searchBox, studentTable, buttonBox);
        
        // 加载学生数据
        ObservableList<Map<String, Object>> studentData = FXCollections.observableArrayList(students);
        studentTable.setItems(studentData);
        
        // 搜索功能
        searchButton.setOnAction(e -> {
            String keyword = searchField.getText().toLowerCase();
            if (keyword.isEmpty()) {
                studentTable.setItems(studentData);
            } else {
                ObservableList<Map<String, Object>> filteredData = FXCollections.observableArrayList();
                for (Map<String, Object> student : students) {
                    String num = String.valueOf(student.get("num")).toLowerCase();
                    String name = String.valueOf(student.get("name")).toLowerCase();
                    if (num.contains(keyword) || name.contains(keyword)) {
                        filteredData.add(student);
                    }
                }
                studentTable.setItems(filteredData);
            }
        });
        
        // 设置按钮事件
        cancelButton.setOnAction(e -> dialog.close());
        
        selectButton.setOnAction(e -> {
            Map<String, Object> selectedItem = studentTable.getSelectionModel().getSelectedItem();
            if (selectedItem != null) {
                selectedStudent = selectedItem;
                String name = String.valueOf(selectedItem.get("name"));
                String num = String.valueOf(selectedItem.get("num"));
                studentField.setText(name + " (" + num + ")");
                dialog.close();
            } else {
                MessageDialog.showDialog("请先选择一名学生");
            }
        });
        
        Scene dialogScene = new Scene(dialogVBox, 400, 450);
        dialog.setScene(dialogScene);
        dialog.showAndWait();
    }
    
    /**
     * 安全获取Map中的Integer值
     */
    private Integer safeGetInteger(Map<String, Object> map, String key) {
        Object value = map.get(key);
        return safeGetInteger(value);
    }
    
    /**
     * 安全转换Object为Integer
     */
    private Integer safeGetInteger(Object value) {
        if (value == null) {
            return null;
        }
        
        if (value instanceof Integer) {
            return (Integer) value;
        }
        
        try {
            return Integer.parseInt(value.toString());
        } catch (NumberFormatException e) {
            return null;
        }
    }
} 